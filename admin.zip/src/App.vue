<template>
<div id="app">
  <ms-header></ms-header>
  <div class="content">
    <div class="ccc">
      <div class="main-menu">
       <el-menu default-active="1" class="el-menu-vertical-demo" @open="handleOpen" @close="handleClose" :router=true :default-openeds="openeds">
           <el-submenu :index="openeds[index]" v-for="(item,index) in navList">
             <template slot="title"><i class="el-icon-message"></i>{{item.name}}</template>
             <el-menu-item-group>
                <el-menu-item v-for="items in item.menus" :index="items.url" v-if="items.type==1">
                  <span class="item" :class="{ isactive: isActive=== items.url }">{{items.name}}</span>
                </el-menu-item>
             </el-menu-item-group>
           </el-submenu>
       </el-menu> 
      </div>
      <router-view ref="present"></router-view>
    </div>
  </div>
  <my-foot></my-foot>
</div>
</template>
<script>
import msHeader from './views/header/header.vue';
import myFoot from './components/footer.vue';

export default {
  name: 'app',
  components: {
    msHeader,
    myFoot
  },
  data() {
    return {
      openeds: ["1","2","3"],
      route: '',
      hehe: '',
      defaultProps: {
        children: 'children',
        label: 'label'
      },
      isActive: '',
      jurisdiction: {
        business: {},
        code: {},
        authority: {}
      },
      navList:[],
      limit: {}
    }
  },
  created() { 
    var newList = JSON.parse(localStorage.getItem('newNavList'));
    this.isActive = newList[0].menus[0].url;
    this.navList = newList; 
    
    var that = this
     
    if (newList.length == 0) {
      this.$router.push({
        path: '/login'
      });
      return false;
    } 
    function delCookie(name) {
      var exp = new Date();
      exp.setTime(exp.getTime() - 1);
      var cval = getCookie(name);
      if (cval != null)
        document.cookie = name + "=" + cval + ";expires=" + exp.toGMTString();
    }
    //判断是否进入登录页面
    if (localStorage.getItem('loginTime')) {
      //超时半小时
      if (localStorage.getItem('urgeTime')) {
        //超时半小时
        if (new Date().getTime() - localStorage.getItem('urgeTime') > 1800000) {
          this.$router.push('/login');
        }
      } else {
        this.$router.push('/login');
      }
    } else {
      this.$router.push('/login');
    } 


  },
  watch: {
    '$route' (to, from) { 
      this.changeActive(to.path);
    }
  },
  methods: {
    isclick() {
      // this.$refs.present.reload();
    },
    userSignIn(userName) {},
    handleOpen(key, keyPath) {},
    handleClose(key, keyPath) {},
    changeActive(path) {
      this.isActive = path; 
    }
  }
}
</script>
<style lang="less" rel="stylesheet/less" scoped>
@import './common/less/property.less';
#app {
    overflow-x: hidden;
}
.content {
    width: 100%;
    margin-bottom: 20px;
    .ccc {
        width: 100%;
        display: flex;
        .ted {
            border: 0;
        }
    }
    .main-nav {
        ul {
            border-bottom: 1px solid #FFF;
            overflow: hidden;
            border-width: 0;
            .nav-item {
                overflow: hidden;
                font-size: 14px;
                line-height: 22px;
                color: white;
                position: relative;
                width: 130px;
                padding: 6px 0 0 8px;
                cursor: pointer;
                .nav-item-inner {
                    border-radius: 2px 2px 0 0;
                    border: 1px solid #FFF;
                    background-color: #E8E9EE;
                    color: #43478e;
                    font-weight: bold;
                    height: 30px;
                    padding: 4px 0 0 31px;
                }
            }
        }
    }
}

.main-menu {
    position: fixed;
    top: 60px;
    /*top: 0;*/
    bottom: 0;
    width: 230px;
    /*min-height: 800px;*/
    /*flex: 0 0 230px;*/
    /*float: left;*/
    /*width: 150px;*/
    /*padding-top: 5px;*/
    background-color: #E8E9EE;
    /*border: 1px solid #ccc;*/
    text-align: left;
    overflow-y: auto;
    overflow-x: hidden;
    z-index: 99;
    /*height: 800px;*/
    .item {
        color: #48576a;
    }
    /*.el-menu-item.is-active {*/
    /*color: #48576a!important;*/
    /*}*/
    .isactive {
        display: inline-block;
        color: #20a0ff!important;
        width: 100%;
    }
    .menutitle {
        /*margin: 0 1px;*/
        /*text-align: center;*/
        background-position: 0 15px;
        height: 17px;
        color: #636775;
        font-weight: bold;
        font-size: 12px;
        overflow: hidden;
        line-height: 25px;
        vertical-align: middle;
        padding: 8px 0 5px 5px;
        /*text-align: center;*/
    }
    ul {
        .menu-li {
            .route {
                height: 20px;
                text-indent: 24px;
                overflow: hidden;
                margin-bottom: 5px;
                display: block;
                color: #5c637b;
                outline: none;
                cursor: pointer;
                em {
                    display: block;
                    margin: 0 1px;
                    font-style: normal;
                    font-family: "SimSun", "Helvetica Neue", Helvetica, Arial, sans-serif;
                    font-size: 12px;
                    text-align: left;
                    overflow: hidden;
                    height: 19px;
                    line-height: 22px;
                    cursor: pointer;
                }
            }
        }
    }
}
</style>
