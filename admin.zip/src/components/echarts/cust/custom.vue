<template>
    <!--客户查询-->
    <div class="art-custom">
        <el-row class="tool">
            <el-col :span="24">
                <div class="grid-content bg-purple toolbar">
                    <el-form :inline="true" :model="formInline" class="demo-form-inline custom-s">
                        <el-form-item label="" class="oinput2">
                            <el-input  v-model="formInline.qrcode" placeholder="二维码号" class="oinput o-user"></el-input>
                        </el-form-item>
                        <el-form-item label="" class="oinput2">
                            <el-input  v-model="formInline.username" placeholder="业务号码" class="oinput"></el-input>
                        </el-form-item>
                        <el-form-item label="" class="oinput2">
                            <el-input  v-model="formInline.workernum" placeholder="装维人员工号" class="oinput"></el-input>
                        </el-form-item>
                        <el-form-item label="">
                            <el-select v-model="formInline.orderType" placeholder="工单类型" clearable>
                                <el-option label="全部" value="5"></el-option>
                                <el-option label="新装工单" value="1"></el-option>
                                <el-option label="移机工单" value="2"></el-option>
                                <el-option label="修障工单" value="3"></el-option>
                            </el-select>
                        </el-form-item>
                        <el-form-item>
                            <el-button  type="primary" @click="onSubmit" class="serSub" icon="search">查询</el-button>
                        </el-form-item>
                        <el-form-item class="f-r">
                            <a :href="baseUrl+'qrcode/export?qrcode='+search.qrcode+'&userAccount='+search.userAccount+'&staffNo='+search.staffNo+'&orderType='+search.orderType" download="排障数据" class="download-cust"><el-button type="success" class="serSub" icon="upload2">导出</el-button></a>
                        </el-form-item>
                    </el-form>
                </div>
            </el-col>
        </el-row>
        <detlist :tableData="tableData" v-loading="loading" :changeData="changeData" :search="search" ref="fadet"></detlist>
    </div>
</template>
<script type="text/ecmascript-6">
    import detlist from './detlist.vue';
import axios from 'axios'
    export default {
        components: {
            detlist
        },
        data() {
            return {
                formInline: {
                    qrcode: '',
                    username:'',
                    workernum:'',
                    orderType:''
                },
                tableData:[],
                loading:false,
                title:'账号查询',
                search:{
                    qrcode: '',
                    userAccount: '',
                    staffNo:'',
                    orderType:''
                },
                baseUrl:''
            }
        },
        created () {
            document.title='账号查询';
            this.baseUrl=axios.defaults.baseURL;
        },
        methods: {
            //查询
            onSubmit() {
                var that=this;
                if (this.formInline.qrcode ===''&&this.formInline.username ===''&&this.formInline.workernum ===''&&this.formInline.orderType==='') {
                    that.$message({
                        type: 'info',
                        message: '查询条件不能为空'
                    });
                    return false;
                }
                if(this.formInline.orderType=='5'){
                    this.search={
                        qrcode: this.formInline.qrcode,
                        userAccount: this.formInline.username,
                        staffNo:this.formInline.workernum,
                        orderType:''
                    }
                }else{
                    this.search={
                        qrcode: this.formInline.qrcode,
                        userAccount: this.formInline.username,
                        staffNo:this.formInline.workernum,
                        orderType:this.formInline.orderType
                    }
                }
            },
            changeData (val) {
                this.tableData=val;
            },
            reload () {
                this.$router.push({
                    path: '/empty'
                })
            }
        }
    }
</script>
<style lang="less" rel="stylesheet/less" scoped>
    @import '../../../assets/css/property.less';
    .art-custom {
        padding: 0px 0px 20px 0px;
        /*padding: 20px 20px 0 20px;*/
        /*width: 100%;*/
        /*margin-left:230px;*/
        /*min-width:1008px;*/
        /*margin-top:60px;*/
        /*border: 1px solid #ccc;*/
        .search {
            padding: 10px 10px;
            width: 100%;
            height: 100px;
            .custom-s{
                margin: 30px 5px;
            }
            /*border: 1px solid #ccc;*/
            .oinput{
                width: 180px;
                vertical-align: middle;
            }
            .serSub{
                width: 100px;
        }
    }

        .el-row {
            margin-bottom: 20px;
            &:last-child {
                margin-bottom: 0;
            }
        }
        .tool{
            background-color: #f2f2f2;
            padding:10px;
            border-radius: 2px;
            margin: 10px 0px;

        }
        .el-col {
            border-radius: 4px;
            /*padding:10px;*/
        }
        .bg-purple-dark {
            background: #99a9bf;
        }
        .bg-purple {
            background: #f2f2f2;
        }
        .bread {
            padding-top: 2px;
            height: 24px;
            /*line-height: 50px;*/
            font-size: 14px;
        }
        .toolbar {
            /*background-color: #f2f2f2;*/
            /*padding: 10px;*/
            /*margin: 10px 0px;*/

            .add{
                font-size:14px;
            }
            .el-form-item {
                margin-bottom: 0px;
                /*.serSub{*/
                /*span{*/
                /*font-weight:200;*/
                /*font-size: 22px;*/
                /*color: #000;*/
                /*}*/
                /*}*/
            }
        }
        .serSub{
            white-space: nowrap;
            cursor: pointer;
            font-size: 14px;
            text-rendering: auto;
            letter-spacing: normal;
            word-spacing: normal;
            text-transform: none;
            text-indent: 0px;
            text-shadow: none;
            /*字体变细的原因*/
            -webkit-font-smoothing: antialiased;
        }
        .download-cust{
            display: inline-block;
            width: 120px;
            height: 36px;
            .el-button{
                width: 120px;
            }
        }
    }
</style>
