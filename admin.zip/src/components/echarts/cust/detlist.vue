<template>
    <div class="detlist" v-loading="loading">
        <el-table
                :data="tableData"
                border
                style="width: 100%">
            <!--<el-table-column-->
                   <!--type="index"-->
                    <!--label="序号"-->
                    <!--sortable-->
                    <!--width="100"-->
                   <!--align="center">-->
            <!--</el-table-column>-->
            <el-table-column
                    prop="qrcode"
                    label="二维码号"
                    width="230"
                    align="center">
            </el-table-column>
            <el-table-column
                    prop="username"
                    label="业务号码"
                    width="150"
                    align="center">
            </el-table-column>
            <el-table-column
                    prop="deviceMode"
                    label="设备型号"
                    width="130"
                    align="center">
            </el-table-column>
            <el-table-column
                    prop="workernum"
                    label="装维人员工号"
                    width="130"
                    align="center">
            </el-table-column>
            <el-table-column
                    prop="staffName"
                    label="装维人员姓名"
                    width="130"
                    align="center">
            </el-table-column>
            <el-table-column
                    prop="orderType"
                    label="工单类型"
                    width="130"
                    align="center">
            </el-table-column>
            <el-table-column
                    prop="date"
                    label="绑定时间"
                    :formatter="formatter"
                    align="center"
            >
            </el-table-column>
        </el-table>
        <page-bar :changePage="changePage" class="f-r" :pageMsg="pageMsg" v-if="pageIf"></page-bar>
    </div>
</template>
<script type="text/ecmascript-6">
    import pageBar from '../../pageBar.vue'
    import {Message} from 'element-ui';

    export default {
        data() {
            return {
                loading:false,
                tableData:[],
                pageIf:true,
                pageMsg: {
                    pageSum: '',
                    //总页码
                    pageList: [],
                    //单页数量
                    pageSize: 10,
                    //商品总数
                    totalCount: '',
                    list: []
                }
            }
        },
        components: {
            pageBar
        },
        props: {
            changeData:{
                type:Function,
                default:null
            } ,
            search:{
                type:Object,
                default:null
            }
        },
        watch :{
            'search' :{
                handler:function(val,oldval){
                    this.changePage(1);
                }
            }
        },
        created () {
            function getCookie(name) {
                var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");

                if (arr = document.cookie.match(reg))

                    return (arr[2]);
                else
                    return null;
            }

            function delCookie(name) {
                var exp = new Date();
                exp.setTime(exp.getTime() - 1);
                var cval = getCookie(name);
                if (cval != null)
                    document.cookie = name + "=" + cval + ";expires=" + exp.toGMTString();
            }
            //初始化列表
            this.loading = true;
            let msg={data:
                {"pageName":"qRCodeService",
                    "paginator":{"limit":10,"page":1},
                    "params":{"qrcode:":"","userAccount":"","staffNo":"","orderType":""}
                }};
            var that=this;
            that.axios.post('/page/list',JSON.stringify(msg))
                .then(res => {
                    if (res.data.resCode === '000000') {
                        //查询字段处理函数
                        this.loading = false;
                        let warningItem = res.data.repBody.list.map((value, index) => {
                            return {
                                qrcode: value.qrcode,//二维码串
                                username: value.userAccount,//用户账户
                                workernum: value.staffNo,//绑定人员工号
                                staffName: value.staffName,//绑定人员工号
                                deviceMode: value.deviceMode,//设备型号
                                date: (new Date(value.bindTime)).toLocaleString(),//绑定时间
                                orderType:this.transtion(value.orderType)//工单类型
                            }
                        });
                        this.tableData = warningItem;
                        //传给分页组件
                        this.pageMsg.totalCount = res.data.repBody.paginator.totalCount;
                        this.pageMsg.pageSum = res.data.repBody.paginator.totalPages;
                        for (let i = 1; i <= this.pageMsg.pageSum; i++) {
                            this.pageMsg.pageList.push(i);
                        }
                        this.pageMsg.list = this.pageMsg.pageList.slice(0, 5);
                    }else {
                        this.loading = false;

                        let message = res.data.resMsg
                        MessageBox.alert(message).then(action => {
                            delCookie('JSESSIONID');
                            localStorage.clear();
                            sessionStorage.clear();
                            that.$router.push('/login')
                        });
                    }
                })
                .catch(error => {
                        this.loading = false;
                        this.$message({
                            type: 'info',
                            message: '网络错误'
                        });
                })
        },
        methods: {
            transtion (orderType) {
                let result;
                if(orderType=='1'){
                    result='新装工单'
                }
                if(orderType=='2'){
                    result='移机工单'
                }
                if(orderType=='3'){
                    result='修障工单'
                }
                return result
            },
            formatter(row, column) {
                return row.date;
            },
            filterTag(value, row) {
                return row.tag === value;
            },
            handleEdit(index, row) {
            },
            handleDelete(index, row) {
                this.tableData.splice(index, 1);
            },
            //渲染商品列表
            changePage (num,list) {
                this.loading = true;
                this.pageMsg={
                    pageSum: '',
                    //总页码
                    pageList: [],
                    //单页数量
                    pageSize: 10,
                    //商品总数
                    totalCount: '',
                    list: []
                };
                let msg={data:
                    {"pageName":"qRCodeService",
                        "paginator":{"limit":10,"page":num},
                    "params":this.search
                    }};
                if(num=='1'){
                    this.pageIf=false;
                }
                var that = this;
                that.axios.post('/page/list',JSON.stringify(msg))
                    .then(res => {
                if (res.data.resCode === '000000') {
                    //渲染处理函数
                    this.loading = false;

                    let warningItem = res.data.repBody.list.map((value, index) => {
                            return {
                                qrcode: value.qrcode,//二维码串
                                username: value.userAccount,//用户账户
                                workernum: value.staffNo,//绑定人员工号
                                staffName: value.staffName,//绑定人员工号
                                deviceMode: value.deviceMode,//设备型号
                                date: (new Date(value.bindTime)).toLocaleString(),//绑定时间
                                orderType:this.transtion(value.orderType)//工单类型
                            }
                        });
                    this.tableData = warningItem;
                    if(num=='1'){
                        this.pageIf=true;
                    }
                    this.pageMsg.totalCount = res.data.repBody.paginator.totalCount;
                    this.pageMsg.pageSum = res.data.repBody.paginator.totalPages;
                    for (let i = 1; i <= this.pageMsg.pageSum; i++) {
                        this.pageMsg.pageList.push(i);
                    }
                    if((num - 1) % 5 === 0){
                        this.pageMsg.list = this.pageMsg.pageList.slice(num - 1, num + 4);
                    }else if(num==1){
                        this.pageMsg.list = this.pageMsg.pageList.slice(0, 5);
                    }else if(num==this.pageMsg.pageSum&&(num % 5) === 0){
                        this.pageMsg.list = this.pageMsg.pageList.slice(num - 5, num);
                    }else if(num==this.pageMsg.pageSum&&(num % 5) !== 0){
                        let nn=num%5;
                        this.pageMsg.list = this.pageMsg.pageList.slice(num - nn, num);
                    }else if((num) % 5 === 0){
                        this.pageMsg.list = this.pageMsg.pageList.slice(num - 5, num);
                    }else{
                        this.pageMsg.list = list
                    }
                }else{
                    this.loading = false;
                    this.$message({
                        type: 'info',
                        message: '网络错误'
                    });
                }
                })
            .catch(error => {
                this.loading = false;
                this.$message({
                    type: 'info',
                    message: '网络错误'
                });
            });
            }
        }
    }
</script>
<style lang="less" rel="stylesheet/less" scoped>
    @import '../../../assets/css/property.less';
    .detlist {
        width: 100%;
    }
</style>
