<template>
    <div class="evaluate">
        <el-row class="tool">
            <el-col :span="24">
                <div class="grid-content bg-purple toolbar">
                    <el-form :inline="true" :model="formInline" class="demo-form-inline">
                        <el-form-item label="" class="oinput3">
                            <el-select v-model="formInline.areaCode" placeholder="选择区域" clearable class="oinput">
                                <el-option
                                        v-for="item in cities"
                                        :key="item.areaName"
                                        :label="item.areaName"
                                        :value="item.areaCode"
                                >
                                    <span style="float: left">{{ item.areaName }}</span>
                                    <span style="float: right; color: #8492a6; font-size: 13px">{{ item.areaCode }}</span>
                                </el-option>
                            </el-select>
                        </el-form-item>
                        <el-form-item label="" class="oinput2">
                            <div class="block">
                                <el-date-picker
                                        v-model="value4"
                                        type="month"
                                        placeholder="选择月"
                                        align="right"
                                        :picker-options="pickerOptions"
                                        :editable=false
                                        @change="(value) => changeHandler2(value, value4)">
                                </el-date-picker>
                            </div>
                        </el-form-item>
                        <el-form-item label="" class="oinput2">
                            <el-input v-model="formInline.staffNo" placeholder="装维人员工号" class="oinput"></el-input>
                        </el-form-item>
                        <el-form-item>
                            <el-button type="primary" @click="onSubmit" class="serSub" icon="search">查询</el-button>
                        </el-form-item>
                    </el-form>
                </div>
            </el-col>
        </el-row>
        <!--table里的tableData就是遍历的数组-->
        <!--prop就是数组对象里对应的数据-->
        <el-table
                :data="tableData"
                style="width: 100%;color:#5d5d61;font-size: 13px"
                v-loading="loading">
            <el-table-column
                    align="center"
                    prop="rankOrder"
                    label="名次"
                    width="110">
            </el-table-column>
            <el-table-column
                    align="center"
                    prop="staffName"
                    label="装维人员姓名"
                    width="130">
            </el-table-column>
            <el-table-column
                    align="center"
                    prop="staffNo"
                    label="工号"
                    width="100">
            </el-table-column>
            <el-table-column
                    align="center"
                    prop="orderCount"
                    label="工单数量"
                    width="100">
            </el-table-column>
            <el-table-column
                    align="center"
                    prop="scoreAvg"
                    label="评分(分)"
                    width="210">
            </el-table-column>
            <el-table-column
                    align="center"
                    label="排名趋势"
                    width="210">
                <template scope="scope" align="center">
                    <span style="vertical-align: middle">{{ scope.row.rankStatus }}</span>
                    <img style="vertical-align: middle" v-if="scope.row.up" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAANCAMAAACn6Q83AAAAaVBMVEXyVlLyVlLyVlLyVlLyVlLyVlLyVlLyVlLyVlLyVlLyVlLyVlLyVlLyVlLyVlLyVlLyVlLyVlLyVlLyVlLyVlLyVlLyVlLyVlLyVlLyVlLyVlLyVlLyVlLyVlLyVlLyVlLyVlLyVlLyVlK+qHS/AAAAInRSTlMAAQIDBgkPGiYzNTk/RUlMVnByc3SCksbP2t3i5ent8fn7AzJUgQAAAFFJREFUCNd9zTkCgkAAwMCAK5cnyKmCbv7/SIu1JtV0AcgeQyDV6ph0+qp3gPKt+qkgTKo6H+n813NbompcLkCt2gBQqBY7zFfdDml3fr6uwA9uiAiIID8Y2AAAAABJRU5ErkJggg==">
                    <img style="vertical-align: middle" v-else src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAANCAMAAACn6Q83AAAAVFBMVEVJyGtJyGtJyGtJyGtJyGtJyGtJyGtJyGtJyGtJyGtJyGtJyGtJyGtJyGtJyGtJyGtJyGtJyGtJyGtJyGtJyGtJyGtJyGtJyGtJyGtJyGtJyGtJyGsb5xkAAAAAG3RSTlMABgocKjI0NjxAQkVHTV+coMnV3eHi5ens9f5Mtxq7AAAARUlEQVQIHQXBBwLBAAAAsdiqtYty//+nBMbXfAS86wmoAlQBqoBd1R6HpaqWwamqauJWVVesH1X3FWy/9dkAl34jwHmCP75ZBk5BLmFuAAAAAElFTkSuQmCC">
                </template>
            </el-table-column>
            <el-table-column
                    prop="areaName"
                    label="所属区域"
                    align="center">
            </el-table-column>
        </el-table>
        <page-bar :changePage="changePage" class="f-r clearfix" :pageMsg="pageMsg"></page-bar>
        <div class="control-bar-wrapper" id="ControlBarWrapper">
            <div id="ControlBar" class="control-bar clearfix">
                <div id="DateSelectBar" class="date-select-bar clearfix">
                    <div class="d-ib">
                        <span :class="{cur:isDate===0}" class="isA" @click="isDate=0;value7=''">最近一周</span><span
                            class="seprator"></span>
                        <span :class="{cur:isDate===1}" class="isA" @click="isDate=1;value7=''">最近30天</span><span
                            class="seprator"></span>
                        <span :class="{cur:isDate===2}" class="isA" @click="isDate=2;value7=''">最近90天</span><span
                            class="seprator"></span>
                        <div class="block d-ib">
                            <el-date-picker
                                    v-model="value7"
                                    type="daterange"
                                    align="right"
                                    placeholder="选择日期范围"
                                    :picker-options="pickerOptions2"
                                    size="small"
                                    :editable=false
                                    @change="(value) => changeHandler(value, value7)"
                            >
                            </el-date-picker>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="getupbar3"></div>
    </div>
</template>
<script type="text/ecmascript-6">
    import pageBar from '../pageBar.vue'
    import {MessageBox} from 'element-ui';
    import {Message} from 'element-ui';
    import echarts from 'echarts';
    export default {
        data() {
            return {
                chart: null,
                //开始时间
                startTime:'',
                //结束时间
                endTime:'',
                loading: false,
                tableData: [],
                //绑定的时间
                value4: '',
                //排名趋势
                up:'',
                pageMsg: {
                    pageSum: '',
                    //总页码
                    pageList: [],
                    //单页数量
                    pageSize: 10,
                    //商品总数
                    totalCount: '',
                    list: []
                },
                formInline: {
                    staffNo: '',
                    areaCode: '',
                    time:{startTime:'',endTime:''}
                },
                search: {
                    "staffNo:": "",
                    "starLevel": "",
                    "areaCode":''
                },
                cities: [],
                //日期
                isDate: 0,
                value7: '',
                //列表日期控件
                pickerOptions: {
                    //禁用状态,大于当前日期则禁用
                    disabledDate (time) {
                        return time.getTime() > Date.now()
                    }
                },
                //图表日期控件
                pickerOptions2: {
                    //禁用状态,大于当前日期则禁用
                    disabledDate (time) {
                        return time.getTime() > Date.now()
                    },
                    shortcuts: [{
                        text: '最近一周',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
                            picker.$emit('pick', [start, end]);
                        }
                    }, {
                        text: '最近30天',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
                            picker.$emit('pick', [start, end]);
                        }
                    },
                        {
                            text: '最近90天',
                            onClick(picker) {
                                const end = new Date();
                                const start = new Date();
                                start.setTime(start.getTime() - 3600 * 1000 * 24 * 90);
                                picker.$emit('pick', [start, end]);
                            }
                        }]
                },
                bar:{
                    date:{
                        startTime:'',endTime:''
                    },
                    areaEva:{
                        areaName: [], staffAvg: []
                    }
                },
                addUser: {areaName: [], staffAvg: []}
            }
        },
        components: {
            pageBar
        },
        watch :{
            'isDate' (newVal, oldVal) {
                if (newVal !== '' && newVal !== null) {
                    this.bar.areaEva.areaName = [];
                    this.bar.areaEva.staffAvg = [];
                    const end = new Date();
                    const start = new Date();
                    switch (newVal) {
                        case 0:
                            //周
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
                            this.bar.date.startTime = this.getTaskTime(start);
                            this.bar.date.endTime = this.getTaskTime(end);
                            this.increase(this.bar.date.startTime, this.bar.date.endTime)
                            break;
                        case 1:
                            //30天
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
                            this.bar.date.startTime = this.getTaskTime(start);
                            this.bar.date.endTime = this.getTaskTime(end);
                            this.increase(this.bar.date.startTime, this.bar.date.endTime);
                            break;
                        case 2:
                            //30天
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 90);
                            this.bar.date.startTime = this.getTaskTime(start);
                            this.bar.date.endTime = this.getTaskTime(end);
                            this.increase(this.bar.date.startTime,this.bar.date.endTime);
                            break;
                        default:
                            break
                    }

                }
            },
        },
        created () {
            function getCookie(name) {
                var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");

                if (arr = document.cookie.match(reg))

                    return (arr[2]);
                else
                    return null;
            }

            function delCookie(name) {
                var exp = new Date();
                exp.setTime(exp.getTime() - 1);
                var cval = getCookie(name);
                if (cval != null)
                    document.cookie = name + "=" + cval + ";expires=" + exp.toGMTString();
            }
            this.loading = true;
//            {"data":{"pageName":"","paginator":{"limit":10,"page":1},"params":{"staffNo":"75675"//工号,"time":{"startTime":"2017-02-01 00:00:00","endTime":"2017-03-01 00:00:00"}//选择月的时间,"areaCode":"0913"//区域编号}}}
            let msg = {
                data: {
                    "pageName": 'evaluationMonthService',
                    "paginator": {"limit": 10, "page": 1},
                    "params": {
                        areaCode: '',
                        staffNo: '',
                        time:{"startTime":"","endTime":""}
                    }
                }
            };



            var that = this;

            that.axios.post('/page/list', JSON.stringify(msg))
                .then(res => {
                    if (res.data.resCode === '000000') {
                        //查询字段处理函数
                        this.loading = false;
                        let warningItem = res.data.repBody.list.map((value, index) => {
                            return {
                                staffName: value.staffName || '',//装维人员姓名
                                scoreAvg:value.scoreAvg || '',//评分
                                staffNo: value.staffNo || '',//装维人员工号
                                orderCount: value.orderCount || '',//工单数
                                rankStatus: Math.abs(Number(value.rankStatus)) || '',//排名趋势,取绝对值
                                areaName: value.areaName || '',//区域
                                rankOrder: value.rankOrder || '',//排名
                                up:that.transition(value.rankStatus)//上升下降图标
                            }
                        });
                        this.tableData = warningItem;
                        //传给分页组件
                        this.pageMsg.totalCount=5;
                        this.pageMsg.pageSum=1
                        for (let i = 1; i <= this.pageMsg.pageSum; i++) {
                            this.pageMsg.pageList.push(i);
                        }
                        this.pageMsg.list = this.pageMsg.pageList.slice(0, 5);
                    }
                    else if (res.data.resCode === '100002') {
                        this.loading = false;
                        let message = res.data.resMsg
                        this.$message({
                            type: 'info',
                            message: message
                        });
                    } else {
                        this.loading = false;
                        let message = res.data.resMsg
                        this.$message({
                            type: 'info',
                            message: message
                        });
                    }
                })
                .catch(error => {
                    this.loading = false;
            let message = res.data.resMsg
            this.$message({
                type: 'info',
                message: message
            });
                });
        },
        mounted() {
            this.$nextTick(function () {
                this.area();
                var end = new Date();
                var start = new Date();
                start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
                this.bar.date.startTime = this.getTaskTime(start);
                this.bar.date.endTime = this.getTaskTime(end);
                this.increase(this.bar.date.startTime, this.bar.date.endTime);
                this.drawbar('getupbar3');
                var that = this;
                var resizeTimer = null;
                window.onresize = function () {
                    if (resizeTimer) clearTimeout(resizeTimer);
                    resizeTimer = setTimeout(function () {
                        that.drawbar('getupbar3');
                    }, 100);
                }
            });
        },
        methods: {
            //渲染列表
            changePage (num,list) {
                this.loading = true;
                this.pageMsg = {
                    pageSum: '',
                    //总页码
                    pageList: [],
                    //单页数量
                    pageSize: 10,
                    //商品总数
                    totalCount: '',
                    list: []
                };
                let msg = {
                    data: {
                        //接口出来了记得改
                        "pageName": 'evaluationMonthService',
                        "paginator": {"limit": 10, "page": num},
                        "params": this.search
                    }
                };
                var that = this;
                that.axios.post('/page/list', JSON.stringify(msg))
                    .then(res => {
                        if (res.data.resCode === '000000') {
                            //渲染处理函数
                            this.loading = false;
                            let warningItem = res.data.repBody.list.map((value, index) => {
                                return {
                                    staffName: value.staffName || '',//装维人员姓名
                                    scoreAvg:value.scoreAvg || '',//评分
                                    staffNo: value.staffNo || '',//装维人员工号
                                    orderCount: value.orderCount || '',//工单数
                                    rankStatus: Math.abs(Number(value.rankStatus)) || '',//排名趋势
                                    areaName: value.areaName || '',//区域
                                    rankOrder: value.rankOrder || '',//排名
                                    up:that.transition(value.rankStatus)
                                }
                            });
                            this.tableData = warningItem;
                            this.pageMsg.totalCount = res.data.repBody.paginator.totalCount;
                            this.pageMsg.pageSum = res.data.repBody.paginator.totalPages;
                            for (let i = 1; i <= this.pageMsg.pageSum; i++) {
                                this.pageMsg.pageList.push(i);
                            }
                            if((num - 1) % 5 === 0){
                                this.pageMsg.list = this.pageMsg.pageList.slice(num - 1, num + 4);
                            }else if(num==1){
                                this.pageMsg.list = this.pageMsg.pageList.slice(0, 5);
                            }else if(num==this.pageMsg.pageSum&&(num % 5) === 0){
                                this.pageMsg.list = this.pageMsg.pageList.slice(num - 5, num);
                            }else if(num==this.pageMsg.pageSum&&(num % 5) !== 0){
                                let nn=num%5;
                                this.pageMsg.list = this.pageMsg.pageList.slice(num - nn, num);
                            }else if((num) % 5 === 0){
                                this.pageMsg.list = this.pageMsg.pageList.slice(num - 5, num);
                            }else{
                                this.pageMsg.list = list
                            }
                        }
                    })
                    .catch(error => {
                        this.loading = false;
                let message = res.data.resMsg
                this.$message({
                    type: 'info',
                    message: message
                });
                    });
            },
            //判断
            transition (val) {
                let result;
                if (Number(val) >= 0) {
                   result=true
                }else{
                    result=false
                }
                return result
            },
            //判断业务类型
            business (val) {
                let business;
                if (val === '2') {
                    business = '宽带'
                }
                if (val === '3') {
                    business = 'ITV'
                }
                return business
            },
            //判断故障类型
            fault (val) {
                let fault;
                if (val === '0') {
                    fault = '无法上网'
                }
                if (val === '1') {
                    fault = '网速慢'
                }
                return fault
            },
            //评价排名列表查询
            onSubmit () {
                var that = this;
                if (this.formInline.staffNo === '' && this.formInline.time.startTime === '' && this.formInline.areaCode === '') {
                    that.$message({
                        type: 'info',
                        message: '查询条件不能为空'
                    });
                    return false;
                }
                if(this.formInline.areaCode=='--'){
                    this.search = {
                        staffNo: this.formInline.staffNo,
                        time: {startTime:this.formInline.time.startTime,endTime:this.formInline.time.endTime},
                        areaCode: ''
                    };
                }else{
                    this.search = {
                        staffNo: this.formInline.staffNo,
                        time: {startTime:this.formInline.time.startTime,endTime:this.formInline.time.endTime},
                        areaCode: this.formInline.areaCode
                    };
                }

                this.changePage(1);
            },
            drawbar(id) {
                this.chart = echarts.init(document.getElementById(id), 'vintage');
                this.chart.setOption({
                    title: {
                        text: '各地区装维人员评分情况',
                        subtext: ''
                    },
                    tooltip: {
                        trigger: 'axis'
                    },
                    legend: {
                        data: ['评分']
                    },
                    toolbox: {
                        show: true,
                        feature: {
                            dataView: {show: true, readOnly: false},
                            magicType: {show: true, type: ['line', 'bar']},
                            restore: {show: true},
                            saveAsImage: {show: true}
                        }
                    },
                    calculable: true,
                    xAxis: [
                        {
                            type: 'category',
                            data: this.bar.areaEva.areaName,
                            name:'地区'
                        }
                    ],
                    yAxis: [
                        {
                            type: 'value',
                            name:'评分',
                            min:5,
                            max:5
                        }
                    ],
                    series: [
                        {
                            name: '评分',
                            type: 'bar',
                            barWidth : 30,
                            data: this.bar.areaEva.staffAvg,
                            markPoint: {
                                data: [
                                    {type: 'max', name: '最大值'},
                                    {type: 'min', name: '最小值'}
                                ]
                            },
                            markLine: {
                                data: [
                                    {type: 'average', name: '平均值'}
                                ]
                            }
                        }
                    ]
                })
            },
            //月时间格式化
            getNextMouth (year,month){
                var that=this;
                var new_year = year;  //取当前的年份
                var new_month = month++;//取下一个月的第一天，方便计算（最后一天不固定）
                if(month>12)      //如果当前大于12月，则年份转到下一年
                {
                    new_month -=12;    //月份减
                    new_year++;      //年份增
                }
                var new_date = new Date(new_year,new_month,1);        //取当年当月中的第一天
                return that.getTaskTime(new_date)
            },
            //入参时间格式化
            getTaskTime (strDate) {
                if (null == strDate || "" == strDate) {
                    return "";
                }
                var dateStr = (strDate.toString()).trim().split(" ");
                var strGMT = dateStr[0] + " " + dateStr[1] + " " + dateStr[2] + " " + dateStr[5] + " " + dateStr[3] + " GMT+0800";
                var date = new Date(Date.parse(strGMT));
                var y = date.getFullYear();
                var m = date.getMonth() + 1;
                m = m < 10 ? ('0' + m) : m;
                var d = date.getDate();
                d = d < 10 ? ('0' + d) : d;
                var h = date.getHours();
                h = h < 10 ? ('0' + h) : h;
                var minute = date.getMinutes();
                minute = minute < 10 ? ('0' + minute) : minute;
                var second = date.getSeconds();
                second = second < 10 ? ('0' + second) : second;
                return y + "-" + m + "-" + d + " " + h + ":" + minute + ":" + second;
            },
            //根据时间调整
            increase (startTime, endTime) {
                var vm = this;
                let mesg = {
                    data: {
                        "startTime": startTime,
                        "endTime": endTime
                    }
                };
                vm.axios.post('/evaluate/rptAreaTrade', JSON.stringify(mesg))
                    .then(res => {
                        if (res.data.resCode === '000000') {
                            //查询字段处理函数
                            this.loading = false;
                            for (var key in res.data.repBody) {
                                (vm.bar.areaEva.areaName).push((res.data.repBody)[key].areaName);
                                (vm.bar.areaEva.staffAvg).push((res.data.repBody)[key].staffAvg);
                            }
                            vm.drawbar('getupbar3');
                        }
                        else if (res.data.resCode === '100002') {
                            this.loading = false;
                            let message = res.data.resMsg
                            this.$message({
                                type: 'info',
                                message: message
                            });
                        } else {
                            this.loading = false;
                            let message = res.data.resMsg
                            this.$message({
                                type: 'info',
                                message: message
                            });
                        }
                    })
                    .catch(error => {
                        this.loading=false;
                    let message = res.data.resMsg
                    this.$message({
                    type: 'info',
                    message: message
                });
                    });
            },
            //评分柱状图日期选择器
            changeHandler (value, value7) {
                this.bar.areaEva.areaName = [];
                this.bar.areaEva.staffAvg = [];
                if(value!==''&&value!==null){
                    this.isDate = '';
                    this.bar.date.startTime = this.getTaskTime(value7[0]);
                    this.bar.date.endTime = this.getTaskTime(value7[1]);
                    //发ajax向后台请求数据
                    this.increase(this.bar.date.startTime, this.bar.date.endTime)
                }
            },
            //评分表格日期选择器(月份选择)
            changeHandler2 (value, value4) {
                //格式:选择当月1号到下月1号
                var year = value4.getFullYear();//年
                var month = value4.getMonth()+1;//月
                if (month<10){
                    month = "0"+month;
                }
                this.formInline.time.startTime = this.getTaskTime(value4);//起始时间
                this.formInline.time.endTime=this.getNextMouth(year,month);//结束时间
            },
            //区域初始化
            area () {
                var vm = this;
                let mesg = {
                    data: {}
                };
                vm.axios.post('/areaCode/findAll', JSON.stringify(mesg))
                    .then(res => {
                        if (res.data.resCode === '000000') {
                            //查询字段处理函数
                            this.loading = false;
                            this.cities=res.data.repBody;
                            this.cities.unshift({areaName:'所有区域',areaCode:'--'})
                        }
                        else if (res.data.resCode === '100002') {
                            this.loading = false;
                            let message = res.data.resMsg
                            this.$message({
                                type: 'info',
                                message: message
                            });
                        } else {
                            this.loading = false;
                            let message = res.data.resMsg
                            this.$message({
                                type: 'info',
                                message: message
                            });
                        }
                    })
                    .catch(error => {
                    this.loading = false;
                let message = res.data.resMsg
                this.$message({
                    type: 'info',
                    message: message
                });
                    });


            }
        }
    }
</script>
<style lang="less" rel="stylesheet/less" scoped>
    @import '../../assets/css/property.less';

    .evaluate {
        width: 100%;
        .oinput {
            width: 169px;
        }
        .el-row {
            margin-bottom: 20px;
            &:last-child {
                margin-bottom: 0;
            }
        }
        .tool {
            background-color: #f2f2f2;
            padding: 10px;
            border-radius: 2px;
            margin: 10px 0px;
        }
        .el-col {
            border-radius: 4px;
            /*padding:10px;*/
        }
        .bg-purple-dark {
            background: #99a9bf;
        }
        .bg-purple {
            background: #f2f2f2;
        }
        .bread {
            padding-top: 2px;
            height: 24px;
            /*line-height: 50px;*/
            font-size: 14px;
            ul li[data-v-1db56538]:first-child {
                border-top-left-radius: 5px;
                border-bottom-left-radius: 5px;
            }
            ul li + li[data-v-1db56538] {
                margin-left: -1px;
            }
            ul li[data-v-1db56538]:last-child {
                border-top-right-radius: 5px;
                border-bottom-right-radius: 5px;
            }
            ul {
                li[data-v-1db56538] {
                    display: inline-block;
                    min-width: 59px;
                    padding: 2px 10px;
                    line-height: 20px;
                    text-align: center;
                    font-size: 11px;
                    transition: all .3s cubic-bezier(.645, .045, .355, 1);
                    transition-property: all;
                    transition-duration: 0.3s;
                    transition-timing-function: cubic-bezier(0.645, 0.045, 0.355, 1);
                    transition-delay: initial;
                    cursor: pointer;
                }
                li[data-v-1db56538]:hover {
                    background: #1278f6 !important;
                    color: #fff !important;
                }
            }
        }
        .toolbar {

            .add {
                font-size: 14px;
            }
            .el-form-item {
                margin-bottom: 0px;

            }
        }
        .serSub {
            white-space: nowrap;
            cursor: pointer;
            font-size: 14px;
            text-rendering: auto;
            letter-spacing: normal;
            word-spacing: normal;
            text-transform: none;
            text-indent: 0px;
            text-shadow: none;
            /*字体变细的原因*/
            -webkit-font-smoothing: antialiased;
        }
        #getupbar3 {
            position: relative;
            /*width: 90%;*/
            /*width: 1049px;*/
            /*width: 60%;*/
            /*left: 50%;*/
            height: 500px;
            /*margin-left: -45%;*/
            /*box-shadow: 0 0 10px #BF382A;*/
            /*border-radius: 10px;*/
            -webkit-tap-highlight-color: transparent;
            user-select: none;
        }
        thead{
            .is-leaf {
                .cell {
                    color: #5d5d61!important;
                }
            }
        }
        .control-bar-wrapper{
            margin-top: 60px;
        }

    }

    /*@media screen and (max-width: 470px) {*/
    /*#getuppie {*/
    /*height: 500px;*/
    /*}*/


</style>
