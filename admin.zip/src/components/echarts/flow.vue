<template>
    <div>
        <el-row class="tool">
            <el-col :span="24">
                <div class="grid-content bg-purple toolbar">
                    <el-form :inline="true" :model="formInline" class="demo-form-inline">
                      <el-form-item label="" v-show="false" class="oinput3">
                          <el-select v-model="formInline.areaCode" placeholder="所属分公司" clearable>
                              <el-option v-for="(item,index) in filialeArr" :label="item.areaName" :value="item.areaCode"></el-option>
                          </el-select>
                      </el-form-item>
                        <el-form-item label="" class="oinput2">
                          <div class="block d-ib defaultBlock">
                                <el-date-picker
                                        v-model="valueForm"
                                        type="daterange"
                                        align="right"
                                        placeholder=""
                                        :picker-options="pickerOptions"
                                        :editable=false
                                        @change="(value) => changeHandlerForm(value, valueForm)"
                                >
                                </el-date-picker>
                                <div class="defaultDate" v-show="isDefault">{{defaultDate}}</div>
                            </div>
                          </el-form-item>
                          <el-form-item label="" class="oinput3">
                              <el-form-item label="" class="oinput2" style="margin-right: 6px">
                                  <el-input v-model="formInline.staffNo" placeholder="请输入装维人员工号" class="oinput" style="width: 160px"></el-input>
                              </el-form-item>
                          </el-form-item>
                        <el-form-item>
                            <el-button type="primary" @click="onSearch" class="serSub" icon="search">查询</el-button>
                        </el-form-item>
                        <el-form-item class="f-r">
                            <a :href="baseUrl+'accessRpt/export?staffNo='+search.staffNo+'&startTime='+search.startTime+'&endTime='+search.endTime" download="流量数据" class="download-flow"><el-button type="success" class="serSub" icon="upload2">导出</el-button></a>
                        </el-form-item>
                        <el-form-item class="f-r" style="margin-right: 12px"><el-tag type="danger" style="padding: 0 12px">累积绑码用户数:{{total.bindTotal}}</el-tag><el-tag type="danger" style="margin-left: 10px;padding: 0 12px">累积活跃用户数:{{total.activeTotal}}</el-tag><el-tag type="danger" style="margin-left: 10px;padding: 0 12px">装维人员数量:{{total.staffTotal}}</el-tag></el-form-item>
                    </el-form>
                </div>
            </el-col>
        </el-row>
        <!--table里的tableData就是遍历的数组-->
        <!--prop就是数组对象里对应的数据-->
        <el-table
                :data="tableData"
                style="width: 100%;color:#5d5d61;font-size: 13px"
                border
                v-loading="loading">
            <el-table-column
                    align="center"
                    prop="staffNo"
                    label="装维人员工号"
                    width="140">
            </el-table-column>
            <el-table-column
                    align="center"
                    prop="staffName"
                    label="装维人员姓名"
                    width="140">
            </el-table-column>
            <el-table-column
                    v-if="false"
                    align="center"
                    prop="filialeName"
                    label="分公司"
                    width="140">
            </el-table-column>
            <el-table-column
                    align="center"
                    prop="bindTotal"
                    label="累积绑码用户数"
                    width="140">
            </el-table-column>
            <el-table-column
                    align="center"
                    prop="bindIncre"
                    label="今日新增绑码用户数"
                    width="160">
            </el-table-column>
            <el-table-column
                    align="center"
                    prop="activeTotal"
                    label="累积活跃用户数(UV)"
                    width="160">
            </el-table-column>
            <el-table-column
                    align="center"
                    prop="activeIncre"
                    label="今日新增活跃用户数"
                    width="160">
            </el-table-column>
            <el-table-column
                    align="center"
                    prop="statTime"
                    label="日期(每小时统计一次)"
            >
            </el-table-column>
        </el-table>
        <page-bar :changePage="changePage" class="f-r clearfix" :pageMsg="pageMsg" v-if="pageIf"></page-bar>
        <div class="control-bar-wrapper top2" id="ControlBarWrapper">
            <div id="ControlBar" class="control-bar clearfix" style="height: 46px">
                <div id="DateSelectBar" class="date-select-bar clearfix flow-main">
                    <div class="d-ib flow-a">
                        <span :class="{cur:isDate===0}" class="isA" @click="isDate=0;value7=''">最近7天</span><span
                            class="seprator"></span>
                        <span :class="{cur:isDate===1}" class="isA" @click="isDate=1;value7=''">最近30天</span><span
                            class="seprator"></span>
                        <div class="block d-ib defaultInline">
                            <el-date-picker
                                    v-model="value7"
                                    type="daterange"
                                    align="right"
                                    placeholder=""
                                    :picker-options="pickerOptions2"
                                    size="small"
                                    :editable=false
                                    @change="(value) => changeHandler(value, value7)"
                            >
                            </el-date-picker>
                            <div class="defaultTime" v-show="isDefaultTime">{{defaultTime}}</div>
                        </div>
                    </div><el-select v-model="bar.areaCode" :disabled="!isfilialeshow" placeholder="请选择分公司" size="small" clearable class="flow-b">
                        <el-option
                                v-for="item in cities"
                                :key="item.areaName"
                                :label="item.areaName"
                                :value="item.areaCode"
                             >
                            <span style="float: left">{{ item.areaName }}</span>
                            <span style="float: right; color: #8492a6; font-size: 13px">{{ item.areaCode }}</span>
                        </el-option>
                    </el-select>
                </div>
            </div>
        </div>
        <div id="getupbar"></div>
    </div>
</template>
<script>
    import echarts from 'echarts';
    import { MessageBox } from 'element-ui';
    import {Message} from 'element-ui';
    import '../../../node_modules/echarts/theme/vintage.js';
    import pageBar from '../pageBar.vue'
    import axios from 'axios'
    export default {
        data() {
            return {
                //加载图标
                loading: false,
                //
                pageIf:true,
                chart: null,
                baseUrl:'',
                pageMsg: {
                    pageSum: '',
                    //总页码
                    pageList: [],
                    //单页数量
                    pageSize: 10,
                    //商品总数
                    totalCount: '',
                    list: []
                },
                total:{bindTotal:'',activeTotal:'',staffTotal:''},
                tableData:[],
                formInline: {
                    staffNo: '',
                    startTime:'',
                    endTime:''
                },
                search: {
                    staffNo: '',
                    startTime:'',
                    endTime:''
                },
                isDefault:true,
                isDefaultTime:true,
                defaultDate:'',
                defaultTime:'',
                valueForm:['',''],
                //日期控件
                pickerOptions: {
                    //禁用状态,大于当前日期则禁用
                    disabledDate (time) {
                        return time.getTime() > Date.now()
                    },
                    shortcuts: [{
                        text: '最近一周',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
                            picker.$emit('pick', [start, end]);
                        }
                    }, {
                        text: '最近30天',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
                            picker.$emit('pick', [start, end]);
                        }
                    }]
                },
                pickerOptions2: {
                    //禁用状态,大于当前日期则禁用
                    disabledDate (time) {
                        return time.getTime() > Date.now()
                    },
                    shortcuts: [{
                        text: '最近一周',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
                            picker.$emit('pick', [start, end]);
                        }
                    }, {
                        text: '最近30天',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
                            picker.$emit('pick', [start, end]);
                        }
                    }]
                },
                //日期绑定
                value7: '',
                //快捷选择日期
                isDate: 0,
                //区域数组
                cities: [],
                //流量数据数组
                flows: [
                ],
                //图表数据
                bar:{
                    startTime:'',//开始日期
                    endTime:'',//结束日期
                    areaCode:'',//区域id
                    data:{counts: [], scanTimes: []}//日期及数据数组
                },
                filialeArr: []
            }
        },
        components: {
            pageBar
        },
        created () {
            this.loading = true;
            if(localStorage.getItem("areaCodeNum") > 1){
                this.isfilialeshow = true;
            }else{
              this.isfilialeshow = false;
              let content = JSON.parse(localStorage.getItem("userInfo"))
              this.bar.areaCode = content.userInfo.areaCode
            }
            this.baseUrl=axios.defaults.baseURL;
            this.defaultDate=this.getTheDate(new Date())+' - '+this.getTheDate(new Date());
            var start = new Date();
            var end = new Date();
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
            this.defaultTime=this.getTheDate(start)+' - '+this.getTheDate(end);
            this.formInline.startTime = this.getTheDate(new Date());
            this.formInline.endTime = this.getTheDate(new Date());
            this.search.startTime = this.getTheDate(new Date());
            this.search.endTime = this.getTheDate(new Date());
            this.getRegion();
            //总数
            var that = this;
            let mesg = {
                data: {}
            };
            that.axios.post('/accessRpt/total')
                .then(res => {
                    if (res.data.resCode === '000000') {
                        //查询字段处理函数
                        this.total=res.data.repBody
                    }else{
                        let mes = res.data.resMsg
                        this.$message({
                            type: 'info',
                            message: mes
                        });
                    }

                })
                .catch(error => {
                    let mes = res.data.resMsg
                    this.$message({
                        type: 'info',
                        message: mes
                    });
                });

            let msg = {
                data: {
                    "pageName": 'accessRptService',
                    "paginator": {"limit": 10, "page": 1},
                    "params": this.formInline
                }
            };
            that.axios.post('/page/list', JSON.stringify(msg))
                .then(res => {
                    if (res.data.resCode === '000000') {
                        //查询字段处理函数
                        this.loading = false;
                        let warningItem = res.data.repBody.list.map((value, index) => {
                            return {
                                staffNo     : value.staffNo || '',//装维人员工号
                                staffName   :value.staffName,//装维人员姓名
                                bindTotal   : value.bindTotal,//总共绑码用户数
                                bindIncre   : value.bindIncre,//新增绑码用户数
                                activeTotal : value.activeTotal,//活跃用户数
                                activeIncre : value.activeIncre,//新增活跃用户数
                                filialeName : value.areaName,//分公司
                                statTime    : this.getMyDate(value.statTime)||''//日期
                            }
                        });
                        this.tableData = warningItem;
                        //传给分页组件
                        this.pageMsg.totalCount = res.data.repBody.paginator.totalCount;
                        this.pageMsg.pageSum = res.data.repBody.paginator.totalPages;
                        for (let i = 1; i <= this.pageMsg.pageSum; i++) {
                            this.pageMsg.pageList.push(i);
                        }
                        this.pageMsg.list = this.pageMsg.pageList.slice(0, 5);
                    }
                    else if (res.data.resCode === '100002') {
                        this.loading = false;
                        let message = res.data.resMsg
                        this.$message({
                            type: 'info',
                            message: message
                        });
                    } else {
                        this.loading = false;
                        let message = res.data.resMsg
                        this.$message({
                            type: 'info',
                            message: message
                        });

                    }
                })
                .catch(error => {
                    this.loading = false;
                    let message = res.data.resMsg
                    this.$message({
                        type: 'info',
                        message: message
                    });
                });

        },
        watch: {
            //监听日期快捷按钮
            'isDate' (newVal, oldVal) {
                if (newVal !== '' && newVal !== null) {
                    this.bar.data.scanTimes = [];
                    this.bar.data.counts = [];
                    //当前时间
                    const end = new Date();
                    const start = new Date();
                    switch (newVal) {
                        case 0:
                            //周
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
                            //格式化时间
                            this.bar.startTime = this.getTaskTime(start);
                            this.bar.endTime = this.getTaskTime(end);
                            this.increase(this.bar.startTime, this.bar.endTime);
                            var start = new Date();
                            var end = new Date();
                            this.isDefaultTime=true;
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
                            this.defaultTime=this.getTheDate(start)+' - '+this.getTheDate(end);
                            break;
                        case 1:
                            //30天
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
                            //格式化时间
                            this.bar.startTime = this.getTaskTime(start);
                            this.bar.endTime = this.getTaskTime(end);
                            this.increase(this.bar.startTime, this.bar.endTime);
                            var start = new Date();
                            var end = new Date();
                            this.isDefaultTime=true;
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
                            this.defaultTime=this.getTheDate(start)+' - '+this.getTheDate(end);
                            break;
                        default:
                            break
                    }

                }
            },
            'bar.areaCode' (newVal, oldVal) {
                //地区选择改变,发请求拿到最新数据
                //参数是this.bar.startTime以及地区newVal
                this.bar.data.scanTimes = [];
                this.bar.data.counts = [];
                this.increase(this.bar.startTime, this.bar.endTime);
            }
        },
        methods: {
            getMyDate(str){
                var da = str;
                da = new Date(da);
                var year = da.getFullYear()+'年';
                var month = da.getMonth()+1+'月';
                var date = da.getDate()+'日';
                var hehe=year+month+date
                return hehe
            },
            getTheDate(str){
                var da = str;
                da = new Date(da);
                var year = da.getFullYear()+'-';
                var month = da.getMonth()+1+'-';
                var date = da.getDate();
                var hehe=year+month+date
                return hehe
            },
            //绘制canvas
            drawbar(id) {
                this.chart = echarts.init(document.getElementById(id), 'vintage');
                this.chart.setOption({
                    title: {
                        text: '扫码用户增长趋势',
                        subtext: ''
                    },
                    tooltip: {
                        trigger: 'axis'
                    },
                    legend: {
                        data: ['', '']
                    },
                    toolbox: {
                        show: true,
                        feature: {
                            dataView: {show: true, readOnly: false},
                            magicType: {show: true, type: ['bar', 'line']},
                            restore: {show: true},
                            saveAsImage: {show: true}
                        }
                    },
                    calculable: true,
                    xAxis: [
                        {
                            type: 'category',
                            data: this.bar.data.scanTimes,
                            name: '日期'
                        }
                    ],
                    yAxis: [
                        {
                            type: 'value',
                            name: '用户增长量'
                        }
                    ],
                    series: [
                        {
                            name: '用户增长数',
                            type: 'line',
                            data: this.bar.data.counts,
                            markPoint: {
                                data: [
                                    {type: 'max', name: '最大值'},
                                    {type: 'min', name: '最小值'}
                                ]
                            },
                            markLine: {
                                data: [
                                    {type: 'average', name: '平均值'}
                                ],
                                name: '平均值'
                            }
                        }
                    ]
                })
            },
            //每日流量请求
            flow () {
                var vm = this;
                let msg = {
                    data: {}
                };
                vm.axios.post('/scanRecord/pageView', JSON.stringify(msg))
                    .then(res => {

                        if (res.data.resCode === '000000') {
                            //查询字段处理函数
                            this.loading = false;
                            let warningItem = res.data.repBody.map((value, index) => {
                                return {
                                    increase: value.increase || '0',//新增用户数
                                    pv: value.pv || '0',//pv
                                    uv: value.uv || '0',//uv
                                    orderNum: value.orderNum || '0',//新增工单
                                    eleCode:value.eleCode||'0',
                                    entCode:value.entCode||'0'

                                }
                            });

                            vm.flows = warningItem;
                        }
                        else if (res.data.resCode === '100002') {
                            this.loading = false;
                            let message = res.data.resMsg
                            this.$message({
                                type: 'info',
                                message: message
                            });

                        } else {
                            this.loading = false;
                            let message = res.data.resMsg
                            this.$message({
                                type: 'info',
                                message: message
                            });

                        }
                    })
                    .catch(error => {
                        let message = res.data.resMsg
                        this.$message({
                            type: 'info',
                            message: message
                        });
                    });
            },
            //流量图表数据请求
            increase (startTime, endTime) {
                var vm = this;
let mesg;
                if(vm.bar.areaCode=='--'){
                    mesg={
                        data: {
                            "startTime": startTime,
                            "endTime": endTime,
                            "areaCode": ''
                        }
                    }
                }else{
                    mesg={
                        data: {
                            "startTime": startTime,
                            "endTime": endTime,
                            "areaCode": vm.bar.areaCode
                        }
                    }
                }
                vm.axios.post('/scanRecord/increTrade', JSON.stringify(mesg))
                    .then(res => {
                        if (res.data.resCode === '000000') {
                            //查询字段处理函数
                            this.loading = false;
                            let warningItem2 = res.data.repBody.list.map((value, index) => {
                                return {
                                    count: value.count || '0',//新增用户数
                                    scanTime: this.replace(value.scanTime)//日期
                                }
                            });
                            for (var key in warningItem2) {
                                (this.bar.data.scanTimes).push((warningItem2[key]).scanTime);
                                (this.bar.data.counts).push((warningItem2[key]).count);
                            }
                            vm.drawbar('getupbar');
                        }
                        else if (res.data.resCode === '100002') {
                            this.loading = false;
                            let message = res.data.resMsg
                            this.$message({
                                type: 'info',
                                message: message
                            });
                        } else {
                            this.loading = false;
                            let message = res.data.resMsg
                            this.$message({
                                type: 'info',
                                message: message
                            });
                        }
                    })
                    .catch(error => {
                        let message = res.data.resMsg
                        this.$message({
                            type: 'info',
                            message: message
                        });
                    });
            },
            //区域列表请求
            area () {
                var vm = this;
                let mesg = {
                    data: {}
                };
                vm.axios.post('/areaCode/findAll', JSON.stringify(mesg))
                    .then(res => {
                        if (res.data.resCode === '000000') {
                            //查询字段处理函数
                            this.loading = false;
                            this.cities=res.data.repBody;
                            // this.cities.unshift({areaName:'所有区域',areaCode:'--'})
                        }
                        else if (res.data.resCode === '100002') {
                            this.loading = false;
                            let message = res.data.resMsg
                            this.$message({
                                type: 'info',
                                message: message
                            });
                        } else {
                            this.loading = false;
                            let message = res.data.resMsg
                            this.$message({
                                type: 'info',
                                message: message
                            });
                        }
                    })
                    .catch(error => {
                        this.loading=false;
                        let message = res.data.resMsg
                        this.$message({
                            type: 'info',
                            message: message
                        });
                    });


            },
            //日期选择器内的input发生改变时触发
            changeHandler (value, value7) {
                this.isDefaultTime=false;
                if(value!==''&&value!==null){
                    this.bar.data.scanTimes = [];
                    this.bar.data.counts = [];
                    this.isDate = '';
                    this.bar.startTime = this.getTaskTime(value7[0]);
                    this.bar.endTime = this.getTaskTime(value7[1]);
                    //请求数据
                    this.increase(this.bar.startTime, this.bar.endTime)
                }
            },
            changeHandlerForm (value, valueForm) {
                this.isDefault=false;
                if(value!==''&&value!==null){
                    this.formInline.startTime = this.getTheDate(valueForm[0]);
                    this.formInline.endTime = this.getTheDate(valueForm[1]);
                }
            },
            //时间格式化
            getTaskTime (strDate) {
                if (null == strDate || "" == strDate) {
                    return "";
                }
                var dateStr = (strDate.toString()).trim().split(" ");
                var strGMT = dateStr[0] + " " + dateStr[1] + " " + dateStr[2] + " " + dateStr[5] + " " + dateStr[3] + " GMT+0800";
                var date = new Date(Date.parse(strGMT));
                var y = date.getFullYear();
                var m = date.getMonth() + 1;
                m = m < 10 ? ('0' + m) : m;
                var d = date.getDate();
                d = d < 10 ? ('0' + d) : d;
                var h = date.getHours();
                h = h < 10 ? ('0' + h) : h;
                var minute = date.getMinutes();
                minute = minute < 10 ? ('0' + minute) : minute;
                var second = date.getSeconds();
                second = second < 10 ? ('0' + second) : second;
                return y + "-" + m + "-" + d + " " + h + ":" + minute + ":" + second;
            },
            //替换符号'-'为'/'
            replace (str) {
                var val = str.replace(/-/g, '/');
                return val
            },
            //渲染列表
            changePage (num,list) {
                this.loading = true;
                this.pageMsg={
                    pageSum: '',
                    //总页码
                    pageList: [],
                    //单页数量
                    pageSize: 10,
                    //商品总数
                    totalCount: '',
                    list: []
                };
                let msg = {
                    data: {
                        "pageName": 'accessRptService',
                        "paginator": {"limit": 10, "page": num},
                        "params":this.formInline
                    }
                };
                if(num=='1'){
                    this.pageIf=false;
                }
                var that = this;
                that.axios.post('/page/list', JSON.stringify(msg))
                    .then(res => {

                        if (res.data.resCode === '000000') {
                            //渲染处理函数
                            this.loading = false;
                            let warningItem = res.data.repBody.list.map((value, index) => {
                                return {
                                    staffNo     : value.staffNo || '',//装维人员工号
                                    staffName   :value.staffName,//装维人员姓名
                                    bindTotal   : value.bindTotal,//总共绑码用户数
                                    bindIncre   : value.bindIncre,//新增绑码用户数
                                    activeTotal : value.activeTotal,//活跃用户数
                                    activeIncre : value.activeIncre,//新增活跃用户数
                                    filialeName : value.areaName,//分公司
                                    statTime    : this.getMyDate(value.statTime)||''//日期
                                }
                            });
                            this.tableData = warningItem;
                    if(num=='1'){
                        this.pageIf=true;
                    }
                            this.pageMsg.totalCount = res.data.repBody.paginator.totalCount;
                            this.pageMsg.pageSum = res.data.repBody.paginator.totalPages;
                            for (let i = 1; i <= this.pageMsg.pageSum; i++) {
                                this.pageMsg.pageList.push(i);
                            }
                            if((num - 1) % 5 === 0){
                                this.pageMsg.list = this.pageMsg.pageList.slice(num - 1, num + 4);
                            }else if(num==1){
                                this.pageMsg.list = this.pageMsg.pageList.slice(0, 5);
                            }else if(num==this.pageMsg.pageSum&&(num % 5) === 0){
                                this.pageMsg.list = this.pageMsg.pageList.slice(num - 5, num);
                            }else if(num==this.pageMsg.pageSum&&(num % 5) !== 0){
                                let nn=num%5;
                                this.pageMsg.list = this.pageMsg.pageList.slice(num - nn, num);
                            }else if((num) % 5 === 0){
                                this.pageMsg.list = this.pageMsg.pageList.slice(num - 5, num);
                            }else{
                                this.pageMsg.list = list
                            }
                        }else if (res.data.resCode === '100002') {
                            this.loading = false;
                            let message = res.data.resMsg
                            this.$message({
                                type: 'info',
                                message: message
                            });
                        } else {
                            this.loading = false;
                            let message = res.data.resMsg
                            this.$message({
                                type: 'info',
                                message: message
                            });
                        }
                    })
                    .catch(error => {
                        this.loading = false;
                        let message = res.data.resMsg
                        this.$message({
                            type: 'info',
                            message: message
                        });
                    });
            },
            //表格查询按钮
            onSearch () {
                var vm = this;
                let mesg;
                if(this.valueForm[0]==null||this.valueForm[0]==undefined){
                    this.$message({
                        type: 'info',
                        message: '请选择查询日期'
                    });
                    return false
                }
                if(vm.formInline.staffNo=='--'){
                    vm.formInline= {
                        "startTime": vm.formInline.startTime,
                        "endTime": vm.formInline.endTime,
                        "staffNo": ''
                    }

                }
                this.search=this.formInline
                this.changePage(1);
            },
            //获取所有区域
            getRegion() {
                var that = this;
                that.axios.post('/areaCode/findAll',{})
                    .then(res =>{
                    if (res.data.resCode === '000000') {
                          that.filialeArr = res.data.repBody
                    }else {
                        this.$message({
                            type: 'info',
                            message: '网络错误'
                        });
                    }
                })
                .catch(error => {
                  console.log(error);
                    this.$message({
                        type: 'info',
                        message: '网络错误'
                    });
                })
            },
        },
        mounted() {
            this.$nextTick(function () {
                this.area();
                var end = new Date();
                var start = new Date();
                start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
                this.bar.startTime = this.getTaskTime(start);
                this.bar.endTime = this.getTaskTime(end);
                this.increase(this.bar.startTime, this.bar.endTime);
                var that = this;
                var resizeTimer = null;
                window.onresize = function () {
                    if (resizeTimer) clearTimeout(resizeTimer);
                    resizeTimer = setTimeout(function () {
                        that.drawbar('getupbar');
                    }, 100);
                }
            });
        }
    }
</script>
<style lang="less" rel="stylesheet/less" scoped>
    .table-list {
        padding-top: 6px;
        padding-right: 1px;
        border: 1px solid #dedede;
        /*border-bottom: 0;*/
        .overview-card-title-container {
            padding: 14px 15px 0;
        }
        .list {
            border-collapse: collapse;
            width: 100%;
            /*margin: 0 auto;*/
            /*padding:0 100px;*/
            font-size: 12px;
            tbody {
                display: table-row-group;
                vertical-align: middle;
                border-color: inherit;
                .title {
                    border-bottom: none;
                    height: 50px;
                    line-height: 50px;
                    th {
                        height: 16px;
                        line-height: 16px;
                        padding: 13px 20px 0 10px;
                        text-align: right;
                        color: #5b5d61;
                        white-space: nowrap;
                        font-weight: 400;
                    }
                    .empty-tr0 {
                        width: 1px;
                        padding: 6px 19px 6px 0;
                        border-left: 0;
                    }
                }
                tr {
                    display: table-row;
                    vertical-align: inherit;
                    border-color: inherit;
                }
                tr.highlight td.normal {
                    padding-left: 20px;
                    font-size: 12px;
                    font-weight: 400;
                    text-align: left;
                    /*text-align: right;*/
                }
                tr td.normal {
                    padding-left: 20px;
                    width: 85px;
                    text-align: left;
                    color: #323437;
                }
                td {
                    border-left: 1px solid #f0f0f0;
                    padding: 6px 20px 6px 5px;
                    height: 17px;
                    line-height: 17px;
                    white-space: nowrap;
                    text-align: right;
                }
                tr.highlight td {
                    color: #111314;
                    font-size: 16px;
                    font-weight: bolder;
                }
                .empty-tr0 {
                    width: 1px;
                    padding: 6px 19px 6px 0;
                    border-left: 0;
                }
                .arrow-up {
                    /*background-repeat: no-repeat;*/
                    /*background-position: 97% 8px;*/
                    /*background-image: url(decorator/arrow-up.png);*/
                }
                tr td:first-child {
                    border-left: 0;
                }
                tr.empty-tr1 {
                    height: 20px;
                    border-bottom: 1px solid #f0f0f0;
                }
            }
        }
        .blockTime {
            .el-input {
                width: 120px;
            }
        }
    }
    .download-flow{
        display: inline-block;
        width: 120px;
        height: 36px;
        .el-button{
            width: 120px;
        }
    }
.top2{
    margin-top:60px;
    height: 45px;
    .flow-main{
        position: relative;
        .flow-a{
            position: absolute;
            top:0;
            left:20px;
        }
        .flow-b{
            position: absolute;
            /*height:45px;*/
            top:1px;
            left:380px;
            /*.el-input{*/
                /*height: 45px;*/
            /*}*/
        }
    }
}
    .el-tag{
        /*height: 26px;*/
        /*line-height: 26px;*/
        font-size:13px;
        /*margin-right: 5px;*/
/*padding: 0 8px;*/
    }
.defaultBlock{
    .defaultDate{
        position: absolute;
        top:1px;
        left:11px;
        color: #1f2d3d;
        font-weight:400;
        font-family: system-ui;
        font-size:14px;
    }
}.defaultInline{
     position: relative;
     .defaultTime{
         position: absolute;
         top:1px;
         left:11px;
         color: #1f2d3d;
         font-weight:400;
         font-family: system-ui;
         font-size:13px;
     }
 }
    #getupbar {
        position: relative;
        /*width: 90%;*/
        /*width: 1049px;*/
        width: 100%;
        /*left: 50%;*/
        height: 600px;
        /*margin-left: -45%;*/
        /*box-shadow: 0 0 10px #BF382A;*/
        /*border-radius: 10px;*/
        -webkit-tap-highlight-color: transparent;
        user-select: none;
        background: #e8e9ee;
    }

    .date-select-bar {

        text-align: right;
        /*height: 45px;*/
    }
</style>
