<template>
    <!--排障数据分析-->
    <div class="loft">
        <el-row class="tool">
            <el-col :span="24">
                <div class="grid-content bg-purple toolbar">
                    <el-form :inline="true" :model="formInline" class="demo-form-inline">
                        <el-form-item label="" class="oinput3">
                            <el-select v-model="formInline.areaCode" :disabled="!isfilialeshow"  placeholder="选择分公司" clearable class="oinput">
                                <el-option
                                        v-for="item in cities"
                                        :key="item.areaName"
                                        :label="item.areaName"
                                        :value="item.areaCode"
                                    >
                                    <span style="float: left">{{ item.areaName }}</span>
                                    <!-- <span style="float: right; color: #8492a6; font-size: 13px">{{ item.areaCode }}</span> -->
                                </el-option>
                            </el-select>
                        </el-form-item>
                        <el-form-item label="" class="oinput2">
                            <div class="block d-ib defaultInline">
                                <el-date-picker
                                        v-model="valueForm"
                                        type="daterange"
                                        align="right"
                                        placeholder=""
                                        :picker-options="pickerOptions"
                                        :editable=false
                                        @change="(value) => changeHandlerForm(value, valueForm)"
                                >
                                </el-date-picker>
                                <div class="defaultDate" v-show="isDefault">{{defaultDate}}</div>
                            </div>
                        </el-form-item>
                        <el-form-item>
                            <el-button type="primary" @click="onSearch" class="serSub" icon="search">查询</el-button>
                        </el-form-item>
                        <el-form-item class="f-r">
                          <a :href="baseUrl+'workerOrderDay/export?areaCode='+search.areaCode+'&beginTime='+search.beginTime+'&endTime='+search.endTime" download="排障数据" class="download-loft"><el-button type="success" class="serSub" icon="upload2">导出</el-button></a>
                        </el-form-item>
                        <el-form-item class="f-r" style="margin-right: 12px"><el-tag type="danger" style="padding: 0 13px">报障次数:{{total.faultTotal}}</el-tag><el-tag type="danger" style="margin-left: 10px;padding: 0 13px">处理次数:{{total.solveTotal}}</el-tag><el-tag type="danger" style="margin-left: 10px;padding: 0 13px">形成工单数:{{total.orderTotal}}</el-tag></el-form-item>
                    </el-form>
                </div>
            </el-col>
        </el-row>
        <!--table里的tableData就是遍历的数组-->
        <!--prop就是数组对象里对应的数据-->
        <el-table
                :data="tableData"
                style="width: 100%;color:#5d5d61;font-size: 13px"
                border
                v-loading="loading"
                highlight-current-row
                @current-change="handleCurrentChange"
                ref="loftLi"
        >
            <el-table-column
                    align="center"
                    prop="areaName"
                    label="分公司"
                    width="110">
            </el-table-column>
            <el-table-column
                    align="center"
                    prop="declareNo"
                    label="用户报障次数"
                    width="150">
            </el-table-column>
            <el-table-column
                    align="center"
                    prop="bindTotal"
                    label="绑码数"
                    width="100">
            </el-table-column>
            <el-table-column
                    align="center"
                    prop="activeTotal"
                    label="活动用户数"
                    width="150">
            </el-table-column>
            <el-table-column
                    align="center"
                    prop="disposeNo"
                    label="处理故障次数"
                    width="150">
            </el-table-column>
            <el-table-column
                    align="center"
                    prop="orderNo"
                    label="形成报障工单数"
                    width="150">
            </el-table-column>
            <el-table-column
                    align="center"
                    prop="date"
                    label="日期"
            >
            </el-table-column>
        </el-table>
        <page-bar :changePage="changePage" class="f-r clearfix" :pageMsg="pageMsg" v-if="pageIf"></page-bar>
        <el-row class="tool el-row2">
            <el-col :span="24">
                <div class="grid-content bg-purple toolbar">
                    <el-form :inline="true"  class="demo-form-inline">
                        <el-form-item label="业务类型">
                            <el-select v-model="order.businessType" placeholder="业务类型" size="small" clearable style="width:120px">
                                <el-option label="全部" value="5"></el-option>
                                <el-option label="宽带" value="2"></el-option>
                                <el-option label="IPTV" value="3"></el-option>
                            </el-select>
                        </el-form-item>
                        <el-form-item label="日期范围">
                        <div class="block d-ib">
                            <el-date-picker
                                    v-model="order.time"
                                    align="right"
                                    type="year"
                                    placeholder="请选择日期范围"
                                    size="small"
                                    format="yyyy年">
                            </el-date-picker>
                        </div>
                        </el-form-item>
                            <el-form-item label="分公司">
                        <el-select v-model="order.areaCode" :disabled="!isfilialeshow" placeholder="请选择分公司" size="small" clearable>
                            <el-option
                                    v-for="item in cities"
                                    :key="item.areaName"
                                    :label="item.areaName"
                                    :value="item.areaCode"
                            >
                                <span style="float: left">{{ item.areaName }}</span>
                                <span style="float: right; color: #8492a6; font-size: 13px">{{ item.areaCode }}</span>
                            </el-option>
                        </el-select>
                            </el-form-item>
                        <el-form-item>
                        <el-button type="primary" @click="onSubmit" class="serSub" icon="search" size="small" style="width:80px">查询</el-button>
                        </el-form-item>
                    </el-form>
                </div>
            </el-col>
        </el-row>
        <div id="getupbar2"></div>
    </div>
</template>
<script>
    import echarts from 'echarts';
    import session from '../../utils/session'
    import '../../../node_modules/echarts/theme/vintage.js';
    import {Message} from 'element-ui';
    import pageBar from '../pageBar.vue'
    import axios from 'axios'
    export default {
        data() {
            return {
              isfilialeshow: true,
                formInline: {
                    areaCode: '',
                    time:{
                        beginTime:'',
                        endTime:''
                    }
                },
                isDefault: true,
                defaultDate: '',
                pageIf:true,
                tableData: [],
                loading: false,
                pageMsg: {
                    pageSum: '',
                    //总页码
                    pageList: [],
                    //单页数量
                    pageSize: 10,
                    //商品总数
                    totalCount: '',
                    list: []
                },
                search: {
                    areaCode: '',
                    time:{
                        beginTime:'',
                        endTime:''
                    }
                },
                total: {
                  faultTotal: '',
                  orderTotal: '',
                  solveTotal: ''
                },
                chart: null,
                pickerOptions: {
                    //禁用状态,大于当前日期则禁用
                    disabledDate (time) {
                        return time.getTime() > Date.now()
                    },
                    shortcuts: [{
                        text: '最近一周',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
                            picker.$emit('pick', [start, end]);
                        }
                    }, {
                        text: '最近30天',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
                            picker.$emit('pick', [start, end]);
                        }
                    }]
                },
                //日期控件
                pickerOptions2: {
                    //禁用状态,大于当前日期则禁用
                    disabledDate (time) {
                        return time.getTime() > Date.now()
                    },
                    shortcuts: [{
                        text: '最近一周',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
                            picker.$emit('pick', [start, end]);
                        }
                    }, {
                        text: '最近30天',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
                            picker.$emit('pick', [start, end]);
                        }
                    },
                        {
                            text: '最近90天',
                            onClick(picker) {
                                const end = new Date();
                                const start = new Date();
                                start.setTime(start.getTime() - 3600 * 1000 * 24 * 90);
                                picker.$emit('pick', [start, end]);
                            }
                        }]
                },
                //日期绑定
                valueForm: ['',''],
                //快捷选择日期
                isDate: 0,
                areaCode:'',
                //区域数组
                cities: [],
                //报障工单对比查询条件
                order:{
                    businessType:'5',
                    time:'',
                    areaCode:''
                },
                //报障工单对比图表数组
                bar:{},
                //报障项比例数组
                pie:{
                    date:{
                        startTime:'',
                        endTime:''
                    },
                    area:{
                        areaName:'',
                        areaCode:''
                    },
                    draw:{
                        title:'',
                        standard:'',
                        items:[
                            {name:'',value:''},
                            {name:'',value:''},
                            {name:'',value:''},
                            {name:'',value:''},
                            {name:'',value:''},
                            {name:'',value:''},
                            {name:'',value:''}],
                    },
                    baseUrl:'',
                    pieAr:[]
                }
            }
        },
        components: {
            pageBar
        },
        created () {
            this.getqureyTotal();
            if(localStorage.getItem("areaCodeNum") > 1){
                this.isfilialeshow = true;
            }else{
              this.isfilialeshow = false;
              let content = JSON.parse(localStorage.getItem("userInfo"))
              this.formInline.areaCode = content.userInfo.areaCode
              this.order.areaCode = content.userInfo.areaCode
            }
            this.loading = true;
            this.baseUrl=axios.defaults.baseURL;
            this.defaultDate=this.getTheDate(new Date())+' - '+this.getTheDate(new Date());
            console.log(this.defaultDate)
            this.formInline.startTime = this.getTheDate(new Date());
            this.formInline.time.endTime = this.getTheDate(new Date());
            var start = new Date();
            var end = new Date();
            start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
            this.defaultTime=this.getTheDate(start)+' - '+this.getTheDate(end);
            this.formInline.startTime = this.getTheDate(new Date());
            this.formInline.time.endTime = this.getTheDate(new Date());
            this.search.startTime = this.getTheDate(new Date());
            this.search.time.endTime = this.getTheDate(new Date());
            let msg = {
                data: {
                    "pageName": 'workerOrderDayService',
                    "paginator": {"limit": 10, "page": 1},
                    "params": {
                        areaCode: '',
                        time:{"beginTime":"","endTime":""}
                    }
                }
            };
            var that = this;
            that.axios.post('/page/list', JSON.stringify(msg))
                .then(res => {
            if (res.data.resCode === '000000') {
                //查询字段处理函数
                this.loading = false;
                let warningItem = res.data.repBody.list.map((value, index) => {
                        return {
                            areaName    : value.areaName || '',//支局
                            declareNo   :value.declareNo,//用户报障次数
                            disposeNo   : value.disposeNo,//处理工单次数
                            orderNo     : value.orderNo,//形成报障工单数
                            bindTotal   : value.bindTotal,//绑码数
                            activeTotal : value.activeTotal,//活动用户数
                            date        : this.getMyDate(value.createTime)||''//日期
                        }
                    });
                this.tableData = warningItem;
                setTimeout(co,100);
                function co() {
                        var ttr=document.getElementsByClassName('el-table__row');
                        ttr[0].style.backgroundColor='#e2f0e4';
                }
                //传给分页组件
                        this.pageMsg.totalCount = res.data.repBody.paginator.totalCount;
                        this.pageMsg.pageSum = res.data.repBody.paginator.totalPages;
                for (let i = 1; i <= this.pageMsg.pageSum; i++) {
                    this.pageMsg.pageList.push(i);
                }
                this.pageMsg.list = this.pageMsg.pageList.slice(0, 5);
            }
            else if (res.data.resCode === '100002') {
                this.loading = false;
                let message = res.data.resMsg
                this.$message({
                    type: 'info',
                    message: message
                });
            } else {
                this.loading = false;
                let message = res.data.resMsg
                this.$message({
                    type: 'info',
                    message: message
                });

            }
        })
        .catch(error => {
                this.loading = false;
            let message = res.data.resMsg
            this.$message({
                type: 'info',
                message: message
            });
        });

        },
        methods: {
            getMyDate(str){
                var da = str;
                da = new Date(da);
                var year = da.getFullYear()+'年';
                var month = da.getMonth()+1+'月';
                var date = da.getDate()+'日';
                var hehe=year+month+date
                return hehe
            },
            getTheDate(str){
                var da = str;
                da = new Date(da);
                var year = da.getFullYear()+'-';
                var month = da.getMonth()+1+'-';
                var date = da.getDate();
                var hehe=year+month+date
                return hehe
            },
            getSummaries(param) {
                const { columns, data } = param;
                const sums = [];
                columns.forEach((column, index) => {
                    if (index === 0) {
                        sums[index] = '总价';
                        return;
                    }
                    const values = data.map(item => Number(item[column.property]));
                    if (!values.every(value => isNaN(value))) {
                        sums[index] = values.reduce((prev, curr) => {
                            const value = Number(curr);
                            if (!isNaN(value)) {
                                return prev + curr;
                            } else {
                                return prev;
                            }
                        }, 0);
                        sums[index] += ' 元';
                    } else {
                        sums[index] = 'N/A';
                    }
                });

                return sums;
            },
            handleCurrentChange(val) {
                this.currentRow = val;
            },
            //渲染列表
            changePage (num,list) {
                this.loading = true;
                this.pageMsg = {
                    pageSum: '',
                    //总页码
                    pageList: [],
                    //单页数量
                    pageSize: 10,
                    //商品总数
                    totalCount: '',
                    list: []
                };
                var ttr=document.getElementsByClassName('el-table__row');
                ttr[0].style.backgroundColor='#fff';
                let msg = {
                    data: {
                        //接口出来了记得改
                        "pageName": 'workerOrderDayService',
                        "paginator": {"limit": 10, "page": num},
                        "params": this.search
                    }
                };
                if(num=='1'){
                    this.pageIf=false;
                }
                var that = this;
                that.axios.post('/page/list', JSON.stringify(msg))
                    .then(res => {
                    if (res.data.resCode === '000000') {
                        //渲染处理函数
                        this.loading = false;
                        let warningItem = res.data.repBody.list.map((value, index) => {
                            return {
                                areaName    : value.areaName || '',//支局
                                declareNo   :value.declareNo,//用户报障次数
                                disposeNo   : value.disposeNo,//处理工单次数
                                orderNo     : value.orderNo,//形成报障工单数
                                bindTotal   : value.bindTotal,//绑码数
                                activeTotal : value.activeTotal,//活动用户数
                                date        : this.getMyDate(value.createTime)||''//日期
                            }
                        });
                        this.tableData = warningItem;
                        setTimeout(co,100);
                        function co() {
                            if(num=='1'){
                                var ttr=document.getElementsByClassName('el-table__row');
                                ttr[0].style.backgroundColor='#e2f0e4';
                            }
                        }
                        if(num=='1'){
                            this.pageIf=true;
                        }
                        this.pageMsg.totalCount = res.data.repBody.paginator.totalCount;
                        this.pageMsg.pageSum = res.data.repBody.paginator.totalPages;
                        for (let i = 1; i <= this.pageMsg.pageSum; i++) {
                            this.pageMsg.pageList.push(i);
                        }
                        if((num - 1) % 5 === 0){
                            this.pageMsg.list = this.pageMsg.pageList.slice(num - 1, num + 4);
                        }else if(num==1){
                            this.pageMsg.list = this.pageMsg.pageList.slice(0, 5);
                        }else if(num==this.pageMsg.pageSum&&(num % 5) == 0){
                            this.pageMsg.list = this.pageMsg.pageList.slice(num - 5, num);
                        }else if(num==this.pageMsg.pageSum&&(num % 5) !== 0){
                            let nn=num%5;
                            this.pageMsg.list = this.pageMsg.pageList.slice(num - nn, num);
                        }else if((num) % 5 == 0){
                            this.pageMsg.list = this.pageMsg.pageList.slice(num - 5, num);
                        }else{
                            this.pageMsg.list = list
                        }
                    }
                })
            .catch(error => {
                    this.loading = false;
                    let message = res.data.resMsg
                    this.$message({
                        type: 'info',
                        message: message
                    });
                });
            },
            //表格查询按钮
            onSearch () {
                var vm = this;
        let mesg;
                if(this.valueForm==''){
                    this.$message({
                        type: 'info',
                        message: '请选择查询日期'
                    });
                    return false
                }
                if(this.valueForm[0]==null){
                    this.$message({
                        type: 'info',
                        message: '请选择查询日期'
                    });
                    return false
                }
                this.search=this.formInline;
                if(vm.formInline.areaCode=='--'){
                    vm.search= {
                            time:{"beginTime": vm.formInline.time.beginTime,"endTime": vm.formInline.time.endTime},
                            "areaCode": ''
                        }
                }
                this.changePage(1);
            },
            //查询按钮
            onSubmit () {
                var vm = this;
                let mesg;
                if(this.order.time==''){
                    this.$message({
                        type: 'info',
                        message: '请选择查询日期'
                    });
                    return false
                }

                //判断年份
                if(vm.order.areaCode=='--'){
                    mesg = {
                        data: {
                            "productType": vm.order.businessType,
                            "year": JSON.stringify((vm.order.time).getFullYear()),
                            "areaCode": ''
                        }
                    }
                }else{
                    mesg = {
                        data: {
                            "productType": vm.order.businessType,
                            "year": JSON.stringify((vm.order.time).getFullYear()),
                            "areaCode": vm.order.areaCode
                        }
                    }
                }

                vm.axios.post('/workOrder/orderAndSelfSolveFaultCount', JSON.stringify(mesg))
                    .then(res => {
                        if (res.data.resCode === '000000') {
                            //查询字段处理函数
                            this.loading = false
                            this.bar=res.data.repBody.data;
                            vm.drawbar('getupbar2');
                        }
                        else if (res.data.resCode === '100002') {
                            this.loading = false;
                            let message = res.data.resMsg
                            this.$message({
                                type: 'info',
                                message: message
                            });

                        } else {
                            this.loading = false;
                            let message = res.data.resMsg
                            this.$message({
                                type: 'info',
                                message: message
                            });

                        }
                    })
                    .catch(error => {
                    let message = res.data.resMsg
                    this.$message({
                    type: 'info',
                    message: message
                });
                    });
            },
            //报障工单对比图表
            drawbar(id) {
                this.chart = echarts.init(document.getElementById(id), 'vintage');
                this.chart.setOption({
                        title : {
                            text: this.bar.title,
                            subtext: ''
                        },
                        tooltip : {
                            trigger: 'axis'
                        },
                        legend: {
                            data:[this.bar.normal.item,this.bar.contrast.item]
                        },
                        toolbox: {
                            show : true,
                            feature : {
                                dataView : {show: true, readOnly: false},
                                magicType : {show: true, type: ['line', 'bar']},
                                restore : {show: true},
                                saveAsImage : {show: true}
                            }
                        },
                        calculable : true,
                        xAxis : [
                            {
                                type : 'category',
                                data : ['1月','2月','3月','4月','5月','6月','7月','8月','9月','10月','11月','12月']
                            }
                        ],
                        yAxis : [
                            {
                                type : 'value'
                            }
                        ],
                        series : [
                            {
                                name:this.bar.normal.item,
                                type:'bar',
                                data:this.bar.normal.value,
                                markPoint : {
                                    data : [
                                        {type : 'max', name: '最大值'},
                                        {type : 'min', name: '最小值'}
                                    ]
                                },
                                markLine : {
                                    data : [
                                        {type : 'average', name: '平均值'}
                                    ]
                                },
                                barGap: '0%'
                            },
                            {
                                name:this.bar.contrast.item,
                                type:'bar',
                                data:this.bar.contrast.value,
                                markPoint : {
                                    data : [
                                        {type : 'max', name: '最大值'},
                                        {type : 'min', name: '最小值'}
                                    ]
                                },
                                markLine : {
                                    data : [
                                        {type : 'average', name : '平均值'}
                                    ]
                                }
                            }
                        ]




            })
            },
            drawpie(id, centery) {
                this.chart = echarts.init(document.getElementById(id), 'vintage');
                this.chart.setOption({
                    tooltip: {
                        trigger: 'item',
                        formatter: "{a} <br/>{b} : {c} ({d}%)"
                    },
                    toolbox: {
                        feature: {
                            saveAsImage: {},
                            dataView: {}
                        },
                        right: 15,
                        top: 10
                    },
                    legend: {
                        orient: 'vertical',
                        left: 5,
                        top: 10,
                        data: this.pie.pieAr
                    },
                    series: [
                        {
                            name: this.pie.draw.standard,
                            type: 'pie',
                            radius: '70%',
                            center: ['50%', '60%'],
                            data:  this.pie.draw.items,
                                emphasis: {
                                    shadowBlur: 10,
                                    shadowOffset: 0,
                                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                                }
                        }
                    ]
                });
            },
            changeHandler (value, value7) {
                if(value!==''&&value!==null){
                    this.pie.pieAr=[];
                    this.isDate = '';
                    this.pie.date.startTime = this.getTaskTime(value7[0]);
                    this.pie.date.endTime = this.getTaskTime(value7[1]);
                    //请求数据
                    this.increase(this.pie.date.startTime, this.pie.date.endTime)
                }
            },
            changeHandlerForm (value, valueForm) {
                 this.isDefault=false;
                if(value!==''&&value!==null){
                    this.formInline.time.beginTime = this.getTaskTime(valueForm[0]);
                    this.formInline.time.endTime = this.getTaskTime(valueForm[1]);

                }
            },
            //根据时间调整
            increase (startTime, endTime) {
                var vm = this;
                let mesg;
                if(vm.pie.area.areaCode=='--'){
                    mesg={
                        data: {
                            "beginTime": startTime,
                            "endTime": endTime,
                            "areaCode": '',
                            "productType": ""
                        }
                    }
                }else{
                    mesg={
                        data: {
                            "beginTime": startTime,
                            "endTime": endTime,
                            "areaCode": vm.pie.area.areaCode,
                            "productType": ""
                        }
                    }
                }
                vm.axios.post('/checkItem/checkItemCount', JSON.stringify(mesg))
                    .then(res => {
                    if (res.data.resCode === '000000') {
                        //查询字段处理函数
                        vm.loading = false;
                        vm.pie.draw=res.data.repBody.data
                        //报障项列表
                        for(var k in (vm.pie.draw.items)){
                            (vm.pie.pieAr).push((vm.pie.draw.items)[k].name)
                        }
                        vm.drawpie('getuppie');
                    }
                    else if (res.data.resCode === '100002') {
                        this.loading = false;
                        let message = res.data.resMsg
                        this.$message({
                            type: 'info',
                            message: message
                        });
                    } else {
                        this.loading = false;
                        let message = res.data.resMsg
                        this.$message({
                            type: 'info',
                            message: message
                        });
                    }
                })
            .catch(error => {
                    this.loading = false;
                    let message = res.data.resMsg
                    this.$message({
                    type: 'info',
                    message: message
                });
                });
            },
            //时间格式化
            getTaskTime (strDate) {
                if (null == strDate || "" == strDate) {
                    return "";
                }
                var dateStr = (strDate.toString()).trim().split(" ");
                var strGMT = dateStr[0] + " " + dateStr[1] + " " + dateStr[2] + " " + dateStr[5] + " " + dateStr[3] + " GMT+0800";
                var date = new Date(Date.parse(strGMT));
                var y = date.getFullYear();
                var m = date.getMonth() + 1;
                m = m < 10 ? ('0' + m) : m;
                var d = date.getDate();
                d = d < 10 ? ('0' + d) : d;

                return y + "-" + m + "-" + d
            },
            //柱状图数据初始化
            loft () {
                var vm = this;
                let mesg = {
                    data: {
                        "productType": '',
//                        "year": JSON.stringify((new Date()).getFullYear()-1),
                        "year": JSON.stringify((new Date()).getFullYear()),
                        "areaCode": ''
                    }
                };
                vm.axios.post('/workOrder/orderAndSelfSolveFaultCount', JSON.stringify(mesg))
                    .then(res => {
                        if (res.data.resCode === '000000') {
                            //查询字段处理函数
                            this.loading = false
                            this.bar=res.data.repBody.data;
                            vm.drawbar('getupbar2');
                        }
                        else if (res.data.resCode === '100002') {
                            this.loading = false;
                            let message = res.data.resMsg
                            this.$message({
                                type: 'info',
                                message: message
                            });
                        } else {
                            this.loading = false;
                            let message = res.data.resMsg
                            this.$message({
                                type: 'info',
                                message: message
                            });
                        }
                    })
                    .catch(error => {
                    this.loading = false;
                    let message = res.data.resMsg
                    this.$message({
                    type: 'info',
                    message: message
                });
                    });
            },
            area () {
                var vm = this;
                let mesg = {
                    data: {}
                };
                vm.axios.post('/areaCode/findAll', JSON.stringify(mesg))
                    .then(res => {
                    if (res.data.resCode === '000000') {
                        //查询字段处理函数
                        this.loading = false;
                        var allareaCode = new Object();
                        allareaCode.areaCode = ''
                        allareaCode.areaId = ''
                        allareaCode.areaName = '所有区域'
                        this.cities.push(allareaCode);
                        res.data.repBody.map((value, index) => {
                            this.cities.push(value);
                        });
                        // this.cities=res.data.repBody;
                        // this.cities.unshift({areaName:'所有',areaCode:'--'})
                    }
                    else if (res.data.resCode === '100002') {
                        this.loading = false;
                        let message = res.data.resMsg
                        this.$message({
                            type: 'info',
                            message: message
                        });
                    } else {
                        this.loading = false;
                        let message = res.data.resMsg
                        this.$message({
                            type: 'info',
                            message: message
                        });
                    }
                })
            .catch(error => {
                    this.loading = false;
                    let message = res.data.resMsg
                    this.$message({
                    type: 'info',
                    message: message
                });
                });
            },
            getMyDate(str){

                 if(typeof str=='string'){
                     return str
                 }
                 if(typeof str=='number'){
                     var da = str;
                     da = new Date(da);
                     var year = da.getFullYear()+'年';
                     var month = da.getMonth()+1+'月';
                     var date = da.getDate()+'日';
                     var hehe=year+month+date
                     return hehe
                 }
            },
        getqureyTotal () {
            var vm = this;
            let mesg = {
                data: {}
            };
            vm.axios.post('/workerOrderDay/total', JSON.stringify(mesg))
                .then(res => {
                if (res.data.resCode === '000000') {
                  this.total.faultTotal = res.data.repBody.faultTotal
                  this.total.orderTotal = res.data.repBody.orderTotal
                  this.total.solveTotal = res.data.repBody.solveTotal
                }
                else if (res.data.resCode === '100002') {
                    this.loading = false;
                    let message = res.data.resMsg
                    this.$message({
                        type: 'info',
                        message: message
                    });
                } else {
                    this.loading = false;
                    let message = res.data.resMsg
                    this.$message({
                        type: 'info',
                        message: message
                    });
                }
            })
        .catch(error => {
                this.loading = false;
                let message = res.data.resMsg
                this.$message({
                type: 'info',
                message: message
            });
            });
        },
      },
        mounted() {
            this.$nextTick(function() {
                this.area();
                this.loft();
            });
        },
        watch: {
            'valueForm' (newVal, oldVal){
                        if(newVal==''){
                this.changeHandlerForm('','')
                }
            }
        }
    }
</script>

<style lang="less" rel="stylesheet/less" scoped>
    @import '../../assets/css/property.less';
    .loft{
        padding: 0px 0px 20px 0px;
        /*width: 100%;*/
        /*min-width: 1008px;*/
        .tool{
            padding: 10px 10px 10px 10px;
            /*font-size:12px;*/
        }
        /*报障数据分析*/
        .control-bar-wrapper{
            margin-bottom:20px;
             .control-bar {
                line-height: 44px;
                border: 1px solid #DDD;
                background-color: #f9f9f9;
                /*width: 100%;*/
                height: auto;
                 /*height: 44px;*/
                 /*box-sizing: border-box;*/
                .date-select-bar {
                    /*margin-top: 9px;*/
                    padding-left: 8px;
                    padding-right: 7px;
                    /*margin-bottom: 13px;*/
                    /*height: 22px;*/
                    /*line-height: 22px;*/
                    a {
                        display: inline-block;
                        color: #666;
                        height: 18px;
                        line-height: 18px;
                        padding: 4px 7px;
                        font-size: 12px;

                    }
                }
            }
        }
        .defaultInline{
         position: relative;
     .defaultDate{
         position: absolute;
         top:1px;
         left:11px;
         color: #1f2d3d;
         font-weight:400;
         font-family: system-ui;
         font-size:13px;
         z-index: 999;
     }
 }
        #getupbar2,
        #getuppie {
            position: relative;
            /*width: 90%;*/
            /*width: 1049px;*/
            /*width: 48%;*/
            /*left: 50%;*/
            height: 500px;
            /*margin-left: -45%;*/
            /*box-shadow: 0 0 10px #BF382A;*/
            /*border-radius: 10px;*/
            -webkit-tap-highlight-color: transparent;
            user-select: none;
            margin:0 auto;
        }
        #getuppie {
            /*margin-top: 30px;*/
        }

        .el-row2{
margin-top: 67px;
        }

        /*.el-tag--primary{*/
            /*height: 32px;*/
            /*line-height: 32px;*/
            /*font-size:14px;*/
        /*}*/
        .download-loft{
            display: inline-block;
            /*width: 79px;*/
            width: 120px;
            height: 36px;
            /*margin-left:15px;*/
            .el-button{
                width: 120px;
            }
        }
    }

    @media screen and (max-width: 470px) {
        #getuppie {
            height: 500px;
        }
        #texta{

        }
    }
</style>
