<template>
  <footer><p>Copyright ©2017 Easier. All Rights Reserved</p></footer>
</template>

<style scoped>
  footer {
    position: fixed;
    bottom: 0;
    width: 100%;
    border-top: solid 1px rgba(16, 16, 16, 0.1);
    box-shadow: 0 0 10px #eee;
    text-align: center;
    background-color: rgba(238, 238, 238, 0.6);
    color: #777;
      padding-left: 230px;
      min-width: 1008px;
      box-sizing: border-box;
  }
  p {
    /*margin-left: 24px;*/
      /*margin:0 auto;*/
      /*width: 300px;*/

    line-height: 40px;
    font-size: 12px;
      /*font-weight: 700;*/
      /*color: rgba(0, 0, 0, 0.9);*/
  }
  span {
    font-weight: 700;
    color: rgba(0, 0, 0, 0.9);
  }
</style>