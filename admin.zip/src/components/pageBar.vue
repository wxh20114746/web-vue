<template>
    <div class="page-bar">
        <div class="pagebtn">
            <button class="homepage" @click="selectPage=1">首页</button>
            <button class="prev" @click="prev" :class="{'isPage':selectPage===1}">上一页</button>
            <ul>
                <li v-for="(item,index) in pageMsg.list" @click="select(item,index)"
                    :class="{'active':selectPage===item}"
                >
                    {{item}}
                </li>
            </ul>
            <button class="next" @click="next" :class="{'isPage':selectPage===pageMsg.pageList.length}">下一页</button>
            <button class='homepage' @click="selectPage=pageMsg.pageSum">末页</button>
            <p class="count">共{{pageMsg.pageSum}}页/{{pageMsg.totalCount}}条数据</p>
        </div>
    </div>
</template>
<script type="text/ecmascript-6">
    export default{
        data () {
            return {
                //当前页
                selectPage: 1,
                idx: null
            }
        },
        props: {
            changePage: {
                type: Function,
                default: null
            },
            pageMsg:{
                type: Object,
                default: null
            }
        },
        created () {
        },
        watch: {
            //监听页码
            selectPage (newVal, oldVal) {
                this.changePage(newVal,this.pageMsg.list);
            }
        },
        methods: {
            //跳转:上一页
            prev () {
                if (this.selectPage > 1) {
                    this.selectPage--;
                }
            },
            //跳转:下一页
            next () {
                if (this.selectPage < this.pageMsg.pageList.length) {
                    this.selectPage++;
                }
            },
            //跳转:点击页码
            select (itm, index) {
                this.selectPage = itm;
            },
            //取消
            cancel (idx) {
            },
            //测试
            parentFlush(){
              // if(this.selectPage == 1){
              //   this.changePage(1,this.pageMsg.list);
              // }else{
              //   this.changePage(this.selectPage,this.pageMsg.list);
              // }
              this.changePage(this.selectPage,this.pageMsg.list);
            },
            create (name,page,limit) {
                //按钮初始化
                let msg={data:
                    {"pageName":name,
                        "paginator":{"limit":limit,"page":page},
                        "params":{"deviceType:":"","deviceBrand":"","deviceMode":""}
                    }};
                var that = this;
                that.axios.post('/admin/page/list',JSON.stringify(msg))
                    .then(res => {
//总页数=商品总数/单页数
                        this.totalCount = res.data.repBody.paginator.totalCount;
                        this.pageSum=res.data.repBody.paginator.totalPages;
                        for (let i = 1; i <= this.pageSum; i++) {
                            this.pageList.push(i);
                        }
                        this.list = this.pageList.slice(0, 5);
                    })
                    .catch(error => {
                    })
            }
        }
    }

</script>
<style scoped>
    .page-bar {
        padding: 12px;
        width: 568px;
        height: 48px;
    }

    .page-bar .pagebtn {
        float: right;
    }

    .page-bar .pagebtn button {
        margin-right: 5px;
        float: left;
        padding: 0;
        text-align: center;
        width: 70px;
        height: 27px;
        line-height: 27px;
        font-size: 13px;
        border-radius: 3px;
        border: 1px solid #20a1fc;
        background-color: #20a1fc;
        color: #fff;
    }

    .page-bar .pagebtn button:hover {
        cursor: pointer;
        border: 1px solid #20a1fc;
        background-color: #20a1fc;
        color: #fff;
    }

    .page-bar .pagebtn .count {
        display: inline-block;
        font-size: 12px;
        color: #999;
        margin-top: 14px;
    }

    .page-bar ul {
        display: inline-block;
        float: left;
    }

    .page-bar ul li {
        box-sizing: border-box;
        margin-right: 5px;
        float: left;
        display: inline;
        width: 27px;
        height: 27px;
        border: 1px solid #ccc;
        border-radius: 3px;
        line-height: 25px;
        text-align: center;
        font-size: 13px;
        color: #999;
    }

    .page-bar ul li:hover {
        cursor: pointer;
        background-color: #20a1fc;
        color: #fff;
        border: 1px solid #20a1fc;
    }

    .homepage {
        width: 50px !important;
    }

    .cancel {
        width: 50px !important;
    }

    .isPage {
        border: 1px solid #ccc !important;
        background-color: #ccc !important;
        color: #fff !important;
    }

    .active {
        background-color: #20a1fc !important;
        color: #fff !important;
        border-color: #20a1fc!important;
    }


</style>
