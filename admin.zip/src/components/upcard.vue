<template>
    <div class="upcard">
        <el-dialog title="图片详情" :visible.sync="dialogFormVisible">
            <el-form :model="tableData">
                <el-form-item label="业务类型" :label-width="formLabelWidth">
                    <el-select v-model="tableData.type" placeholder="请选择业务类型">
                        <el-option label="宽带" value="2"></el-option>
                        <el-option label="ITV" value="3"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="活动主题" :label-width="formLabelWidth">
                    <el-input v-model="tableData.theme" auto-complete="off"></el-input>
                </el-form-item>
                <el-form-item label="跳转链接" :label-width="formLabelWidth">
                    <el-input v-model="tableData.url" auto-complete="off"></el-input>
                </el-form-item>
                <el-form-item label="图片上传" :label-width="formLabelWidth">
                    <div class="File2"><span>选择文件</span><input type="file" name="file" @change="getFile($event)">
                    </div>
                    <div id="filename"><span class="filename" v-show="!isname">{{tableData.imgurl}}</span><span class="filename" v-show="isname">{{name}}</span></div>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="isname = false;dialogFormVisible = false;">取 消</el-button>
                <el-button type="primary" @click="submitForm($event)">确 定</el-button>
            </div>
        </el-dialog>
    </div>
</template>
<script type="text/ecmascript-6">
    export default {
        data () {
            return {
                dialogFormVisible: false,
                formLabelWidth: '120px',
                isname: false,
                name: ''
            }
        },
        props: {
            tableData: {
                type: Object,
                default: null
            },
            reload: {
                type: Function,
                default: null
            }
        },
        created () {
            this.isname = false;
        },
        methods: {
            submitForm(event) {
                var vm = this;
                //如果选择了图片,那么类型就为对象,那么就需要验证格式以及大小
                if(typeof(this.tableData.imgurl)=='object'){
                    const isJPG = /(jpg|jpeg|png|GIF|JPG|PNG)$/.test(vm.getStrg(vm.tableData.imgurl.type))
                    const isLt1M = vm.tableData.imgurl.size / 1024 / 1024 < 1;
                    if (!isJPG) {
                        this.$message.error('请上传格式为jpg/jpeg/png的图片!');
                        return false
                    }

                    if (!isLt1M) {
                        this.$message.error('上传图片大小不能超过 1MB!');
                        return false
                    }
                }else{

                }
//开始传参
                event.preventDefault();
                let formData = new FormData();
                formData.append('item', vm.tableData.theme);
                formData.append('productType', vm.tableData.type);
                formData.append('skipUrl', vm.tableData.url);
//                formData.append('file', vm.tableData.imgurl);
                //如果选择了图片,那么类型就为对象,那么应该添加上传地址,如果没有选择图片,那么传空字符串
                if(typeof(this.tableData.imgurl)=='object'){
                    formData.append('file', vm.tableData.imgurl);
                }else{
                    formData.append('file', '');
                }

                formData.append('carouselId', vm.tableData.carouselId);
                let config = {
                    headers: {
                        'Content-Type': 'multipart/form-data'
                    }
                }
                this.axios.post('/carouselPicture/replace', formData, config).then(res => {
                    if (res.data.resCode === '000000') {
                        vm.$message({
                            type: 'info',
                            message: '更换成功'
                        });
                        this.reload();
                    }else{
                        vm.$message({
                            type: 'info',
                            message: '更换失败'
                        });
                    }

                });
                this.isname = false;
                this.dialogFormVisible = false;

            },
            getStr(str) {
                return str.replace(/^.+\./, '')
            },
            getStrg(string) {
                var str_after = string.split('/')[1];
                return str_after
            },
            getFile(event) {
                this.tableData.imgurl = event.target.files[0];
                if (this.tableData.imgurl.name) {
                    this.isname = true;
                    this.name = this.tableData.imgurl.name
                }
            }
        }
    }
</script>
<style lang="less" rel="stylesheet/less">
    .File2 {
        position: relative;
        display: inline-block;
        background: #20A0FF;
        border: 1px solid #20A0FF;
        border-radius: 4px;
        padding: 4px 12px;
        overflow: hidden;
        color: #fff;
        text-decoration: none;
        text-indent: 0;
        line-height: 20px;
        #filename{
            /*width: 100%;*/
            /*min-width:100px;*/
        }
        .filename {
            /*text-align: justify;*/
            font-size: 12px;
            /*text-justify: inter-ideograph;*/
        }
        /*cursor: pointer;*/
        /*font-size:0;*/
        span {
            /*cursor: pointer;*/
            font-size: 14px;
        }
        #upload {
            /*cursor: pointer;*/
            font-size: 0;
        }
    }

    .File2 input {
        position: absolute;
        /*font-size: 100px;*/
        left: 0;
        top: 0;
        /*bottom: 0;*/
        /*right:0;*/
        width: 100%;
        height: 100%;
        opacity: 0;
        cursor: pointer;
        font-size: 0;
        z-index: 99;
    }

    .File2:hover {
        background: #20A0FF;
        border-color: #78C3F3;
        color: #fff;
        text-decoration: none;
        /*cursor: pointer;*/
    }

</style>
