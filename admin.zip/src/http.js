//http配置
import axios from 'axios'
import { Loading } from 'element-ui';
import { MessageBox } from 'element-ui';
import { Message } from 'element-ui';
let url=window.location.protocol;
// 基础url前缀
let axiosBaseUrl;
// 生产阶段设为production，开发阶段设为develop或staging，然后在脚本中
// 读取process.env.NODE_ENV即可。
if(process.env.NODE_ENV == 'production'){
    // 部署服务调用正式地址
    axiosBaseUrl = '/'
}else{
    // 开发测试地址
    //config里设置
    axiosBaseUrl = '/api'
}

// 超时时间
axios.defaults.timeout = 50000;
axios.defaults.baseURL = axiosBaseUrl;
axios.defaults.baseURL = 'http://192.168.163.117:8007/admin/';//vsp车检


var that=this;
// // http request 请求拦截器
// // 每次跳页面, 都要获取新路由对应的html页面, 这时候可以用axios的http拦截
// // 每次路由跳转, 都先让后台验证一下token是否有效, 在http头添加token,
// //     当后端接口返回 401 Unauthorized（未授权） ，让用户重新登录。
axios.interceptors.request.use(
    config => {
        // console.log(this.$refs.present);
        //加载动画
        function getCookie(name)
        {
            var arr,reg=new RegExp("(^| )"+name+"=([^;]*)(;|$)");

            if(arr=document.cookie.match(reg))

                return (arr[2]);
            else
                return null;
        }
        function delCookie(name)
        {
            var exp = new Date();
            exp.setTime(exp.getTime() - 1);
            var cval=getCookie(name);
            if(cval!=null)
                document.cookie= name + "="+cval+";expires="+exp.toGMTString();
        }
        //如果存在urgeTime,表示不在登录页面
        if(localStorage.getItem('urgeTime')){
            //超时半小时
        if(new Date().getTime()-localStorage.getItem('urgeTime')>1800000){
            // console.log('超时');
            //重新登录
            MessageBox.alert('登录超时,请重新登录').then(action => {
                delCookie('JSESSIONID');
                localStorage.clear();
                sessionStorage.clear();
                location.reload()
            });
            return
        }
        }
        // console.log('拦截器-request');
        config.headers.Authorization = `JSESSIONID=${sessionStorage.getItem("JSESSIONID")}`;
        //在请求发送之前做一些事
        // if (store.state.token) { // 判断是否存在token，如果存在的话，则每个http header都加上token
        if (sessionStorage.getItem("code")) { // 判断是否存在token，如果存在的话，则每个http header都加上token
            // config.headers.Authorization = `token ${sessionStorage.getItem("code")}`;
        }
        return config;
    }, error => {
        //当出现请求错误时做一些事
        // loadinginstace.close();
        Message.error({
            message: '加载超时,请检查网络或尝试重新登录'
        })
        return Promise.reject(error);
    });

// http response 返回拦截器

 axios.interceptors.response.use(
     response => {
         // setTimeout(() => {
         //     loadinginstace.close();
         // }, 800);
         // loadinginstace.close()
         //对返回的数据进行一些处理
         //关闭动画
         // loadinginstace.close();
         localStorage.setItem('urgeTime', new Date().getTime());
         // console.log('拦截器-response-success--输出')
         // console.log(response);
         return response;
     },
     error => {
         Message.error({
             message: '加载失败'
         })
         // loadinginstace.close();
         //对返回的错误进行一些处理
         // MessageBox('网络错误').then(action => {
         // });
         // MessageBox.alert('网络错误,返回登录页面').then(action => {
         //     delCookie('JSESSIONID');
         //     localStorage.clear();
         //     sessionStorage.clear();
         //     location.reload()
         //     // that.$router.push('/login');
         // });
         // MessageBox.alert('网络错误').then(action => {
         // });
         // if (error.response) {
         //     switch (error.response.status) {
         //         case 401:
         //             // 401 清除token信息并跳转到登录页面
         //             store.dispatch('userSignOut',{
         //                 redirect:{
         //                     name  : 'login'
         //                 }
         //             })
         //     }
         // }
         // console.log(JSON.stringify(error));//console : Error: Request failed with status code 402
         return Promise.reject(error.response.data)
     });


export default axios;
