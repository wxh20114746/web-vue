/**
 * Created by apple on 17/7/4.
 */
"use strict";
import Vue from 'vue';
import App from './App'
import VueRouter from 'vue-router'
Vue.use(VueRouter);

const routerConfig = [{
    path: '/login',
    name: 'login',
    component: resolve => require(['./views/login/login.vue'], resolve)
  },
  {path: '*',redirect:'/login'},
  {
    path: '/',
    // name: 'index',
    meta: {
      requireAuth: false,
    },
    redirect:'/login',
    component: App,
    children: [
      {
        path: '/qrTask',
        name: 'makeTaskService',
        meta: {
          requireAuth: true,
        },
        component: resolve => require(['./views/qr/qrcode.vue'], resolve)
      } ,
        {
        path: '/qrQuery',
        name: 'qrQuery',
        meta: {
          requireAuth: true,
        },
        component: resolve => require(['./views/bindcodequery/index.vue'], resolve)
      } ,
        {
        path: '/makeQr',
        name: 'makeQr',
        meta: {
          requireAuth: true,
        },
        component: resolve => require(['./views/codemanage/index.vue'], resolve)
      } ,
      {
        path: '/qrStat',
        name: 'qrStat',
        meta: {
          requireAuth: true,
        },
        component: resolve => require(['./views/statistics/qrStat.vue'], resolve)
      } ,
      {
        path: '/creatQr',
        name: 'batchService',
        meta: {
          requireAuth: true,
        },
        component: resolve => require(['./views/creatqr/creatqr.vue'], resolve)
      },
      {
        path: '/password',
        name: 'password',
        meta: {
          requireAuth: true,
        },
        component: resolve => require(['./views/jurisdiction/password/password.vue'], resolve)
      },
      {
        path: '/role',
        name: 'roleService',
        meta: {
          requireAuth: true,
        },
        component: resolve => require(['./views/jurisdiction/role/role.vue'], resolve)
      },
      {
        path: '/user',
        name: 'userService',
        meta: {
          requireAuth: true,
        },
        component: resolve => require(['./views/jurisdiction/admin/admin.vue'], resolve)
      }
       
    ]
  }
];
export default new VueRouter({
  mode: 'hash',
  base: '/',
  routes: routerConfig
})
