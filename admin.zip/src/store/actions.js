"use strict";

import vue from 'vue'
import axios from '../http'
import router from '../router'

/***************************************
 * 登录
 **************************************/
export const userSignIn = ({commit},obj) => {
    //对应传入的对象内的url,params,redirect
	axios.post(obj.url,obj.params)
	.then(response => {
		console.log('用户登录反馈')
		// 这里目前没有提供token，所以resCode代替token
        //commit触发mutation里的USER_SIGN_IN,登录
        commit('USER_SIGN_IN', {
			token : response.data.resCode,
			user  : response.data.repBody.crmGetCodeRsp,
		})
		router.push(obj.redirect)
	})
	.catch(error => {
		console.log('用户请求失败')
		console.log(error)
	})
}
/***************************************
 * 退出
 **************************************/
export const userSignOut = ({commit},obj) => {
    //commit触发mutation里的USER_SIGN_OUT,退出
	commit('USER_SIGN_OUT');
	router.push(obj.redirect)
};

/***************************************
 * 设置二维码及序列号
 **************************************/
export const setCode = ({commit},obj) => {
	console.log('获取url参数')
	console.log(obj)
    //commit触发mutation里的SET_CODE.设置二维码
	commit('SET_CODE',{
		code : obj.code,
		sn   : obj.sn
	})
}
/***************************************
 * 进入登录页面
 **************************************/
export const loginPage = ({commit},obj) => {
    //对应传入的对象内的url,params,redirect
    console.log(obj.redirect);
    // commit('LOGIN_PAGE');
    router.push(obj.redirect)

}