"use strict";

export const user = state => state.user
export const token = state => state.token

export const areaCodes = state => state.areaCodes
export const workerCode = state => state.workerCode
export const workerSn = state => state.workerSn