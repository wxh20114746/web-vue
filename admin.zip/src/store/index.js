"use strict";

import Vue from 'vue'
import Vuex from 'vuex'

import * as actions from './actions'
import * as getters from './getters'
import mutations from './mutations'

Vue.use(Vuex)

const state = {
	user : (localStorage.user && localStorage.user !="undefined") ? JSON.parse(localStorage.user) : {},
	token: localStorage.token || null,
	areaCodes:['029','0911','0912','0913','0914','0915','0916','0917','0919'], // 区号
	workerCode : localStorage.workerCode || null,//扫到的二维码
	workerSn : localStorage.workerSn || null,
    pages : '' || null,
    count: 0,
    color: ['#325B69', '#698570', '#AE5548', '#6D9EA8', '#9CC2B0', '#C98769']
}

const debug = process.env.NODE_ENV !== 'production'

export default new Vuex.Store({
	state,
	actions,
	getters,
	mutations,
	strict: debug
})
