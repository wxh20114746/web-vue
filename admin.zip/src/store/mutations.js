"use strict";

export default {
	// 获取用户信息
	USER_INFO (state, _user) {
	},
	// 登录
	USER_SIGN_IN (state, data) {
		localStorage.token = data.token
		localStorage.user = JSON.stringify(data.user)
        state.token = data.token
		console.log('登录成功')
	},
	// 退出
	USER_SIGN_OUT(state) {
		localStorage.removeItem('token');
		localStorage.removeItem('user');
        state.token = null
        state.user = {}
        console.log('退出登录')
	},
	// 设置二维码及序列号
	SET_CODE(state,data) {
		localStorage.workerCode = data.code
		localStorage.workerSn = data.sn
        state.workerCode = data.code
        state.workerSn  = data.sn
        console.log('获取二维码成功')
        console.log(data)
	},
    //进入登录页面
    LOGIN_PAGE(state) {

    },
}