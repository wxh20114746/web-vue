<template>
  <div class="loft">
    <el-row class="tool">
      <el-col :span="24">
        <div class="grid-content bg-purple toolbar">
          <el-form :inline="true" class="demo-form-inline">
            <el-form-item label="" style="width: 120px;" class="oinput3 keywordQuery">
              <el-input
                placeholder="车架号"
                v-model="formInline.qrcode"
                clearable >
              </el-input>
            </el-form-item>
            <el-form-item label="" style="width: 120px;" class="oinput3 keywordQuery">
              <el-input
                placeholder="二维码号"
                v-model="formInline.custName"
                clearable >
              </el-input>
            </el-form-item>
             <el-form-item label="" class="oinput3">
               <el-select  v-model="chzId" placeholder="全部车检站" clearable>  
                   <el-option :label="item.aileas" :value="item.id" v-for="item in stationList"></el-option> 
            </el-select>
          </el-form-item>
               <el-form-item label="" class="oinput3">
                <el-select v-model="formInline.zhanghao" placeholder="全部账号" clearable>
                  <el-option>全部账号</el-option>
                  <el-option>深圳北车检公司1</el-option>
                  <el-option>深圳北车检公司2</el-option>
                  <el-option>深圳北车检公司3</el-option>
                </el-select>
          </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="flushPage" class="serSub" icon="search">查询</el-button>
            </el-form-item>
            <el-form-item>
              <a :href="baseUrl+'/qrcode/exportCust?'" download="客户经理绑码信息" class="download-cust"><el-button type="primary" class="serSub" icon="upload2">导出</el-button></a>
            </el-form-item>
          </el-form>
        </div>
      </el-col>
    </el-row>
    <el-table :data="tableData" style="width: 100%;color:#5d5d61;font-size: 13px" border v-loading="loading" highlight-current-row @current-change="handleCurrentChange" ref="loftLi">
      <el-table-column align="center" prop="qrcode" label="二维码号">
      </el-table-column>
      <el-table-column align="center" prop="vin" label="车架号">
      </el-table-column>
      <el-table-column align="center" prop="cisName" label="打码车检站">
      </el-table-column>
      <el-table-column align="center" prop="account" label="账号">
      </el-table-column>
      <el-table-column align="center" prop="bindQrcodeType" label="打码类型">
      </el-table-column>
      <el-table-column align="center" prop="bindTime" label="打码时间">
      </el-table-column>
    </el-table>
    <page-bar :changePage="changePage" class="f-r clearfix" :pageMsg="pageMsg" ref="pageRef"></page-bar>
  </div>
</template>
<script>
  import echarts from 'echarts';
  import session from '../../utils/session'
  import '../../../node_modules/echarts/theme/vintage.js';
  import {
    Message
  } from 'element-ui';
  import pageBar from '../../../src/components/pageBar.vue'
  import axios from 'axios'
  export default {
    components: {
      pageBar
    },
    data() {
      return {
        chzId:'',
        stationList:[],
        filialeArr: [],
        formInline: {
          qrcode:'',
          custName:'',
          custPhone:'',
          cjz:'',
          zhanghao:''
        },
        pageMsg: {
          pageSum: '',
          //总页码
          pageList: [],
          //单页数量
          pageSize: 10,
          //商品总数
          totalCount: '',
          list: []
        },
        tableData: [],
        loading:false,
        baseUrl:''
      }
    },
    created() {
      // this.changePage(1);
      this.baseUrl = axios.defaults.baseURL;
      this.frameList();
      this.getallstation();
    },
    mounted() {
    },
    activated() {},
    methods: {
      //获取数据列表
        frameList(){
          let that = this;
          let msg = {
            data:{
              pageName:"pqQrcodeService",
              method:"qrcodeByTime",
              paginator:{limit:10,page:1},
              params:{vin:"",qrcode:"",cisId:"",account:""}
            }
          }
          that.axios.post('/page/list',JSON.stringify(msg))
          .then(res =>{
            if (res.data.resCode === '000000') {
              console.log( res.data.repBody.list)
              this.tableData = res.data.repBody.list;
            }
          })
          .catch(error =>{

          })
    },
        //获取所有车检站
      getallstation(){
       let msg = {}
          let that = this;
          that.axios.post('/cisCompany/queryAll', JSON.stringify(msg))
          .then(res => { 
              if (res.data.resCode === '000000') { 
                  that.stationList = res.data.repBody;
              }
          })
          .catch(error => { 

          })
      },
      formatter(row, column) {
        return row.date;
      },
      handleCurrentChange(val) {
        this.currentRow = val;
      },
      //渲染列表
      changePage(num) {
        this.loading = true;
        let msg = {
          data: {
            "pageName": 'qRCodeService',
            "paginator": {
              "limit": 10,
              "page": num
            },
            "params": {
              "qrcode": this.formInline.qrcode,
              "method": "listByPageCust",
              "custName": this.formInline.custName,
              "custPhone":this.formInline.custPhone
            }
          }
        };
        this.axios.post('/page/list', JSON.stringify(msg))
          .then(res => {
            if (res.data.resCode === '000000') {
              //渲染处理函数
              this.loading = false;
              this.tableData = res.data.repBody.list;
              this.pageMsg.pageList = [];
              this.pageMsg.totalCount = res.data.repBody.paginator.totalCount;
              this.pageMsg.pageSum = res.data.repBody.paginator.totalPages;
              for (let i = 1; i <= this.pageMsg.pageSum; i++) {
                this.pageMsg.pageList.push(i);
              }
              if ((num - 1) % 5 === 0) {
                this.pageMsg.list = this.pageMsg.pageList.slice(num - 1, num + 4);
              } else if (num == 1) {
                this.pageMsg.list = this.pageMsg.pageList.slice(0, 5);
              } else if (num == this.pageMsg.pageSum && (num % 5) == 0) {
                this.pageMsg.list = this.pageMsg.pageList.slice(num - 5, num);
              } else if (num == this.pageMsg.pageSum && (num % 5) !== 0) {
                let nn = num % 5;
                this.pageMsg.list = this.pageMsg.pageList.slice(num - nn, num);
              } else if ((num) % 5 == 0) {
                this.pageMsg.list = this.pageMsg.pageList.slice(num - 5, num);
              } else {
                this.pageMsg.list = list
              }

            } else {
              this.loading = false;
              let message = "请求失败";
              this.$message({
                type: 'info',
                message: message
              });
            }
          })
          .catch(error => {
            this.loading = false;
            let message = "请求异常"
            this.$message({
              type: 'info',
              message: message
            });
          });
      },
      flushPage(){
        this.$refs.pageRef.parentFlush();
      }
    },
    watch: {
      'valueForm' (newVal, oldVal) {
        if (newVal == '') {
          this.changeHandlerForm('', '')
        }
      }
    }
  }
</script>

<style lang="less" rel="stylesheet/less" scoped>
  @import '../../assets/css/property.less';
  .loft {
    padding: 0 0 20px;
    /*width: 100%;*/
    /*min-width: 1008px;*/
    .tool {
      padding: 10px;
      /*font-size:12px;*/
    }
    /*报障数据分析*/
    .control-bar-wrapper {
      margin-bottom: 20px;
      .control-bar {
        line-height: 44px;
        border: 1px solid #DDD;
        background-color: #f9f9f9;
        /*width: 100%;*/
        height: auto;
        /*height: 44px;*/
        /*box-sizing: border-box;*/
        .date-select-bar {
          /*margin-top: 9px;*/
          padding-left: 8px;
          padding-right: 7px;
          /*margin-bottom: 13px;*/
          /*height: 22px;*/
          /*line-height: 22px;*/
          a {
            display: inline-block;
            color: #666;
            height: 18px;
            line-height: 18px;
            padding: 4px 7px;
            font-size: 12px;

          }
        }
      }
    }
    .defaultInline {
      position: relative;
      .defaultDate {
        position: absolute;
        top: 1px;
        left: 11px;
        color: #1f2d3d;
        font-weight: 400;
        font-family: system-ui;
        font-size: 13px;
        z-index: 999;
      }
    }
    #getupbar2,
    #getuppie {
      position: relative;
      /*width: 90%;*/
      /*width: 1049px;*/
      /*width: 48%;*/
      /*left: 50%;*/
      height: 500px;
      /*margin-left: -45%;*/
      /*box-shadow: 0 0 10px #BF382A;*/
      /*border-radius: 10px;*/
      -webkit-tap-highlight-color: transparent;
      user-select: none;
      margin: 0 auto;
    }
    #getuppie {
      /*margin-top: 30px;*/
    }

    .el-row2 {
      margin-top: 67px;
    }

    /*.el-tag--primary{*/
    /*height: 32px;*/
    /*line-height: 32px;*/
    /*font-size:14px;*/
    /*}*/
    .download-loft {
      display: inline-block;
      /*width: 79px;*/
      width: 120px;
      height: 36px;
      /*margin-left:15px;*/
      .el-button {
        width: 120px;
      }
    }
    /*设置关键字搜索框的长度*/
    .keywordQuery {
      width:  260px;
    }
  }

  @media screen and (max-width: 470px) {
    #getuppie {
      height: 500px;
    }
    #texta {}
  }
</style>
