<template>
<div class="loft">
  <el-row class="tool">
    <el-col :span="24">
      <div class="grid-content bg-purple toolbar">
        <el-form :inline="true" class="demo-form-inline">
          <el-form-item label="" style="width: 120px;" class="oinput3 keywordQuery">
          <el-input
              placeholder="车架号"
              v-model="formInline.deviceSn"
              clearable >
            </el-input>
          </el-form-item>
          <el-form-item label="" style="width: 120px;" class="oinput3 keywordQuery">
          
              <el-input
              placeholder="二维码号"
              v-model="formInline.qrcode"
              clearable >
            </el-input>
          </el-form-item> 
             <el-form-item label="" class="oinput3 selectWidth">
             <el-select  v-model="chzId" placeholder="全部车检站" clearable>  
                   <el-option :label="item.aileas" :value="item.id" v-for="item in stationList"></el-option> 
            </el-select>
          </el-form-item>
          <el-form-item label="" class="oinput3 selectWidth">
            <el-select v-model="formInline.filiale" placeholder="选择次数" clearable>
              <el-option label="不限次数" value="0">不限次数</el-option>
              <el-option label="小于3次" value="1">小于3次</el-option>
              <el-option label="3~5次" value="3">3~5次</el-option>
              <el-option label="大于5次" value="5">大于5次</el-option>
            </el-select>
          </el-form-item>
               <el-form-item label="" class="oinput3 selectWidth">
                <el-select v-model="formInline.zhanghao" placeholder="全部账号" clearable>
                  <el-option v-for="item in adminList" :label="item.userName" :value="item.userId">{{item.userName}}</el-option> 
                </el-select>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="flushPage" class="serSub" icon="search">查询</el-button>
          </el-form-item>
          <el-form-item>
            <a :href="baseUrl+'/qrcode/exportByVIN?vin='+formInline.deviceSn+'&qrcode='+formInline.qrcode+'&cisId='+chzId+'&sumSize='+formInline.filiale" download="码查询信息" class="download-cust"><el-button type="primary" class="serSub" icon="upload2">导出</el-button></a>
          </el-form-item>
        </el-form>
      </div>
    </el-col>
  </el-row>
  <el-table :data="tableData" style="width: 100%;color:#5d5d61;font-size: 13px" border v-loading="loading" highlight-current-row @current-change="handleCurrentChange" ref="loftLi">
    <el-table-column align="center" prop="vin" label="车架号">
    </el-table-column>
    <el-table-column align="center" prop="catType" label="车辆类型">
    </el-table-column>
    <el-table-column align="center" prop="qrcode" width="150" label="二维码号">
    </el-table-column>
    <el-table-column align="center" prop="cisName" width="300" label="打码车检站">
    </el-table-column>
    <el-table-column align="center" prop="bindTime"  width="250" label="绑定时间">
    </el-table-column>
    <el-table-column align="center" prop="account" label="绑定账号">
    </el-table-column> 
    <el-table-column align="center" prop="sprayNum" label="打码">
    </el-table-column>
    <el-table-column align="center" prop="supplementNum" label="补打">
    </el-table-column>
    <el-table-column align="center" prop="sumNum" label="总计次数">
    </el-table-column>
  </el-table>
  <page-bar :changePage="changePage" class="f-r clearfix" :pageMsg="pageMsg" ref="pageRef"></page-bar>
</div>
</template>
<script>
import echarts from 'echarts';
import session from '../../utils/session'
import '../../../node_modules/echarts/theme/vintage.js';
import {
  Message
} from 'element-ui';
import pageBar from '../../../src/components/pageBar.vue'
import axios from 'axios'
export default {
  components: {
    pageBar
  },
  data() {
    return {
      stationList:[],
      adminList:[],
      chzId:'',
      filialeArr: [],
      formInline: {
        qrcode:'',
        deviceSn:'',
        staffNo:'',
        filiale:'',
        zhanghao:''
      },
      pageMsg: {
        pageSum: '',
        //总页码
        pageList: [],
        //单页数量
        pageSize: 10,
        //商品总数
        totalCount: '',
        list: []
      },
      tableData: [],
      loading:false,
      baseUrl:''
    }
  },
  created() {
    // this.getRegion();
    this.baseUrl = axios.defaults.baseURL;
    this.frameList(1);
     this.getallstation();
     this.getallAdmin();
    // this.changePage(1)
  },
  mounted() {
  },
  activated() {},
  methods: {
    //获取所有账号
    getallAdmin(){
       let msg = {}
          let that = this;
          that.axios.post('/user/clientAccountAll', JSON.stringify(msg))
          .then(res => { 
              if (res.data.resCode === '000000') { 
                  that.adminList = res.data.repBody;
              }
          })
          .catch(error => { 

          })
    },
    //获取所有车检站
      getallstation(){
       let msg = {}
          let that = this;
          that.axios.post('/cisCompany/queryAll', JSON.stringify(msg))
          .then(res => { 
              if (res.data.resCode === '000000') { 
                  that.stationList = res.data.repBody;
              }
          })
          .catch(error => { 

          })
      },
    formatter(row, column) {
      return row.date;
    },
    handleCurrentChange(val) {
      this.currentRow = val;
    },
    frameList(num){
      let that = this;
      let msg = {
        data:{
          pageName:"pqQrcodeService",
          method:"qrcodeByVIN",
          paginator:{limit:10,page:1},
          params:{vin:"",qrcode:"",cisId:"",sumSize:"",account:''}
        }
      }
      that.axios.post('/page/list',JSON.stringify(msg))
      .then(res =>{
        if (res.data.resCode === '000000') { 
         
           let warningItem = res.data.repBody.list.map((value, index) => {
                       return {
                          account:value.account, 
                          catType:value.catType,
                           bindTime: (new Date(value.bindTime)).toLocaleString(),
                           cisName:value.cisName,
                           qrcode:value.qrcode,
                           size:value.size ,
                           sprayNum:value.sprayNum ,
                           sumNum:value.sumNum ,
                           supplementNum:value.supplementNum ,
                          vin:value.vin
                       }
                   });
            this.tableData = warningItem;
             if(num=='1'){
                this.pageIf=true;
             }
            this.pageMsg.pageList = [];
            this.pageMsg.totalCount = res.data.repBody.paginator.totalCount;
            this.pageMsg.pageSum = res.data.repBody.paginator.totalPages;
            for (let i = 1; i <= this.pageMsg.pageSum; i++) {
              this.pageMsg.pageList.push(i);
            }
            if ((num - 1) % 5 === 0) {
              this.pageMsg.list = this.pageMsg.pageList.slice(num - 1, num + 4);
            } else if (num == 1) {
              this.pageMsg.list = this.pageMsg.pageList.slice(0, 5);
            } else if (num == this.pageMsg.pageSum && (num % 5) == 0) {
              this.pageMsg.list = this.pageMsg.pageList.slice(num - 5, num);
            } else if (num == this.pageMsg.pageSum && (num % 5) !== 0) {
              let nn = num % 5;
              this.pageMsg.list = this.pageMsg.pageList.slice(num - nn, num);
            } else if ((num) % 5 == 0) {
              this.pageMsg.list = this.pageMsg.pageList.slice(num - 5, num);
            } else {
              this.pageMsg.list = list
            }
        }
      })
      .catch(error =>{

      })
    },
    //渲染列表
    changePage(num) {
      this.loading = true;
      let msg = {
            data:{
              pageName:"pqQrcodeService",
              method:"qrcodeByVIN",
              paginator:{limit:10,page:num},
              params:{
                vin:this.formInline.deviceSn,
                qrcode:this.formInline.qrcode,
                cisId:this.chzId,
                sumSize:this.formInline.filiale,
                account:this.formInline.zhanghao
              }
            }
          }
      this.axios.post('/page/list', JSON.stringify(msg))
        .then(res => {
          if (res.data.resCode === '000000') {
            //渲染处理函数
            this.loading = false;
                 let warningItem = res.data.repBody.list.map((value, index) => {
                       return {
                          account:value.account, 
                          catType:value.catType,
                           bindTime: (new Date(value.bindTime)).toLocaleString(),
                           cisName:value.cisName,
                           qrcode:value.qrcode,
                           size:value.size ,
                           sprayNum:value.sprayNum ,
                           sumNum:value.sumNum ,
                           supplementNum:value.supplementNum ,
                          vin:value.vin
                       }
                   });
            this.tableData = warningItem; 
            this.pageMsg.pageList = [];
            this.pageMsg.totalCount = res.data.repBody.paginator.totalCount;
            this.pageMsg.pageSum = res.data.repBody.paginator.totalPages;
            for (let i = 1; i <= this.pageMsg.pageSum; i++) {
              this.pageMsg.pageList.push(i);
            }
            if ((num - 1) % 5 === 0) {
              this.pageMsg.list = this.pageMsg.pageList.slice(num - 1, num + 4);
            } else if (num == 1) {
              this.pageMsg.list = this.pageMsg.pageList.slice(0, 5);
            } else if (num == this.pageMsg.pageSum && (num % 5) == 0) {
              this.pageMsg.list = this.pageMsg.pageList.slice(num - 5, num);
            } else if (num == this.pageMsg.pageSum && (num % 5) !== 0) {
              let nn = num % 5;
              this.pageMsg.list = this.pageMsg.pageList.slice(num - nn, num);
            } else if ((num) % 5 == 0) {
              this.pageMsg.list = this.pageMsg.pageList.slice(num - 5, num);
            } else {
              this.pageMsg.list = list
            }

          } else {
            this.loading = false;
            let message = "请求失败";
            this.$message({
              type: 'info',
              message: message
            });
          }
        })
        .catch(error => {
          this.loading = false;
          let message = "请求异常"
          this.$message({
            type: 'info',
            message: message
          });
        });
    },
    flushPage(){
      this.$refs.pageRef.parentFlush();
    },
    //获取所有区域
    getRegion() {
      var that = this;
      that.axios.post('/areaCode/findAll', {})
        .then(res => {
          if (res.data.resCode === '000000') {
            var allareaCode = new Object();
            allareaCode.areaCode = ''
            allareaCode.areaId = ''
            allareaCode.areaName = '所有分公司'
            that.filialeArr.push(allareaCode);
            res.data.repBody.map((value, index) => {
              that.filialeArr.push(value);
            });
          }
          this.changePage(1);
        })
        .catch(error => {
          this.changePage(1);
        })
    }
  },
  watch: {
    'valueForm' (newVal, oldVal) {
      if (newVal == '') {
        this.changeHandlerForm('', '')
      }
    }
  }
}
</script>

<style lang="less" rel="stylesheet/less" scoped>
@import '../../assets/css/property.less';
.loft {
    padding: 0 0 20px;
    /*width: 100%;*/
    /*min-width: 1008px;*/
    .tool {
        padding: 10px;
         white-space:nowrap;

        /*font-size:12px;*/
    }
    /*报障数据分析*/
    .control-bar-wrapper {
        margin-bottom: 20px;
        .control-bar {
            line-height: 44px;
            border: 1px solid #DDD;
            background-color: #f9f9f9;
            /*width: 100%;*/
            height: auto;
            /*height: 44px;*/
            /*box-sizing: border-box;*/
            .date-select-bar {
                /*margin-top: 9px;*/
                padding-left: 8px;
                padding-right: 7px;
                /*margin-bottom: 13px;*/
                /*height: 22px;*/
                /*line-height: 22px;*/
                a {
                    display: inline-block;
                    color: #666;
                    height: 18px;
                    line-height: 18px;
                    padding: 4px 7px;
                    font-size: 12px;

                }
            }
        }
    }
    .defaultInline {
        position: relative;
        .defaultDate {
            position: absolute;
            top: 1px;
            left: 11px;
            color: #1f2d3d;
            font-weight: 400;
            font-family: system-ui;
            font-size: 13px;
            z-index: 999;
        }
    }
    #getupbar2,
    #getuppie {
        position: relative;
        /*width: 90%;*/
        /*width: 1049px;*/
        /*width: 48%;*/
        /*left: 50%;*/
        height: 500px;
        /*margin-left: -45%;*/
        /*box-shadow: 0 0 10px #BF382A;*/
        /*border-radius: 10px;*/
        -webkit-tap-highlight-color: transparent;
        user-select: none;
        margin: 0 auto;
    }
    #getuppie {
        /*margin-top: 30px;*/
    }

    .el-row2 {
        margin-top: 67px;
    }

    /*.el-tag--primary{*/
    /*height: 32px;*/
    /*line-height: 32px;*/
    /*font-size:14px;*/
    /*}*/
    .download-loft {
        display: inline-block;
        /*width: 79px;*/
        width: 120px;
        height: 36px;
        /*margin-left:15px;*/
        .el-button {
            width: 120px;
        }
    }
  /*设置关键字搜索框的长度*/
  .keywordQuery {
    width:  260px;
  }
  .selectWidth{
    width:180px;
  }
}

@media screen and (max-width: 470px) {
    #getuppie {
        height: 500px;
    }
    #texta {}
}
</style>
