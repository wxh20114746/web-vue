<template>
  <!--设备管理-->
  <div class="work-order f-l">
    <!--工具条-->
<!--     <el-row class="tool">
      <el-col :span="24">
        <div class="grid-content bg-purple toolbar">
          <div id="DateSelectBar" class="date-select-bar">
            <el-button type="primary" id="equipment_btn" style="border:0;" @click="isCur=1">按车架号查询</el-button>
            <el-button  type="primary" id="cust_btn" style="background: #909399;border:0;" @click="isCur=2">按绑码记录查询</el-button>
          </div>
        </div>
      </el-col>
    </el-row> -->
    <!--渲染列表-->
    <device_code_list v-if="device_code_list"></device_code_list>
    <!-- <cust_code_list v-if="cust_code_list"></cust_code_list> -->
  </div>
</template>
<script type="text/ecmascript-6">
  import {
    Message
  } from 'element-ui';
  import device_code_list from './device.vue';
  // import cust_code_list  from './cust.vue';
  export default {
    components: {
      device_code_list,
      // key_code_list,
      // cust_code_list
    },
    data(){
      return {
        isCur: 1,
        device_code_list: true,
        key_code_list:false,
        // cust_code_list:false
      }
    },
    created() {
      document.title = '绑码查询';
       this.device_code_list = true;
    },
    methods: {
    },
    watch: {
      // 'isCur' (newVal, oldVal) {
      //   switch (newVal) {
      //     case 1:
      //       this.device_code_list = true;
      //       this.cust_code_list = false;
      //       document.getElementById("equipment_btn").style.background = "";
      //       document.getElementById("cust_btn").style.background = "#909399";
      //       break;
      //     case 2:
      //       this.device_code_list = false;
      //       this.cust_code_list = true;
      //       document.getElementById("equipment_btn").style.background = "#909399";
      //       document.getElementById("cust_btn").style.background = "";
      //       break;
      //     default:
      //       break
      //   }
      // },
    }
  }
</script>
<style lang="less" rel="stylesheet/less" scoped>
  @import '../../assets/css/property.less';
  .work-order {
    width: 100%;
    padding: 20px 20px 0;
    margin-left: 230px;
    min-width: 1008px;
    margin-top: 60px;
    /*border: 1px solid #ccc;*/
    .search {
      padding: 10px;
      width: 100%;
      height: 100px;
      border: 1px solid #ccc;
      .shuiping {
        line-height: 36px;
        vertical-align: middle;
      }
      .oinput {
        width: 193px;
      }
      .serSub {
        width: 120px;
        top: 0;
      }
      .addSub {
        width: 120px;
        margin-left: 16px;
      }
    }
    .el-row {
      margin-bottom: 20px;
      &:last-child {
        margin-bottom: 0;
      }
    }
    .tool {
      background-color: #f2f2f2;
      padding: 10px;
      border-radius: 2px;
      margin: 10px 0;

    }
    .el-col {
      border-radius: 4px;
      /*padding:10px;*/
    }
    .bg-purple-dark {
      background: #99a9bf;
    }
    .bg-purple {
      background: #f2f2f2;
    }
    .bread {
      padding-top: 2px;
      height: 24px;
      /*line-height: 50px;*/
      font-size: 14px;
    }
    .toolbar {
      /*background-color: #f2f2f2;*/
      /*padding: 10px;*/
      /*margin: 10px 0px;*/

      .add {
        font-size: 14px;
      }
      .el-form-item {
        margin-bottom: 0;
        /*.serSub{*/
        /*span{*/
        /*font-weight:200;*/
        /*font-size: 22px;*/
        /*color: #000;*/
        /*}*/
        /*}*/
      }
    }
    .serSub {
      white-space: nowrap;
      cursor: pointer;
      font-size: 14px;
      text-rendering: auto;
      letter-spacing: normal;
      word-spacing: normal;
      text-transform: none;
      text-indent: 0;
      text-shadow: none;
      /*字体变细的原因*/
      -webkit-font-smoothing: antialiased;
    }
    .addSub {
      white-space: nowrap;
      cursor: pointer;
      font-size: 14px;
      text-rendering: auto;
      letter-spacing: normal;
      word-spacing: normal;
      text-transform: none;
      text-indent: 0;
      text-shadow: none;
      /*字体变细的原因*/
      -webkit-font-smoothing: antialiased;
    }
  }

  #test {
    width: 200px;
    height: 100px;
    border: 1px solid #000;
  }

  .add {
    border-radius: 3px;
    width: 400px;
    height: 250px;
    position: fixed;
    top: 30%;
    left: 40%;
    border: 1px solid #ccc;
    background-color: #fff;
    .select-fa {
      width: 290px;
    }
    .btn {
      width: 138px;
    }
    z-index: 99;
  }
</style>
