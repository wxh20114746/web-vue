<template>
    <!--码管理-->
    <div class="work-order">
         
        <el-row class="tool">
            <div class="topJ"> 
                <span>激光机客户端管理</span>
                <button class="setUp" v-show="isNum" @click="setup">设置</button>
                <button class="setUp" v-show="!isNum" @click="optionUpdate">保存</button>
            </div>
             <div class="nakeCont">
             <ul>
                 <li v-for="(item,index) in optionList">
                     <span>{{item.name}}： <span class="lan" v-show="isNum">{{item.value}}</span>
                        <el-input v-show="!isNum"  :value="item.value" type="number" class="w50" min="0" max="99999"> </el-input>
                     </span> 
                 </li> 
             </ul> 
             </div>  
        </el-row> 
    </div>
</template>
<script type="text/ecmascript-6">
 

    export default { 
        data() {
            return {
               isNum:true,
               optionList:[] 
            } 
        },
        created () {
            document.title='批次管理';
            this.getpeizhi();
            //初始化列表
        }, 
        methods: {   
            //修改配置
            optionUpdate(){
                let that = this;
                let oInput = document.getElementsByTagName('input');
                let newArry = [];
                for(var i =0;i < oInput.length;i++){
                  if(oInput[i].value < 0 ){ 
                          that.$message({
                                type: 'info',
                                message: '请输入正整数'
                            });
                          return; 
                    }
                    if( oInput[i].value ==''){ 
                          that.$message({
                                type: 'info',
                                message: '请输入数字'
                            });
                          return; 
                    }
                    var obj ={}
                    obj.value= oInput[i].value 
                    obj.key =  that.optionList [i].key;
                    newArry.push(obj)
                  } 
                let msg = {"data":{"configs":newArry}}
                that.axios.post('/cisConfig/update',JSON.stringify(msg))
                .then(res => { 
                   if (res.data.resCode === '000000') {
                       that.$message({
                                type: 'info',
                                message: '修改成功'
                        });
                       this.isNum = !this.isNum;
                       that.getpeizhi();
                   }
                })
                .catch( error => {

                })
            },
            getpeizhi(){
                let that = this;
                let msg = {};
                that.axios.post('/cisConfig/queryAll',JSON.stringify(msg))
                .then(res => { 
                    that.optionList = res.data.repBody;
                })
                .catch( error => {

                })
            },
          setup(){
            this.isNum = !this.isNum;
          }
        }
    }
</script>
<style lang="less" rel="stylesheet/less">
    @import '../../assets/css/property.less';
    .work-order {
        padding: 20px 20px 0 20px;
        width: 100%;
        min-width:1008px;
        margin-left:230px;
        margin-top:60px;
      
        .tool{
            background-color: #f2f2f2;
            padding:10px;
            border-radius: 2px;
            margin: 10px 0px;

        }
        .nakeCont{
            
            ul{
               width: 760px; 
               overflow: hidden;  
            li{
                height: 50px;
                width: 280px;
                line-height: 50px;
                float: left;


                .r_span{
                    display: inline-block; 
                }
                .sr_span{
                    display: inline-block;
                    margin-left: 116px;
                }
                .lan{
                    color: blue;
                }
                .w50{
                    display: inline-block;
                    width: 80px;
                }
                 input[type='number']::-webkit-outer-spin-button,
                 input[type='number']::-webkit-inner-spin-button{
                    -webkit-appearance: none !important;
                    -moz-appearance:textfield;
                    margin: 0;
                }  
            }
            li:nth-child(2n){
                 margin-left: 180px;
            }
        }
        }
     .topJ{ 
         height: 50px;
         line-height: 50px;
         margin-bottom: 10px;

         span{
            font-weight: bold;
            /*color: #fff;*/
            display: inline-block;
            margin-right: 15px;
         }
         .setUp{
            display: inline-block;
            padding:10px 15px;
            background-color: #20a0ff;
            border:none; 
         border-radius: 4px;
         cursor: pointer;
         color: #fff;

         &:hover{

         }
         }
     }
 
        .serSub{
            white-space: nowrap;
            cursor: pointer;
            font-size: 14px;
            text-rendering: auto;
            letter-spacing: normal;
            word-spacing: normal;
            text-transform: none;
            text-indent: 0px;
            text-shadow: none;
            /*字体变细的原因*/
            -webkit-font-smoothing: antialiased;
        }
    }
</style>
