<template>
    <!--新建批次-->
    <div class="create">
        <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
            <el-form-item label="批次名称" prop="name">
                <el-input v-model="ruleForm.name" class="createtext"></el-input>
            </el-form-item>
            <el-form-item label="制码类型" prop="region">
                <el-select v-model="ruleForm.region" placeholder="二维码">
                    <el-option label="二维码" value="2"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="制码数量" prop="desc">
                <el-input v-model.number="ruleForm.desc" class="createtext"></el-input>
            </el-form-item>
            <!--操作按钮-->
            <el-form-item>
                <el-button type="primary" @click="adds(ruleForm)">立即创建</el-button>
                <el-button @click="resetForm('ruleForm')">重置</el-button>
                <el-button @click="close('ruleForm')">取消</el-button>
            </el-form-item>
        </el-form>
    </div>
</template>
<script type="text/ecmascript-6">
    export default {
        data() {
            return {
                //用户输入内容
                ruleForm: {
                    name: '',
                    region: '',
                    desc: ''
                },
                //限制
                rules: {
                    name: [
                        {required: true, message: '请输入批次名称', trigger: 'blur'},
                        {min: 3, max: 20, message: '长度在 3 到 20 个字符', trigger: 'blur'}
                    ],
                    region: [
                        {required: true, message: '请选择制码类型', trigger: 'change'}
                    ],
                    desc: [
                        {required: true, message: '请输入制码数量'},
                        {type: 'number', message: '制码数量必须为数字'}
                    ]
                }
            };
        },
        props: {
            isShowContro: {
                type: Function,
                default: null
            },
            onTex: {
                type: Function,
                default: null
            },
            add :{
                type: Function,
                default: null
            }
        },
        created () {

        },
        methods: {
            adds (ruleForm) {
                this.$refs.ruleForm.validate((valid) => {
                    if (valid) {
                        this.submitForm(ruleForm);
                    } else {
                        return false;
                    }
                });
            },
            //立即创建
            submitForm(ruleForm) {
                //关闭新建批次页面
                this.isShowContro();
                var warningItem = {};
                warningItem.qrname = this.ruleForm.name;
                warningItem.qrtype = this.ruleForm.region;
                warningItem.count = this.ruleForm.desc;
                warningItem.createTime = new Date(Date.parse(new Date())).toLocaleString();

                let msg = {
                    data: {
                        "batchName": this.ruleForm.name,
                        "codeNum": this.ruleForm.desc,                //制码数量
                        "codeType": this.ruleForm.region
                    }
                };

                var that = this;
                that.axios.post('/batch/addOrUpdateBatch', JSON.stringify(msg))
                    .then(res => {
                        if (res.data.resCode === '000000') {
                            warningItem.qrnum = res.data.repBody.batchId;
                            that.$message({
                                type: 'info',
                                message: '批次增加成功'
                            });
                            this.add();
                        }
                    })
                    .catch(error => {
                    })
                //发送查询请求,返回数组对象,拿到批次号等,插入页面
                //清空输入内容
                this.$refs[ruleForm].resetFields();
            },
            resetForm(formName) {
                //重置按钮
                this.$refs[formName].resetFields();
            },
            close (ruleForm) {
                this.isShowContro();
                this.$refs[ruleForm].resetFields();
            }
        }
    }
</script>
<style lang="less" rel="stylesheet/less" scoped>
    @import '../../assets/css/property.less';

    .create {
        border-radius: 5px;
        background-color: #fff;
        width: 400px;
        height: 300px;
        position: fixed;
        top: 30%;
        left: 40%;
        border: 1px solid #ccc;
        padding: 20px 10px;
        .createtext {
            width: 260px;
        }
        z-index: 99;
    }
</style>
