<template>
    <!--码管理-->
    <div class="work-order"> 
        <el-row class="tool">
            <el-col :span="24">
                <div class="grid-content bg-purple toolbar">
                    <el-form :inline="true" :model="formInline" class="demo-form-inline creatqr">
                        <el-form-item label="">
                            <el-input  v-model="formInline.qrname" placeholder="请输入批次名称" ></el-input>
                        </el-form-item>
                        <el-form-item label="">
                            <el-input  v-model="formInline.qrid" placeholder="请输入批次号"></el-input>
                        </el-form-item>
                        <el-form-item>
                            <el-button  type="primary" @click="onSubmit" class="serSub" icon="search">查询</el-button>
                        </el-form-item>
                        <el-form-item>
                            <el-button  type="primary" @click="creatqr" class="serSub">新建批次</el-button>
                        </el-form-item>
                    </el-form>
                </div>
            </el-col>
        </el-row>
        <!--列表-->
        <detlist :tableData="tableData" v-loading="loading" :changeData="changeData" :search="search" ref="detqr"></detlist>
        <!--新建批次-->
        <transition name='fade' mode='out-in'>
            <create v-if="isShow" :isShowContro="isShowContro" :onTex="onTex" :add="add"></create>
        </transition>
    </div>
</template>
<script type="text/ecmascript-6">

    import detlist from './detlist.vue';
    import create from './create.vue';

    export default {
        components: {
            detlist,
            create
        },
        data() {
            return {
                isShow: false,
                //查询条件
                formInline: {
                    qrname: '',
                    qrid: ''
                },
                //列表数据
                tableData: [],
                loading:false,
                title:'批次管理',
                search:{
                    batchName: '',
                    batchId: ''
                }
            }
        },
        created () {
            document.title='批次管理';
            //初始化列表
        },
        methods: {
            //查询
            onSubmit() {
                var that=this;
                // if (this.formInline.qrname ===''&&this.formInline.qrid ==='') {
                //     that.$message({
                //         type: 'info',
                //         message: '查询条件不能为空'
                //     });
                //     return false;
                // }
                this.search={
                    batchName: this.formInline.qrname,
                    batchId: this.formInline.qrid
                }
            },
            isShowContro () {
                this.isShow = !this.isShow;
            },
            creatqr () {
                this.isShow = true;
            },
            onTex (val) {

                this.$refs.detqr.tableData.push(val);
            },
            transition (val) {
                let result;
                if(val=='1'){
                    result='普通二维码'
                }
                if(val=='2'){
                    result='数字条形码'
                }
                if(val=='4'){
                    result='数字验证码'
                }
                if(val=='8'){
                    result='微型二维码'
                }
                return result
            },
            changeData (val) {
                this.tableData=val;
            },
            reload () {
                this.$router.push({
                    path: '/empty'
                })
            },
            add () {
                this.search={
                    batchName: '',
                    batchId: ''
                }
            }
        }
    }
</script>
<style lang="less" rel="stylesheet/less">
    @import '../../assets/css/property.less';
    .work-order {
        padding: 20px 20px 0 20px;
        width: 100%;
        min-width:1008px;
        margin-left:230px;
        margin-top:60px;
        .search {
            padding: 10px 10px;
            width: 100%;
            height: 100px;
            border: 1px solid #ccc;
            /*.creatqr {*/
                /*margin: 30px 5px;*/
            /*}*/
            .oinput {
                width: 193px;
            }
        }
        .el-row {
            margin-bottom: 20px;
            &:last-child {
                margin-bottom: 0;
            }
        }
        .tool{
            background-color: #f2f2f2;
            padding:10px;
            border-radius: 2px;
            margin: 10px 0px;

        }
        .el-col {
            border-radius: 4px;
            /*padding:10px;*/
        }
        .bg-purple-dark {
            background: #99a9bf;
        }
        .bg-purple {
            background: #f2f2f2;
        }
        .bread {
            padding-top: 2px;
            height: 24px;
            /*line-height: 50px;*/
            font-size: 14px;
        }
        .toolbar {
            /*background-color: #f2f2f2;*/
            /*padding: 10px;*/
            /*margin: 10px 0px;*/

            .add{
                font-size:14px;
            }
            .el-form-item {
                margin-bottom: 0px;
                /*.serSub{*/
                /*span{*/
                /*font-weight:200;*/
                /*font-size: 22px;*/
                /*color: #000;*/
                /*}*/
                /*}*/
            }
        }
        .serSub{
            white-space: nowrap;
            cursor: pointer;
            font-size: 14px;
            text-rendering: auto;
            letter-spacing: normal;
            word-spacing: normal;
            text-transform: none;
            text-indent: 0px;
            text-shadow: none;
            /*字体变细的原因*/
            -webkit-font-smoothing: antialiased;
        }
    }
</style>
