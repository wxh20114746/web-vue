<template>
<div class="_empty"></div>
</template>
<script type="text/ecmascript-6">
    export default{
        created () {
//            满足当前路由刷新
//            this.$router.back(-1)
            this.$router.push({ name: localStorage.getItem("pages")});
        }
    }
</script>
<style lang="stylus" rel="stylesheet/stylus">

</style>
