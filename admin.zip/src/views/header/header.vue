<template>
    <div class="header">
        <div class="left f-l">
            <img data-v-7ad4e6e1=""
                 src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4w
                                   IiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+Cjxzdmcgd2l
                                   kdGg9IjMwcHgiIGhlaWdodD0iMzBweCIgdmlld0JveD0iMCAwIDM4IDQ4IiB
                                   2ZXJzaW9uPSIxLjEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2
                                   ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsi
                                   PgogICAgPCEtLSBHZW5lcmF0b3I6IFNrZXRjaCA0MCAoMzM3NjIpIC0gaHR0c
                                   DovL3d3dy5ib2hlbWlhbmNvZGluZy5jb20vc2tldGNoIC0tPgogICAgPHRpdG
                                   xlPlNoYXBlIENvcHk8L3RpdGxlPgogICAgPGRlc2M+Q3JlYXRlZCB3aXRoIFN
                                   rZXRjaC48L2Rlc2M+CiAgICA8ZGVmcz48L2RlZnM+CiAgICA8ZyBpZD0idjIuM
                                   i4wIiBzdHJva2U9Im5vbmUiIHN0cm9rZS13aWR0aD0iMSIgZmlsbD0ibm9uZSI
                                   gZmlsbC1ydWxlPSJldmVub2RkIj4KICAgICAgICA8ZyBpZD0i6aaW6aG1Lem7m
                                   OiupOaViOaenC1jb3B5LTIiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC03MC4wMDA
                                   wMDAsIC0xOS4wMDAwMDApIiBmaWxsPSIjRkZGRkZGIj4KICAgICAgICAgICAgP
                                   HBhdGggZD0iTTIxMi4xMzU0NDEsNDUuMTU3ODA3NyBaIE0xMDMuNDE2NTAyLDQ2
                                   LjIxNzU1MTEgQzEwMy40MDcwMDgsNDcuNzk0NTY4MiAxMDIuNTg3ODQxLDQ4Lj
                                   E0NjM0NzQgMTAyLjU4Nzg0MSw0OC4xNDYzNDc0IEMxMDIuNTg3ODQxLDQ4LjE0
                                   NjM0NzQgODguNDUyMDQ3OCw1Ni4zMTQ1MDg3IDg3LjUzMjk5NTYsNTYuODI2Mjc
                                   1MSBDODYuNjIyMzM2LDU3LjIxNzE1NjEgODYuMDEzNjcwMyw1Ni44MjYyNzUxID
                                   g2LjAxMzY3MDMsNTYuODI2Mjc1MSBDODYuMDEzNjcwMyw1Ni44MjYyNzUxIDcxL
                                   jIyMjU3MDYsNDguMjQ3OTU3MiA3MC42ODI2OTYyLDQ3Ljg3MDg0NDQgQzcwLjE0
                                   MjY4NDMsNDcuNDkzNzMxNiA3MC4xMzAxNjQzLDQ2LjkwNjM3NzQgNzAuMTMwMTY
                                   0Myw0Ni45MDYzNzc0IEM3MC4xMzAxNjQzLDQ2LjkwNjM3NzQgNzAuMTQ1MDIzMi
                                   wyOS45MTk5MTc0IDcwLjEzMDE2NDMsMjkuMTMzMzM2NCBDNzAuMTE1MzA1MywyO
                                   C4zNDY2MTc3IDcxLjA5Njk1NzYsMjcuNzU1NTQ2MSA3MS4wOTY5NTc2LDI3Ljc1
                                   NTU0NjEgTDg1Ljg3NTUzNzMsMTkuMjEzNDM4NyBDODYuNzg1MzcxNCwxOC43MzMy
                                   MDE2IDg3LjY3MTEyODYsMTkuMjEzNDM4NyA4Ny42NzExMjg2LDE5LjIxMzQzODc
                                   gQzg3LjY3MTEyODYsMTkuMjEzNDM4NyAxMDAuNzI2NjIzLDI2LjgwMjA5MzcgMTA
                                   yLjE3MzQ0MiwyNy42MTc3MjU3IEMxMDMuNTkxNTA3LDI4LjI5MTk1NzcgMTAzLjQ
                                   xNjUwMiwyOS42ODQzNDI0IDEwMy40MTY1MDIsMjkuNjg0MzQyNCBDMTAzLjQxNjU
                                   wMiwyOS42ODQzNDI0IDEwMy40MjUzMDcsNDQuNzUxOTE5MiAxMDMuNDE2NTAyLDQ
                                   2LjIxNzU1MTEgTDEwMy40MTY1MDIsNDYuMjE3NTUxMSBaIE05Ny41MTYwMTA1LDI
                                   5LjE2OTEzMzkgQzk0LjQ5MDAxNzMsMjcuNDI3NDQ4MyA4Ny4zNjE1ODQyLDIzLjI5
                                   NzEwNjMgODcuMzYxNTg0MiwyMy4yOTcxMDYzIEM4Ny4zNjE1ODQyLDIzLjI5NzEw
                                   NjMgODYuNjY2MTAzOSwyMi45MjEyMzI2IDg1Ljk1MTc3NDcsMjMuMjk3MTA2MyBM
                                   NzQuMzQ4NzQwNiwyOS45ODIxNSBDNzQuMzQ4NzQwNiwyOS45ODIxNSA3My41Nzgw
                                   MDI1LDMwLjQ0NDkwMTQgNzMuNTg5Njk3LDMxLjA2MDQ4MDUgQzczLjYwMTM5MTUsM
                                   zEuNjc2MDU5NyA3My41ODk2OTcsNDQuOTY5ODcwOCA3My41ODk2OTcsNDQuOTY5OD
                                   cwOCBDNzMuNTg5Njk3LDQ0Ljk2OTg3MDggNzMuNTk5NDY1NCw0NS40Mjk1OTMyIDc
                                   0LjAyMzQ5NTEsNDUuNzI0NjQ3MiBDNzQuNDQ3Mzg3Myw0Ni4wMTk3MDExIDg2LjA2
                                   MDE4OTgsNTIuNzMzMjQ1MSA4Ni4wNjAxODk4LDUyLjczMzI0NTEgQzg2LjA2MDE4O
                                   TgsNTIuNzMzMjQ1MSA4Ni41MzgxNTIsNTMuMDM5MTc1OSA4Ny4yNTMwMzE1LDUyLj
                                   czMzI0NTEgQzg3Ljk3NDY1MjYsNTIuMzMyNzI2MiA5OS4wNzMwMzM1LDQ1Ljk0MDI1
                                   ODIgOTkuMDczMDMzNSw0NS45NDAyNTgyIEM5OS4wNzMwMzM1LDQ1Ljk0MDI1ODIgO
                                   TkuNzE2MjMyNSw0NS42NjQ4OTI5IDk5LjcyMzY2MTksNDQuNDMwNzA1NiBDOTkuNz
                                   I1NzI1Nyw0NC4wNzQ3OTU5IDk5LjcyNjU1MTIsNDIuNjkzMjg4MSA5OS43MjY2ODg3
                                   LDQwLjk1NzUyMjkgTDg2LjY2MDA1MDIsNDguODc1MjM5NCBMODYuNjYwMDUwMiw0NS
                                   44NDYyMjEgQzg2LjY2MDA1MDIsNDQuNjAyMTIwNSA4Ny42MjMxMjg5LDQzLjc4MDk4
                                   MTEgODcuNjIzMTI4OSw0My43ODA5ODExIEw5OS4xODA3NjA3LDM2LjgxNjU3OTMgQz
                                   k5LjYxNjg5NzgsMzYuMzYxMTI1MSA5OS43MDY4NzY4LDM1LjYzMTU0NDcgOTkuNzI1
                                   NDUwNSwzNS4zNTU2Mjg3IEM5OS43MjUwMzc4LDM0LjA5MDQ2MjcgOTkuNzI0NDg3NCw
                                   zMi45ODUyODQxIDk5LjcyNDA3NDcsMzIuMjg1MTY3OCBMODYuNjYwMDUwMiw0MC4yMD
                                   EyMzIxIEw4Ni42NjAwNTAyLDM3LjAzNDUzMSBDODYuNjYwMDUwMiwzNS43OTA0MzA1ID
                                   g3LjQ4NTU0NjIsMzUuMjQ0NjU2NCA4Ny40ODU1NDYyLDM1LjI0NDY1NjQgTDk3LjUxNj
                                   AxMDUsMjkuMTY5MTMzOSBaIiBpZD0iU2hhcGUtQ29weSI+PC9wYXRoPgogICAgICAgIDw
                                   vZz4KICAgIDwvZz4KPC9zdmc+" alt="element-logo" class="nav-logo-small ic">
        </div>
        <div class="user f-r">
            <div class="iconList f-l">
                <div class="i1" v-if="limit.business.length!='0'">
                    <router-link to="/main"><img src="../../common/fonts/img/gray/main.png" alt="" class="icon1"
                                                 v-if="this.$route.path==='/main'"><img
                            src="../../common/fonts/img/white/main.png" alt=""
                            class="icon1" v-else>
                        <p>首页</p></router-link>
                </div>
                <div class="i1" v-if="limit.business.length!='0'">
                    <router-link :to="businessRouter">
                        <img src="../../common/fonts/img/gray/business.png" alt="" class="icon1"
                             v-if="this.$route.path==='/workorder'||this.$route.path==='/assorder'||this.$route.path==='/custom'||this.$route.path==='/facility'||this.$route.path==='/slide'||this.$route.path==='/artificial'">
                        <img src="../../common/fonts/img/white/business.png" alt=""
                             class="icon1" v-else>
                        <p>业务管理</p></router-link>
                </div>
                <div class="i1" v-if="limit.code.length!='0'">
                    <router-link :to="codeRouter">
                        <img src="../../common/fonts/img/gray/code.png" alt="" class="icon1"
                             v-if="this.$route.path==='/creatqr'||this.$route.path==='/qr'">
                        <img src="../../common/fonts/img/white/code.png" alt="" class="icon1" v-else>
                        <p>码管理</p></router-link>
                </div>
                <div class="i1" v-if="limit.authority.length!='0'">
                    <router-link :to="authorityRouter">
                        <img src="../../common/fonts/img/gray/authority.png" alt="" class="icon1"
                             v-if="this.$route.path==='/admin'||this.$route.path==='/role'||this.$route.path==='/password'">
                        <img src="../../common/fonts/img/white/authority.png" alt="" class="icon1" v-else>
                        <p>权限管理</p></router-link>
                </div>
            </div>
          <el-breadcrumb separator="/" class="titleTips f-r" v-if="complaintWarnFlag">
            <el-breadcrumb-item :to="{ path: '/evaluamanage' }"><span style="color:#fff;font-size: 14px;cursor:pointer;">您有新的投诉待处理！</span><img src="../../common/fonts/img/gray/complaintWarn.png"/></el-breadcrumb-item>
          </el-breadcrumb>
          <el-breadcrumb separator="/" class="titleTips f-r" v-if="requireWarnFlag">
            <el-breadcrumb-item :to="{ path: '/evaluamanage',query: {id: 1}}"><span style="color:#fff;font-size: 14px;cursor:pointer;">您有新的需求待处理！</span><img src="../../common/fonts/img/gray/complaintWarn.png"/></el-breadcrumb-item>
          </el-breadcrumb>
            <div class="userName f-r">欢迎您<span>{{userNames}}</span>
                <span @click="log" class="logout">[退出]</span>
            </div>
        </div>
    </div>
</template>
<script type="text/ecmascript-6">
    import session from '../../utils/session'
    import {Message} from 'element-ui';
    export default {
        data () {
            return {
                timerName:'',
                userNames: '',
                rou: '',
                complaintWarnFlag:false,
                requireWarnFlag:false,
                limit:{
                    business:[],
                    code:[],
                    authority:[]
                },
                businessRouter:'',
                codeRouter:'',
                authorityRouter:'',
                tableData:[
                    {
                        "link":'/workorder',
                        "name":"工单管理"
                    },
                    {
                        "link":'/facility',
                        "name":"设备管理"
                    },
                    {
                        "link":'/slide',
                        "name":"图片管理"
                    },
                    {
                        "link":'/artificial',
                        "name":"数据报表"
                    },
                    {
                        "link":'/creatqr',
                        "name":"批次管理"
                    },
                    {
                        "link":'/qr',
                        "name":"码任务"
                    },
                    {
                        "link":'/admin',
                        "name":"人员信息"
                    },
                    {
                        "link":'/role',
                        "name":"角色管理"
                    },
                    {
                        "link":'/password',
                        "name":"修改密码"
                    }
                ]
            }
        },
        created () {
            var that=this;
            var limit=JSON.parse(localStorage.getItem('jurisdiction'));
            this.limit=limit;

            if((limit.business)[0]){
                var busF=(limit.business)[0].name;
            }
            if((limit.code)[0]){
                var codeF=(limit.code)[0].name;
            }
            if((limit.authority)[0]){
                var authorityF=(limit.authority)[0].name;
            }

            for (var x of this.tableData){
                if(busF==x.name){
                    that.businessRouter=x.link;
                }
                if(codeF==x.name){
                    that.codeRouter=x.link;
                }
                if(authorityF==x.name){
                    that.authorityRouter=x.link;
                }
            }
            this.userNames = localStorage.getItem("userNames");
            if(localStorage.getItem("jurisdiction").indexOf("投诉管理") !== -1){
              this.getComplainDetail();//获取投诉需求数量
              this.complaintCountTimer();//获取未投诉数量定时器
              this.requireCountTimer();//获取未投诉数量定时器
            }
        },
        methods: {
            logout () {

                let msg = {
                    data: {}
                };
                function getCookie(name)
                {
                    var arr,reg=new RegExp("(^| )"+name+"=([^;]*)(;|$)");

                    if(arr=document.cookie.match(reg))

                        return (arr[2]);
                    else
                        return null;
                }
                function delCookie(name)
                {
                    var exp = new Date();
                    exp.setTime(exp.getTime() - 1);
                    var cval=getCookie(name);
                    if(cval!=null)
                        document.cookie= name + "="+cval+";expires="+exp.toGMTString();
                }

                var that = this;
                that.axios.post('/user/logoff',JSON.stringify(msg))
                    .then(res => {
                if (res.data.resCode === '000000') {
                    this.$message({
                        type: 'success',
                        message: '退出登录成功'
                    });
                    delCookie('JSESSIONID');
                    localStorage.clear();
                    sessionStorage.clear();
                    this.$router.push('/login');
                }
                })
            .catch(error => {
            })
            },
            log (index, row) {
                this.$confirm('此操作将退出, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.clearTiemr();
                    this.logout(index, row);
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消'
                    });
                });
            },
          clearTiemr(){
            window.clearInterval(this.timerName);
          },

          getComplainDetail(){
            var msg = {
              data: {}
            };
            this.axios.post('/complainDetail/count',JSON.stringify(msg))
              .then(res => {
                if (res.data.resCode === '000000') {
                  if(res.data.repBody.complainNum>0){
                    this.complaintWarnFlag = true;
                    localStorage.setItem('complainDetailCountFlag','show');
                    localStorage.setItem('requireDetailCountFlag','hide');
                  }else if(res.data.repBody.requireNum>0){
                    if(false == this.complaintWarnFlag){
                      this.requireWarnFlag = true;
                      localStorage.setItem('requireDetailCountFlag','show');
                      localStorage.setItem('complainDetailCountFlag','hide');
                    }else{
                      localStorage.setItem('requireDetailCountFlag','hide');
                    }
                  }
                } else {
                  localStorage.setItem('complainDetailCountFlag','hide');
                  localStorage.setItem('requireDetailCountFlag','hide');
                  this.$message({
                    type: 'info',
                    message: "获取投诉数量失败"
                  });
                }
              })
              .catch(error => {
                localStorage.setItem('complainDetailCountFlag','hide');
                this.$message({
                  type: 'info',
                  message: "获取投诉数量异常"
                });
              });
          },
          requireCountTimer(){
            this.timerName = setInterval(() => {
              if('show' == localStorage.getItem('requireDetailCountFlag')){
                this.requireWarnFlag = true;
              }else if('hide' === localStorage.getItem('requireDetailCountFlag')){
                this.requireWarnFlag = false;
              }
            }, 2000)
          },
          complaintCountTimer(){
            this.timerName = setInterval(() => {
              if('show' == localStorage.getItem('complainDetailCountFlag')){
                this.complaintWarnFlag = true;
              }else if('hide' == localStorage.getItem('complainDetailCountFlag')){
                this.complaintWarnFlag = false;
              }
            }, 2000)
          },
        },
    }
</script>
<style lang="less" rel="stylesheet/less">
    @import '../../assets/css/property.less';
    html, body, div, span, applet, object, iframe,
    h1, h2, h3, h4, h5, h6, p, blockquote, pre,
    a, abbr, acronym, address, big, cite, code,
    del, dfn, em, img, ins, kbd, q, s, samp,
    small, strike, strong, sub, sup, tt, var,
    b, u, i, center,
    dl, dt, dd, ol, ul, li,
    fieldset, form, label, legend,
    table, caption, tbody, tfoot, thead, tr, th, td,
    article, aside, canvas, details, embed,
    figure, figcaption, footer, header,
    menu, nav, output, ruby, section, summary,
    time, mark, audio, video, input {
        margin: 0;
        padding: 0;
        border: 0;
        font-size: 100%;
        font-weight: normal;
        vertical-align: baseline;
    }

    /* HTML5 display-role reset for older browsers */
    article, aside, details, figcaption, figure,
    footer, header, menu, nav, section {
        display: block;
    }

    body {
        line-height: 1;
    }

    blockquote, q {
        quotes: none;
    }

    blockquote:before, blockquote:after,
    q:before, q:after {
        content: none;
    }

    table {
        border-collapse: collapse;
        border-spacing: 0;
    }

    /* custom */
    a {
        color: #7e8c8d;
        text-decoration: none;
        -webkit-backface-visibility: hidden;
    }

    li {
        list-style: none;
    }

    ::-webkit-scrollbar {
        width: 5px;
        height: 5px;
    }

    ::-webkit-scrollbar-track-piece {
        background-color: rgba(0, 0, 0, 0.2);
        -webkit-border-radius: 6px;
    }

    ::-webkit-scrollbar-thumb:vertical {
        height: 5px;
        background-color: rgba(125, 125, 125, 0.7);
        -webkit-border-radius: 6px;
    }

    ::-webkit-scrollbar-thumb:horizontal {
        width: 5px;
        background-color: rgba(125, 125, 125, 0.7);
        -webkit-border-radius: 6px;
    }

    html, body {
        width: 100%;
    }
    body {
        -webkit-text-size-adjust: none;
        -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
    }
    .header {
        width: 100%;
        min-width:1008px;
        height: 60px;
        background-color: #20A0FF;
        /*background-image: -webkit-gradient(linear,left top,right top,from(#1278f6),to(#00b4aa));*/
        /*background-image: -webkit-linear-gradient(left,#1278f6,#00b4aa);*/
        /*background-image: -moz-linear-gradient(left,#1278f6,#00b4aa);*/
        /*background-image: linear-gradient(to right,#1278f6,#00b4aa);*/
        /*position: relative;*/
        position: fixed;
        z-index: 999;
        /*display: flex;*/
        .left {
            /*flex:0 230px;*/
            width: 230px;
            height: 60px;
            /*background-color: #fff;*/
            border-right-width: 1px;
            border-right-style: solid;
            border-color: hsla(62, 77%, 76%, .3);
            .ic {
                margin-left: 16px;
                margin-top: 20px;
                font-size: 18px;
            }
        }

        .user {
            width: 50%;
            min-width:300px;
            height: 60px;
            /*color: #C1D5EC;*/
            color: #fff;
            /*padding: 10px 16px 0 0;*/
            font-size: 12px;
            /*line-height: 60px;*/
            position: relative;
            .userName {
                position: absolute;
                top: 40px;
                right: 15px;
                span {
                    padding-left: 10px;
                    padding-right: 8px;
                }
                a {
                    color: #c1d5ec;
                }
            }
            .titleTips{
              font-size: 14px;
              position: absolute;
              top: 15px;
              right: 15px;
              span {
                padding-left: 10px;
                padding-right: 8px;
              }
              a {
                color: #c1d5ec;
              }
            }
            .iconList {
                position: absolute;
                top: 10px;
                right: 200px;
                .i1 {
                    /*margin-top:10px;*/
                    padding: 0 10px;
                    /*margin-left:8px;*/
                    text-align: center;
                    width: 50px;
                    height: 50px;
                    display: inline-block;
                    font-family: "Helvetica Neue", Helvetica, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "微软雅黑", Arial, sans-serif;
                    font-size: 12px;
                    cursor: pointer;
                    vertical-align: middle;
                    p {
                        color: #fff !important;
                    }
                    .icon1 {
                        /*display: inline-block;*/
                        /*font-size: 16px;*/
                        width: 22px;
                        height: 22px;
                        /*background-image: url('../../common/fonts/img/white/二维码.png');*/
                        margin-bottom: 5px;
                    }

                }
            }

        }
        .clear {
            clear: both;
        }
        .icon {
            /*width: 1000px;*/

        }
    }
    .logout{
        color: #ccc;
        cursor: pointer;
    }


</style>
