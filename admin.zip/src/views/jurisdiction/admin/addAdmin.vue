<template>
    <div class="add-admin">
        <div class="headerAA"><span>添加管理员</span><i class="el-icon-circle-close f-r" @click="resetForm('ruleForm3')"></i>
        </div>
        <div class="content">
            <el-form :model="ruleForm3" :rules="rules2" ref="ruleForm3" label-width="100px" class="demo-ruleForm">
                <el-form-item label="账号" prop="account" class="input" :required="true">
                    <el-input v-model.number="ruleForm3.account" placeholder="请输入账号"></el-input>
                </el-form-item>
                <el-form-item label="密码" prop="pwd" class="input" :required="true">
                    <el-input type="password" v-model="ruleForm3.pwd" auto-complete="off"
                              placeholder="请输入密码"></el-input>
                </el-form-item>
                <el-form-item label="确认密码" prop="checkPass" class="input" :required="true">
                    <el-input type="password" v-model="ruleForm3.checkPass" auto-complete="off"
                              placeholder="请确认密码"></el-input>
                </el-form-item> 
                   <el-form-item label="所属角色"  :required="true" >
                <el-select   class="select" v-model="ruleForm3.suoshurole">
                        <el-option v-for="item in roleList" :label="item.roleName" :value="item.roleName">{{item.roleName}}</el-option> 
                    </el-select>
                </el-form-item>
                <el-form-item label="所属公司"   :required="true" >
                <el-select v-model="ruleForm3.companyn"  class="select">
                        <el-option v-for="item in vehicleList" :value="item.aileas" :label="item.aileas">{{item.aileas}}</el-option> 
                    </el-select>
                </el-form-item>
                <el-form-item label="账号类别"  :required="true">
                    <el-select v-model="ruleForm3.adminType"  class="select">
                        <el-option :value="item.id" v-for="item in adminList" :label="item.name">{{item.name}}</el-option> 
                    </el-select>
                </el-form-item>
                <el-form-item label="状态" prop="resource" :required="true">
                    <el-radio-group v-model="ruleForm3.resource">
                        <el-radio label="1" value="1">启用</el-radio>
                        <el-radio label="0" value="0">禁用</el-radio>
                    </el-radio-group>
                </el-form-item>
            </el-form>
        </div>
        <div class="footer">
            <div class="sub f-r">
                <template>
                    <el-button type="primary" @click="open2('ruleForm3')">立即创建</el-button>
                </template>
                <el-button @click="resetForm('ruleForm3')" class="but">关闭</el-button>
            </div>
        </div>
    </div>
</template>
<script type="text/ecmascript-6">
    import md5 from 'js-md5';
    import {Message} from 'element-ui';
    export default {
        data() {
            var accountchange = (rule, value, callback) => {
                var that = this;
                if (value==="") {
                    return callback(new Error('账号不能为空'));
                }else{
                    let msg = {
                        data: {
                            "userAccount": that.ruleForm3.account
                        }
                    };
                    that.axios.post('/user/check',JSON.stringify(msg))
                        .then(res => {
                            if (res.data.resCode === '000000') {
                                if(res.data.repBody.enable){ 
                                    callback()
                                }else{
                                    return callback(new Error('账号已存在,请输入新的账号'));
                                }
                            }else{
                                that.$message({
                                    type: 'info',
                                    message: '请求失败'
                                });
                            }
                        })
                        .catch(error => {
                            this.$message({
                                type: 'warning',
                                message: '请求错误'
                            });
                        });
                }
            };
            var validatePass = (rule, value, callback) => {
                if (value === '') {
                    callback(new Error('新密码不能为空'));
                }else if (!/^(\w){6,20}$/.test(this.ruleForm3.pwd)) {
                    return callback(new Error('请输入6-20个字母、数字或者下划线组成的新密码'));
                }
                else {
                    callback();
                }


            };
            var validatePass2 = (rule, value, callback) => {
                if (value === '') {
                    callback(new Error('请再次输入密码'));
                } else if (value !== this.ruleForm3.pwd) {
                    callback(new Error('两次输入密码不一致!'));
                } else {
                    callback();
                }
            };
            return {
                checkAll: false, 
                vehicleList:[], //车检站 
                adminList:[{id:'m',name:'后台管理'},{id:'p', name:'客户端'},{ id:'a',name:'全部'}],
                checkedCities: [],
                cities: this.regionDate,
                isIndeterminate: true,
                roleList:[],
                areaCode : '',
                ruleForm3: {
                    pwd: '',
                    checkPass: '',
                    account: '',
                    resource: '1',
                    region: '',
                     suoshurole:'',
                     adminType:'', //账号类别
                     companyn:''
                    // areaCode: ''
                },
                rules2: {
                    pwd: [
                        { validator: validatePass,trigger: 'blur',}
                    ],
                    checkPass: [
                        { validator: validatePass2,trigger: 'blur'}
                    ],
                    account: [
                        { validator: accountchange,trigger: 'blur'}
                    ],
                    suoshurole: [
                        {required: true, message: '请选择所属角色', trigger: 'change'}
                    ],
                    companyn: [
                        {required: true, message: '请选择所属公司', trigger: 'change'}
                    ],
                    adminType: [
                        {required: true, message: '请选择账号类别', trigger: 'change'}
                    ],
                    resource: [
                        { required: true, message: '请选择状态', trigger: 'change' }
                    ]
                },
                userInfo:{}
            };
        },
        props: {
            issel: {
                type: Function,
                default: null
            },
            onTex: {
                type: Function,
                default: null
            },
            roleData :{
                type: Array,
                default: null
            },
            regionDate :{
                type: Array,
                default: null
            },
            isShow: {
                type: Boolean,
                default: null
            },
            changePage:{
                type: Function,
                default: null
            }

        },
        created () {
            this.getrole()
            this.getallquery();
        },
        methods: {
            //获取车检站
            getallquery(){
                let that = this;
                let msg = {};
                that.axios.post('/cisCompany/queryAll',JSON.stringify(msg))
                .then(res =>{
                    console.log(res);
                    if(res.data.resCode === '000000'){
                        that.vehicleList = res.data.repBody;
                    }
                })
                .catch(error =>{

                }) 
            },
            //获取角色
            getrole(){
                let that = this;
                let msg = {};
                that.axios.post('/role/total',JSON.stringify(msg))
                .then(res =>{
                    console.log(res);
                    if(res.data.resCode === '000000'){
                        that.roleList = res.data.repBody;
                    }
                })
                .catch(error =>{

                })
            },
          handleCheckAllChange(event) {
              if(event.target.checked){
                for(let i=0;i<this.regionDate.length;i++){
                  this.checkedCities.push(this.regionDate[i].areaCode);
                }
              }else{
                this.checkedCities = []
              }
              this.isIndeterminate = false;
          },
          handleCheckedCitiesChange(value) {
              let checkedCount = value.length;
             this.checkAll = checkedCount === this.regionDate.length;
             this.isIndeterminate = checkedCount > 0 && checkedCount < this.regionDate.length;
          },
            //添加管理员提交
            submitForm() {  
                var juseId ='',gongsiId=''; 
               for(let i=0;i<this.roleList.length;i++){
                    if(this.ruleForm3.suoshurole == this.roleList[i].roleName){
                        juseId = this.roleList[i].roleId;
                        break;
                    }
               }
                for(let i=0;i<this.vehicleList.length;i++){
                    if(this.ruleForm3.companyn == this.vehicleList[i].aileas){
                        gongsiId = this.vehicleList[i].id;
                        break;
                    }
               } 
                let msg = {
                    data: {
                        "pwd":(md5(this.ruleForm3.pwd)).toUpperCase(),
                        "roleId": juseId,
                        "companyId":gongsiId,
                        "type" :this.ruleForm3.adminType,
                        "status": this.ruleForm3.resource,
                        "userAccount": this.ruleForm3.account
                    }
                };   
                if(this.ruleForm3.suoshurole == "" || this.ruleForm3.suoshurole=='请选择所属角色'){
                  this.$message({
                      type: 'warning',
                      message: '请选择所属角色'
                  });
                  return ;
                }

                if(this.ruleForm3.companyn == "" || this.ruleForm3.companyn=='请选择所属公司'){
                  this.$message({
                      type: 'warning',
                      message: '请选择所属公司'
                  });
                  return ;
                }
                 if(this.ruleForm3.adminType == "" || this.ruleForm3.adminType=='请选择账号类别'){
                  this.$message({
                      type: 'warning',
                      message: '请选择账号类别'
                  });
                  return ;
                }
 
                var that = this;
                that.axios.post('/user/insert',JSON.stringify(msg))
                    .then(res => {
                var roleId;
                if (res.data.resCode === '000000') {

                  //this.$root.eventHub.$emit('YOUR_EVENT_NAME','addAdmin');
                    that.$message({
                        type: 'success',
                        message: '管理员添加成功'
                    });
                    that.resetForm('ruleForm3');
                    that.ruleForm3.suoshurole=='';
                    that.ruleForm3.companyn=='';
                    that.ruleForm3.adminType=='';
                    that.changePage(1);
                }else{
                    this.$message({
                        type: 'info',
                        message: '添加失败'
                    });
                }
                })
            .catch(error => {
                that.$message({
                    type: 'error',
                    message: '添加失败'
                });
            });
                this.quit();
            },
            resetForm(formName) {
                this.$refs[formName].resetFields();
                this.issel()
            },
            open2(ruleForm3) {
                //提交创建
                var that=this;
                that.$refs.ruleForm3.validate((valid) => {
                    // debugger
                    if (valid) {
                        that.submitForm(ruleForm3)
                    } else {
                        return false;
                    }
                })
            },
            quit () {
                this.issel();
            },
            clear () {
                this.ruleForm3={
                    pwd: '',
                        checkPass: '',
                        account: '',
                        resource: '1',
                        suoshurole: '',
                        companyn: '',
                        adminType:''

                }
            }
        },
        watch: {
       },
    }
</script>
<style lang="less" rel="stylesheet/less" scoped>
    @import '../../../assets/css/property.less';
    .add-admin {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        /*left:0;*/
        /*right:0;*/
        /*margin:0 auto;*/
        background-color: #fff;
        z-index: 99;
        width: 750px;
        height: 550px;
        border: 1px solid #ccc;
        border-radius: 4px;
        .headerAA {
            background-color: #fff;
            width: 100%;
            height: 40px;
            line-height: 40px;
            text-indent: 10px;
            font-size: 14px;
            border-bottom: 1px solid #ccc;
            .el-icon-circle-close {
                font-size: 18px;
                cursor: pointer;
                margin-top: 10px;
                margin-right: 10px;
            }
        }
        .content {
            padding-top: 20px;
            height: 440px;
            border-bottom: 1px solid #ccc;
            .input {
                width: 320px;
                height: 35px;
            }
            .select {
                width: auto;
            }

        }
        .footer {
            .sub {
                margin-top: 6px;
                margin-right: 12px;
                .but {
                    width: 70px;
                }
            }
        }
        .el-form-item__error{
            color: #000!important;
            position: relative!important;
        }
        .sheet{
            width: 600px;
            height: 110px;
            overflow-y: auto;
            .checkAll{
                margin-left:5px;
            }
            .check{
                width: 100px;
                margin-left:5px;
                margin-right:20px;
            }
        }

    }
</style>
