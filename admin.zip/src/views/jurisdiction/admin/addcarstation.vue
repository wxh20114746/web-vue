<template>
    <!--新建批次-->
    <div class="create">
    <div class="headerAA"><span>添加车检站</span><i class="el-icon-circle-close f-r" @click="close('ruleForm')"></i>
        </div>
        <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
            <el-form-item label="归属地" prop="name">
                <el-input v-model="ruleForm.name" class="createtext"></el-input>
            </el-form-item> 
            <el-form-item label="车检站名称" prop="desc">
                <el-input v-model.number="ruleForm.desc" class="createtext"></el-input>
            </el-form-item>
            <!--操作按钮-->
            <el-form-item>
                <el-button type="primary" @click="adds(ruleForm)">立即添加</el-button> 
                <el-button @click="close('ruleForm')">取消</el-button>
            </el-form-item>
        </el-form>
    </div>
</template>
<script type="text/ecmascript-6">
    export default {
        data() {
            return {
                //用户输入内容
                ruleForm: {
                    name: '', 
                    desc: ''
                },
                //限制
                rules: {
                    name: [
                        {required: true, message: '请输入归属地', trigger: 'blur'},
                        {min: 2, max: 20, message: '长度在 2 到 10 个字符', trigger: 'blur'}
                    ], 
                    desc: [
                        {required: true, message: '请输入名称'},
                       {min: 1, max: 20, message: '长度在 3 到 15 个字符', trigger: 'blur'}
                    ]
                }
            };
        },
        props: {
            isShowContro: {
                type: Function,
                default: null
            },
            carObject: {
                type: Object,
                default: null
            },
            getcarlist:{
                type:Object,
                default:null
            }
        },
        created () {

        },
        methods: {
            adds (ruleForm) {
                this.$refs.ruleForm.validate((valid) => {
                    if (valid) {
                        this.submitForm(ruleForm);
                    } else {
                        return false;
                    }
                });
            },
            //立即创建
            submitForm(ruleForm) { 

                let msg = {
                    data: {
                        "province": this.ruleForm.name,
                        "aileas": this.ruleForm.desc
                    }
                };

                var that = this;
                that.axios.post('/cisCompany/add', JSON.stringify(msg))
                    .then(res => {
                        if (res.data.resCode === '000000') { 
                            that.$message({
                                type: 'info',
                                message: '车检站增加成功'
                            }); 
                            this.isShowContro();
                            this.getcarlist();
                            this.ruleForm = {
                                name: '', 
                                desc: ''
                            }
                        }
                    })
                    .catch(error => {
                    })
                //发送查询请求,返回数组对象,拿到批次号等,插入页面
                //清空输入内容
                this.$refs[ruleForm].resetFields();
            }, 
            close (ruleForm) {
                this.isShowContro();
                this.ruleForm = {
                    name: '', 
                    desc: ''
                }
                this.$refs[ruleForm].resetFields();
            }
        }
    }
</script>
<style lang="less" rel="stylesheet/less" scoped>
    @import '../../../assets/css/property.less';

    .create {
        border-radius: 5px;
        background-color: #fff;
        width: 400px;
        height: 250px;
        position: fixed;
        top: 30%;
        left: 40%;
        border: 1px solid #ccc;
        /*padding: 20px 10px;*/
        .createtext {
            width: 260px;
        }
        z-index: 99;

        .headerAA{
            margin-bottom: 35px;
                background-color: #fff;
                width: 100%;
                height: 40px;
                line-height: 40px;
                text-indent: 10px;
                font-size: 14px;
                border-bottom: 1px solid #ccc;
                 .el-icon-circle-close {
                font-size: 18px;
                cursor: pointer;
                margin-top: 10px;
                margin-right: 10px;
            }
        }
    }
</style>
