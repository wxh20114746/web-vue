<template>
    <div class="admin">
        <!--工具条-->
        <el-breadcrumb separator="/" class="bread" style="margin-bottom:25px;"> 
            <el-button type="primary" id="equipment_btn" style="border:0;" @click="adminZhang">账号管理</el-button>
            <el-button  type="primary" id="cust_btn" style="background: #909399;border:0;" @click="adminCar">车检站管理</el-button>
        </el-breadcrumb>

        <el-row class="tool" v-if="isAccout"> 
        <el-col :span="24">
        <div class="grid-content bg-purple toolbar">
            <el-button type="primary" class="add" @click="addAdmin" size="small">添加管理员</el-button>
        </div>
        </el-col>
        </el-row>
         <el-row class="tool" v-if="isVehicle"> 
        <el-col :span="24">
        <div class="grid-content bg-purple toolbar">
            <el-button type="primary" class="add" @click="addcarstat" size="small">添加车检站</el-button>
        </div>
        </el-col>
        </el-row> 
        <!-- 账号管理 -->
        <numlist v-if="isAccout" :tableData="tableData3" :getListData="getListData"></numlist>
    <div class="detlist"  v-if="isVehicle">
            <el-table 
                    ref="multipleTable"
                    :data="tableData2"
                    border
                    tooltip-effect="dark" 
                    @selection-change="handleSelectionChange">
                <el-table-column
                        type="selection"  
                        align="center">
                </el-table-column>
                <el-table-column
                        label="车检站" 
                        prop="aileas"
                        align="center">  
                </el-table-column> 
                <el-table-column
                        prop="province"
                        label="归属地" 
                        align="center">
                </el-table-column>
                <el-table-column
                        prop="createTime"
                        label="创建时间" 
                        align="center">
                </el-table-column>
                <el-table-column label="操作" align="center">
                    <template scope="scope"> 
                        <el-button
                                size="small"
                                @click="handleEdit(scope.$index, scope.row)">编辑
                        </el-button>
                        <el-button size="small" type="danger" @click="del(scope.$index, scope.row)">删除</el-button>
                    </template>
                </el-table-column>
            </el-table>
            <div style="margin-top: 20px">
            <el-button type="danger" @click="dels" :disabled="this.multipleSelection.length===0">批量删除</el-button>

            <el-button @click="toggleSelection()">取消选择</el-button>
            </div>
            <page-bar :changePage="changePage" class="f-r" :pageMsg="pageMsg" v-if="pageIf"></page-bar>
        </div>
        <!-- 添加管理员 -->
        <transition name='fade' mode='out-in'>
            <add-admin v-show="isShow" :issel="issel" :onTex="onTex" :regionDate="regionDate" :roleData="roleData" :isShow="isShow" ref="add" :changePage="changePage"></add-admin>
        </transition>
        <!-- 编辑管理员 -->
        <!-- <transition name='fade' mode='out-in'>
            <edit-admin v-show="isEdit" :isedit="isedit" :regionDate="regionDate" :check="check" :reviseInfo="reviseInfo" :roleData="roleData" :changePage="changePage" :defaultCode="defaultCodeData"></edit-admin>
        </transition> -->
        <!-- 添加车检站 -->
        <transition name='fade' mode='out-in'>
            <addcarstation v-if="isshowCar" :isShowContro="isShowContro" :carObject="carObject" :getcarlist="getcarlist"></addcarstation>
        </transition>
        <!-- 编辑车检站 -->
        <transition name='fade' mode='out-in'>
            <editcarstation v-if="iseditCar" :iseditContro="iseditContro" :carObject="carObject" :getcarlist="getcarlist"></editcarstation>
        </transition>
    </div>
</template>
<script type="text/ecmascript-6">
    import addAdmin from './addAdmin.vue'
    import addcarstation from './addcarstation.vue'
    import editcarstation from './editcarstation.vue'
    import editAdmin from './editAdmin.vue'
    import pageBar from '../../../components/pageBar.vue'
    import session from '../../../utils/session'
    import numlist from './numlist.vue';
    import {Message} from 'element-ui';

    export default {
        data() {
            return {
                isshowCar:false, 
                iseditCar:false,
                carObject:{},
                isAccout:true,
                isVehicle:false,
                tableData2:[],
                tableData3: [],
                isShow: false,
                multipleSelection: [],
                userNames: {},
                check: {},
                isRevise: false,
                idx: '',
                isEdit: false,
                loading:false,
                title:'人员信息',
                roleData:[],
                regionDate: [],
                pageIf:true,
                pageMsg: {
                    pageSum: '',
                    //总页码
                    pageList: [],
                    //单页数量
                    pageSize: 10,
                    //商品总数
                    totalCount: '',
                    list: []
                },
                listData: [],
                defaultCode: '',
                defaultCodeData: []
            }
        },
        components: {
            addAdmin,
            pageBar,
            editAdmin,
            addcarstation,
            editcarstation,
            numlist
        },
        mounted: function () {
          this.$nextTick(function () {
            this.$root.eventHub.$on('YOUR_EVENT_NAME', (yourData)=>{
                this.getListData();
            })
          })
        },
        created () {
            function getCookie(name) {
                var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");

                if (arr = document.cookie.match(reg))

                    return (arr[2]);
                else
                    return null;
            }

            function delCookie(name) {
                var exp = new Date();
                exp.setTime(exp.getTime() - 1);
                var cval = getCookie(name);
                if (cval != null)
                    document.cookie = name + "=" + cval + ";expires=" + exp.toGMTString();
            }
            document.title='管理员信息';
            // this.loading = true;
            this.getListData();
            
        },
        methods: {  
            //获取车检站列表
            getcarlist(){
                let that = this;
                let msg = {data:{pageName:"cisCompanyService",paginator:{limit:100,page:1},params:{}}}
                that.axios.post('/page/list',JSON.stringify(msg))
                .then(res =>{
                    if (res.data.resCode === '000000') { 
                           
                              //查询字段处理函数
                         let warningItem = res.data.repBody.list.map((value, index) => {
                             return { 
                                 updateTime: (new Date(value.updateTime)).toLocaleString(),
                                 address:value.address,
                                 aileas:value.aileas,
                                 county:value.county,
                                 detail:value.detail,
                                 id:value.id,
                                 name:value.name,
                                 province:value.province,
                                 town:value.town,
                                 createTime:(new Date(value.createTime)).toLocaleString() 
                             }
                         });
                         that.tableData2 = warningItem;

                            //传给分页组件
                         this.pageMsg.totalCount = res.data.repBody.paginator.totalCount;
                         this.pageMsg.pageSum = res.data.repBody.paginator.totalPages;
                         // for (let i = 1; i <= this.pageMsg.pageSum; i++) {
                         //     this.pageMsg.pageList.push(i);
                         // }
                         // this.pageMsg.list = this.pageMsg.pageList.slice(0, 5);
                    }
                })
                .catch(error =>{

                })
            },
            adminZhang(){
                document.getElementById("equipment_btn").style.background = "";
            document.getElementById("cust_btn").style.background = "#909399";
                this.isAccout = true;
                this.isVehicle = false;
                 this.loading = true;
                this.getListData();
            },
            adminCar(){
                     document.getElementById("equipment_btn").style.background = "#909399";
                     document.getElementById("cust_btn").style.background = "";
                this.isAccout = false;
                this.isVehicle = true;
                this.getcarlist();
            },
           getListData(){
             let msg = {
                 data: {
                     "pageName": localStorage.getItem("pages"),
                     "paginator": {"limit": 10, "page": 1},
                      // 不能只查启用的
                      "params": {}
                 }
             }
             var that = this;
             that.axios.post('/page/list',JSON.stringify(msg))
                 .then(res => {
                     if (res.data.resCode === '000000') {
                         this.loading = false;
                         this.listData = res.data.repBody.list;
                         //查询字段处理函数
                         let warningItem = res.data.repBody.list.map((value, index) => {
                             return {
                                companyId:JSON.stringify(value.companyId), //公司id
                                types:JSON.stringify(value.type), //账号类别
                                 account: value.userAccount,//账号
                                 role: value.roleName,//角色 
                                 secondStatus:JSON.stringify(value.status),
                                 status: this.transition(value.status),//状态
                                 roleId:JSON.stringify(value.roleId),
                                 createTime: (new Date(value.createTime)).toLocaleString(),//创建时间
                                 userId:value.userId,
                                 pwd:value.pwd,
                                 roleName:value.roleName,//角色名称
                                 typeName:this.typeChange(value.type) //帐号类型
                             }
                         });
                         // mdefaultRegname
                         this.tableData3 = warningItem;
                         //传给分页组件
                         // this.pageMsg.totalCount = res.data.repBody.paginator.totalCount;
                         // this.pageMsg.pageSum = res.data.repBody.paginator.totalPages;
                         // for (let i = 1; i <= this.pageMsg.pageSum; i++) {
                         //     this.pageMsg.pageList.push(i);
                         // }
                         // this.pageMsg.list = this.pageMsg.pageList.slice(0, 5);
                     }
                     else {
                         this.loading = false;
                         let message = res.data.resMsg
                         MessageBox.alert(message).then(action => {
                             delCookie('JSESSIONID');
                             localStorage.clear();
                             sessionStorage.clear();
                             that.$router.push('/login')
                         });
                     }})
                 .catch(error => {
                   console.log(error);
                 this.loading = false;
                   this.$message({
                       type: 'info',
                       message: '网络错误'
                   });
                 })
           },
            reviseInfo (check) {
                this.tableData3[this.idx].account = check.account;
                this.tableData3[this.idx].role = check.role;
                this.tableData3[this.idx].status = check.status;
                this.tableData3[this.idx].userId = check.userId;
                this.tableData3[this.idx].pwd = check.pwd;
            },
            del (index, row) {
                this.$confirm('此操作将删除车检站, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    var rowUser = row.account;
                    var cureentUser = localStorage.getItem("userNames");
                    if(rowUser==cureentUser){
                        this.$message({
                            type: 'warning',
                            message: '用户为当前登录用户，禁止删除'
                        });
                    }else{
                        this.handleDelete(index, row);
                    }
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消'
                    });
                });
            },
            dels (index, row) {
                this.$confirm('此操作将删除车检站, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.batchRemove();
                }).catch((e) => {
                  console.log(e);
                    this.$message({
                        type: 'info',
                        message: '已取消'
                    });
                })
            },
            toggleSelection(rows) {
                if (rows) {
                    rows.forEach(row => {
                        this.$refs.multipleTable.toggleRowSelection(row);
                    });
                } else {
                    this.$refs.multipleTable.clearSelection();
                }
            },
            handleSelectionChange(val) {
                this.multipleSelection = val;
            },
   
            addAdmin () {
                // this.$refs.add.clear();
                let msg={data:
                    {"pageName":'roleService',
                        "paginator":{"limit":'100',"page":'1'},
                        "params":{"deviceType:":"","deviceBrand":"","deviceMode":""}
                    }};
                var that = this; 
                that.axios.post('/page/list',JSON.stringify(msg))
                    .then(res => {
                if (res.data.resCode === '000000') {
                    this.roleData=res.data.repBody.list
                }else{
                    this.$message({
                        type: 'info',
                        message: '网络错误'
                    });
                }

            })
            .catch(error => {
                this.$message({
                    type: 'info',
                    message: '网络错误'
                });
            })
                this.isShow = true;
            },
            addcarstat(){
                this.isshowCar = true;
            },
            issel () {
                this.isShow = false;
            },
            isedit () {
                this.isEdit = false;
            },
            isShowContro () {
                this.isshowCar = false;
            },
            iseditContro(){
                this.iseditCar = false;
            },
            //删除
            handleDelete(index, row) {
                this.loading = true;
                this.tableData2.splice(index, 1);
                let ss = String(row.id);
                let msg = {data: {"id": (ss)}};
                var that = this;
                that.axios.post('/cisCompany/delete',JSON.stringify(msg))
                    .then(res => {
                        if (res.data.resCode === '000000') {
                            this.loading = false;
                            this.$message({
                                type: 'success',
                                message: '删除成功'
                            });

                        }else{
                            this.loading = false;
                            this.$message({
                                type: 'info',
                                message: '删除失败'
                            });
                        }
                    })
                    .catch(error => {
                        this.$message({
                            type: 'error',
                            message: '删除失败'
                        });
                    })
            },
            batchRemove () {
                //批量删除
                this.loading = true;
                var ids = this.multipleSelection.map(item => item.id)//获取所有选中行的id组成的字符串，以逗号分隔
                var arr = [];
                //存一下tableData3
                let table = this.tableData2;
                //前台遍历删除
                this.tableData3.forEach(function (value, index) {
                    ids.forEach(function (val, ind) {
                        if (value.id === val) {
                            arr.push(index);
                            //排序
                            arr.sort(function (a, b) {
                                return b - a;
                            });
                        }
                    })
                });
                //从后往前删
                arr.forEach(function (val, ind) {
                    table.splice(val, 1);
                });
                //逗号连接
                let idd = ids.join(',');
                let msg = {data: {"id": (idd)}};
                var that = this;
                that.axios.post('/cisCompany/delete',JSON.stringify(msg))
                    .then(res => {
                        if (res.data.resCode === '000000') {
                            this.loading = false;
                            this.$message({
                                type: 'success',
                                message: '删除成功'
                            });
                        }else{
                            this.loading = false;
                            this.$message({
                                type: 'info',
                                message: '删除失败'
                            });
                        }
                    })
                    .catch(error => {
                        this.$message({
                            type: 'error',
                            message: '删除失败'
                        });
                    })
            },
            //渲染列表
            changePage (num,list) {
                this.loading = true;

                let msg = {
                    data: {
                        "pageName": localStorage.getItem("pages"),
                        "paginator": {"limit": 10, "page": num},
                         "params": {}
                    }
                };
                if(num=='1'){
                    this.pageIf=false;
                }
                var that = this;
                that.axios.post('/page/list',JSON.stringify(msg))
                    .then(res => {
                        if (res.data.resCode === '000000') {
                            //渲染处理函数
                            this.loading = false;
                            let warningItem = res.data.repBody.list.map((value, index) => {
                                return {
                                    //字段
                                    account: value.userAccount,//账号
                                    role: value.roleName,//角色
                                    status: this.transition(value.status),//状态
                                    createTime: (new Date(value.createTime)).toLocaleString(),//创建时间
                                    userId: value.userId//账户id
                                }
                            });
                            this.tableData3 = warningItem;
                            if(num=='1'){
                                this.pageIf=true;
                            }
                            this.pageMsg.totalCount = res.data.repBody.paginator.totalCount;
                            this.pageMsg.pageSum = res.data.repBody.paginator.totalPages;
                            for (let i = 1; i <= this.pageMsg.pageSum; i++) {
                                this.pageMsg.pageList.push(i);
                            }
                            if((num - 1) % 5 === 0){
                                this.pageMsg.list = this.pageMsg.pageList.slice(num - 1, num + 4);
                            }else if(num==1){
                                this.pageMsg.list = this.pageMsg.pageList.slice(0, 5);
                            }else if(num==this.pageMsg.pageSum&&(num % 5) === 0){
                                this.pageMsg.list = this.pageMsg.pageList.slice(num - 5, num);
                            }else if(num==this.pageMsg.pageSum&&(num % 5) !== 0){
                                let nn=num%5;
                                this.pageMsg.list = this.pageMsg.pageList.slice(num - nn, num);
                            }else if((num) % 5 === 0){
                                this.pageMsg.list = this.pageMsg.pageList.slice(num - 5, num);
                            }else{
                                this.pageMsg.list = list
                            }
                        }else {
                            this.loading = false;
                            let message = res.data.resMsg
                            MessageBox.alert(message).then(action => {
                                delCookie('JSESSIONID');
                            localStorage.clear();
                            sessionStorage.clear();
                            that.$router.push('/login')
                        });
                        }
                    })
                    .catch(error => {
                    this.loading = false;
                        this.$message({
                            type: 'info',
                            message: '网络错误'
                        });
                    })
            },
            onTex (val) {
                //注意,接收到返回的id后才增加
                //增加的项前台页面展现,同时拿到新增项的id存进列表项数组
                var newV = {
                    account: val.userAccount,
                    role: val.roleId,
                    status: this.transition(val.status),
                    createTime: (new Date(new Date().getTime())).toLocaleString()
                };
                this.tableData3.push(newV);
            },
            nowTime (ns) {
                return new Date(parseInt(ns) * 1000).toLocaleString().replace(/:\d{1,2}$/, ' ');
            },
            //编辑车检站
            handleEdit(index, row) {
                console.log(index,row)
                this.carObject  = row;
                this.iseditCar = true;
            },
            onRevise (val, index) {
                this.idx = index;
                for (var key in val) {
                    this.check[key] = val[key];
                }
                this.isEdit = true;
            },
            transition (val) {
                let result;

                if(val=='0'){
                    result='禁用'
                }
                if(val=='1'){
                    result='启用'
                }

                return result
            },
            typeChange (val) {
                let results;

                if(val=='p'){
                    results='客户端'
                }
                if(val=='m'){
                    results='后台管理'
                }
                if(val=='a'){
                    results='全部'
                }

                return results
            },
            reload () {
                this.$router.push({
                    path: '/empty'
                })
            }
        }
    }
</script>
<style lang="less" rel="stylesheet/less" scoped>
    @import '../../../assets/css/property.less';

    .admin {
        padding: 20px 20px 0 20px;
        margin-left:230px;
        min-width:1008px;
        width: 100%;
        margin-top:60px;
        /*flex: 1;*/
        .admin-content {
            padding: 10px 10px;
            width: 100%;
            height: 50px;
            border: 1px solid #ccc;
            .add {
                margin-top: 15px;
                font-size: 14px;
            }
        }
        .detlist {
            width: 100%;
        }

        .el-row {
            margin-bottom: 20px;
            &:last-child {
                margin-bottom: 0;
            }
        }
        .tool{
            background-color: #f2f2f2;
            padding:10px;
            border-radius: 2px;
            margin: 10px 0px;

        }
        .el-col {
            border-radius: 4px;
            /*padding:10px;*/
        }
        .bg-purple-dark {
            background: #99a9bf;
        }
        .bg-purple {
            background: #f2f2f2;
        }
        .bread {
            padding-top: 2px;
            height: 24px;
            /*line-height: 50px;*/
            font-size: 14px;
        }
        .toolbar {
            /*background-color: #f2f2f2;*/
            /*padding: 10px;*/
            /*margin: 10px 0px;*/

            .add{
                font-size:14px;
            }
            .el-form-item {
                margin-bottom: 10px;
            }
        }
        /*.add {*/

            /*button{*/
                /*height: 30px!important;*/
                /*font-size: 14px;*/
                /*padding:15px 10px;*/
            /*}*/
        /*}*/
    }
</style>
