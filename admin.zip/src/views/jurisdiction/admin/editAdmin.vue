<template>
    <div class="add-admin">
        <div class="headerAA"><span>修改管理员</span><i class="el-icon-circle-close f-r" @click="resetForm('ruleForm3')"></i>
        </div>
        <div class="content">
            <el-form :model="ruleForm3"  ref="ruleForm3" label-width="100px" class="demo-ruleForm">
                <el-form-item label="账号"  class="input" :required="true">
                    <el-input v-model.number="check.account" :disabled="true"></el-input>
                </el-form-item> 
                   <el-form-item label="所属角色"  :required="true" >
                <el-select   class="select" v-model="check.roleId">
                        <el-option v-for="item in roleList" :label="item.roleName" :value="JSON.stringify(item.roleId)"></el-option> 
                    </el-select>
                </el-form-item>
                <el-form-item label="所属公司"   :required="true" >
                <el-select v-model="check.companyId"  class="select">
                        <el-option v-for="item in vehicleList" :value="JSON.stringify(item.id)" :label="item.aileas"></el-option> 
                    </el-select>
                </el-form-item>
                <el-form-item label="账号类别"  :required="true">
                    <el-select v-model="check.types"  class="select">
                        <el-option :value="JSON.stringify(item.id)" v-for="item in adminList" :label="item.name"></el-option> 
                    </el-select> 
                </el-form-item>
                <el-form-item label="状态" prop="resource" :required="true">
                    <el-radio-group v-model="check.secondStatus">
                        <el-radio label="1" value="1">启用</el-radio>
                        <el-radio label="0" value="0">禁用</el-radio>
                    </el-radio-group>
                </el-form-item>
            </el-form>
        </div>
        <div class="footer">
            <div class="sub f-r">
                <template>
                    <el-button type="primary" @click="open2('ruleForm3')">立即修改</el-button>
                </template>
                <el-button @click="resetForm('ruleForm3')" class="but">关闭</el-button>
            </div>
        </div>
    </div>
</template>
<script type="text/ecmascript-6">
    import md5 from 'js-md5';
    import {Message} from 'element-ui';
    export default {
        data() {  
            return {
                vehicleList:[], //车检站 
                adminList:[{id:'m',name:'后台管理'},{id:'p', name:'客户端'},{ id:'a',name:'全部'}],
                checkedCities: [],
                isIndeterminate: true,
                roleList:[],
                areaCode : '',
                ruleForm3: {
                    pwd: '',
                    checkPass: '',
                    account: '',
                    resource: '1',
                    region: '',
                     suoshurole:'',
                     adminType:'', //账号类别
                     companyn:''
                    // areaCode: ''
                }
            };
        },
        props: {
            check: {
                type: Object,
                default: null
            }, 
            isEdit: {
                type: Boolean,
                default: null
            },
            issel:{
                type:Function,
                default:null
            }

        },
        created () {
            this.getrole()
            this.getallquery(); 
        },
        methods: {
            //获取车检站
            getallquery(){
                let that = this;
                let msg = {};
                that.axios.post('/cisCompany/queryAll',JSON.stringify(msg))
                .then(res =>{
                    console.log(res);
                    if(res.data.resCode === '000000'){
                        that.vehicleList = res.data.repBody;
                    }
                })
                .catch(error =>{

                }) 
            },
            //获取角色
            getrole(){
                let that = this;
                let msg = {};
                that.axios.post('/role/total',JSON.stringify(msg))
                .then(res =>{
                    console.log(res);
                    if(res.data.resCode === '000000'){
                        that.roleList = res.data.repBody;
                    }
                })
                .catch(error =>{

                })
            },
          handleCheckAllChange(event) {
              if(event.target.checked){
                for(let i=0;i<this.regionDate.length;i++){
                  this.checkedCities.push(this.regionDate[i].areaCode);
                }
              }else{
                this.checkedCities = []
              }
              this.isIndeterminate = false;
          },
          handleCheckedCitiesChange(value) {
              let checkedCount = value.length;
             this.checkAll = checkedCount === this.regionDate.length;
             this.isIndeterminate = checkedCount > 0 && checkedCount < this.regionDate.length;
          },
            //添加管理员提交
            submitForm() {  
                let that =this; 
            let msg = {data:
                    {
                         "pwd":(md5(this.ruleForm3.pwd)).toUpperCase(),
                        "roleId": this.check.roleId,
                        "companyId":this.check.companyId,
                        "type" :JSON.parse(this.check.types),
                        "status": this.check.secondStatus,
                        "userAccount": this.check.account
                        }
                    };   
                that.axios.post('/user/update',JSON.stringify(msg))
                    .then(res => { 
                        if (res.data.resCode === '000000') {
                            // this.$root.eventHub.$emit('YOUR_EVENT_NAME','editAdmin');
                            this.$message({
                                type: 'success',
                                message: '编辑成功'
                            });  
                            that.$emit('changeData','1')
                        }else{
                            this.$message({
                                type: 'info',
                                message: '编辑失败'
                            });
                        }
                })
            .catch(error => {
                this.$message({
                    type: 'error',
                    message: '编辑失败'
                });
            });
                this.quit();
            },
            resetForm(formName) {
                this.$refs[formName].resetFields();
                this.issel()
            },
            open2(ruleForm3) {
                //提交创建
                var that=this;
                that.$refs.ruleForm3.validate((valid) => {
                    // debugger
                    if (valid) {
                        that.submitForm(ruleForm3)
                    } else {
                        return false;
                    }
                })
            },
            quit () {
                this.issel();
            },
            clear () {
                this.ruleForm3={
                    pwd: '',
                        checkPass: '',
                        account: '',
                        resource: '1',
                        suoshurole: '',
                        companyn: '',
                        adminType:''

                }
            }
        },
        watch: {
       },
    }
</script>
<style lang="less" rel="stylesheet/less" scoped>
    @import '../../../assets/css/property.less';
    .add-admin {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        /*left:0;*/
        /*right:0;*/
        /*margin:0 auto;*/
        background-color: #fff;
        z-index: 99;
        width: 750px;
        height: 550px;
        border: 1px solid #ccc;
        border-radius: 4px;
        .headerAA {
            background-color: #fff;
            width: 100%;
            height: 40px;
            line-height: 40px;
            text-indent: 10px;
            font-size: 14px;
            border-bottom: 1px solid #ccc;
            .el-icon-circle-close {
                font-size: 18px;
                cursor: pointer;
                margin-top: 10px;
                margin-right: 10px;
            }
        }
        .content {
            padding-top: 20px;
            height: 440px;
            border-bottom: 1px solid #ccc;
            .input {
                width: 320px;
                height: 35px;
            }
            .select {
                width: auto;
            }

        }
        .footer {
            .sub {
                margin-top: 6px;
                margin-right: 12px;
                .but {
                    width: 70px;
                }
            }
        }
        .el-form-item__error{
            color: #000!important;
            position: relative!important;
        }
        .sheet{
            width: 600px;
            height: 110px;
            overflow-y: auto;
            .checkAll{
                margin-left:5px;
            }
            .check{
                width: 100px;
                margin-left:5px;
                margin-right:20px;
            }
        }

    }
</style>
