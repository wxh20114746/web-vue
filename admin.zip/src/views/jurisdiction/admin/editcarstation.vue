<template>
    <!--新建批次-->
    <div class="create">
    <div class="headerAA"><span>添加管理员</span><i class="el-icon-circle-close f-r" @click="close('ruleForm')"></i>
        </div>
        <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
            <el-form-item label="归属地" prop="province">
                <el-input v-model="carObject.province" class="createtext"></el-input>
            </el-form-item> 
            <el-form-item label="名称" prop="aileas">
                <el-input v-model.number="carObject.aileas" class="createtext"></el-input>
            </el-form-item>
            <!--操作按钮-->
            <el-form-item>
                <el-button type="primary" @click="adds(ruleForm)">立即修改</el-button> 
                <el-button @click="close('ruleForm')">取消</el-button>
            </el-form-item>
        </el-form>
    </div>
</template>
<script type="text/ecmascript-6">
    export default {
        data() {
            return {
                //用户输入内容
                ruleForm: {
                    name: '', 
                    desc: ''
                },
                //限制
                rules: {
                    name: [
                        {required: true, message: '请输入归属地', trigger: 'blur'},
                        {min: 2, max: 20, message: '长度在 2 到 10 个字符', trigger: 'blur'}
                    ], 
                    desc: [
                        {required: true, message: '请输入名称'},
                       {min: 3, max: 20, message: '长度在 3 到 15 个字符', trigger: 'blur'}
                    ]
                }
            };
        },
        props: {
            iseditContro: {
                type: Function,
                default: null
            },
            carObject: {
                type: Object,
                default: null
            },
            getcarlist:{
                type:Object,
                default:null
            }
        },
        created () {

        },
        methods: {
            adds (ruleForm) {
                this.$refs.ruleForm.validate((valid) => {
                    if (valid) {
                        this.submitForm(ruleForm);
                    } else {
                        return false;
                    }
                });
            },
            //立即创建
            submitForm(ruleForm) { 

                let msg = {
                    data: {
                        "id": this.carObject.id,
                        "province": this.carObject.province,
                        "aileas": this.carObject.aileas
                    }
                };

                var that = this;
                that.axios.post('/cisCompany/update', JSON.stringify(msg))
                    .then(res => {
                        if (res.data.resCode === '000000') { 
                            that.$message({
                                type: 'info',
                                message: '车检站修改成功'
                            }); 
                            this.iseditContro();
                            this.getcarlist();
                           
                        }
                    })
                    .catch(error => {
                         that.$message({
                                type: 'warning',
                                message: error.data.resMsg
                            }); 
                    }) 
            }, 
            close (ruleForm) {
                this.iseditContro();
                  
            }
        }
    }
</script>
<style lang="less" rel="stylesheet/less" scoped>
    @import '../../../assets/css/property.less';

    .create {
        border-radius: 5px;
        background-color: #fff;
        width: 400px;
        height: 250px;
        position: fixed;
        top: 30%;
        left: 40%;
        border: 1px solid #ccc;
        /*padding: 20px 10px;*/
        .createtext {
            width: 260px;
        }
        z-index: 99;

        .headerAA{
            margin-bottom: 35px;
                background-color: #fff;
                width: 100%;
                height: 40px;
                line-height: 40px;
                text-indent: 10px;
                font-size: 14px;
                border-bottom: 1px solid #ccc;
                 .el-icon-circle-close {
                font-size: 18px;
                cursor: pointer;
                margin-top: 10px;
                margin-right: 10px;
            }
        }
    }
</style>
