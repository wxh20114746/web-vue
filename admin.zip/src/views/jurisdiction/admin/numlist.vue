<template>
  <div class="detlist" v-loading="loading">
        <el-table
                ref="multipleTable"
                :data="tableData"
                border
                tooltip-effect="dark"
                style="width: 100%"
                @selection-change="handleSelectionChange">
            <el-table-column
                    type="selection"
                    align="center">
            </el-table-column>
            <el-table-column
                    label="账号"
                    align="center">
                <template scope="scope">{{ scope.row.account }}</template>
            </el-table-column>
            <el-table-column
                    prop="roleName"
                    label="角色"
                    align="center">
            </el-table-column>
            <el-table-column
                    prop="typeName"
                    label="帐号类别"
                    align="center">
            </el-table-column>
            <el-table-column
                    prop="status"
                    label="状态"
                    align="center">
            </el-table-column>
            <el-table-column
                    prop="createTime"
                    label="创建时间"
                    width="250"
                    align="center">
            </el-table-column>
            <el-table-column label="操作"  width="250" align="center">
                <template scope="scope">
                <el-button
                            size="small"
                            @click="resetPassword(scope.$index,scope.row)">重置密码
                    </el-button>
                    <el-button
                            size="small"
                            @click="handleEdit(scope.$index, scope.row)">编辑
                    </el-button>
                    <el-button size="small" type="danger" @click="del(scope.$index, scope.row)">删除</el-button>
                </template>
            </el-table-column>
        </el-table>
        <div style="margin-top: 20px">
        <el-button type="danger" @click="dels" :disabled="this.multipleSelection.length===0">批量删除</el-button>

        <el-button @click="toggleSelection()">取消选择</el-button>
        </div>
        <page-bar :changePage="changePage" class="f-r" :pageMsg="pageMsg" v-if="pageIf"></page-bar>
            <!-- 编辑管理员 -->
        <transition name='fade' mode='out-in'>
            <edit-admin v-show="isEdit" :check="check" :issel="issel" @changeData="changeData"></edit-admin>
        </transition>
    </div>
    </template>	
 <script type="text/ecmascript-6">
         import pageBar from '../../../components/pageBar.vue'
	    import session from '../../../utils/session'
	    import {Message} from 'element-ui';
	    import editAdmin from './editAdmin.vue' 
export default{
		props:{
			tableData:{
				type:Array,
				default:[]
			},
			getListData:{
				type:Function,
				default:null
			}
		},
		    data() {
		    return {
		        isAccout:true,
		        isVehicle:false,
		        tableData2:[],
		        tableData3: [],
		        isShow: false,
		        multipleSelection: [],
		        userNames: {},
		        check: {},
		        isRevise: false,
		        idx: '',
		        isEdit: false,
		        loading:false,
		        title:'人员信息',
		        roleData:[],
		        regionDate: [],
		        pageIf:true,
		        pageMsg: {
		            pageSum: '',
		            //总页码
		            pageList: [],
		            //单页数量
		            pageSize: 10,
		            //商品总数
		            totalCount: '',
		            list: []
		        },
		        listData: [],
		        defaultCode: '',
		        defaultCodeData: []
		    }
		},
		   components: {
            pageBar,
            editAdmin


        },
        created(){
        	// this.loading = true;
        	this.getListData();
        },
        methods:{
          changeData(){
            this.getListData();
          },
        	  issel () {
                this.isEdit = false;
            },
        	//删除
            handleDelete(index, row) {
                this.loading = true;
                this.tableData3.splice(index, 1);
                let ss = String(row.userId);
                let msg = {data: {"userIds": (ss)}};
                var that = this;
                that.axios.post('/user/deleteBatch',JSON.stringify(msg))
                    .then(res => {
                        if (res.data.resCode === '000000') {
                            this.loading = false;
                            this.$message({
                                type: 'success',
                                message: '删除成功'
                            }); 
                            this.getListData();
                        }else{
                            this.loading = false;
                            this.$message({
                                type: 'info',
                                message: '删除失败'
                            });
                        }
                    })
                    .catch(error => {
                        this.$message({
                            type: 'error',
                            message: '删除失败'
                        });
                    })
            },
               toggleSelection(rows) {
                if (rows) {
                    rows.forEach(row => {
                        this.$refs.multipleTable.toggleRowSelection(row);
                    });
                } else {
                    this.$refs.multipleTable.clearSelection();
                }
            },
             del (index, row) {
                this.$confirm('此操作将永久删除该管理员, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    var rowUser = row.account;
                    var cureentUser = localStorage.getItem("userNames");
                    if(rowUser==cureentUser){
                        this.$message({
                            type: 'warning',
                            message: '用户为当前登录用户，禁止删除'
                        });
                    }else{
                        this.handleDelete(index, row);
                    }
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消'
                    });
                });
            },
        	 transition (val) {
                let result;

                if(val=='0'){
                    result='禁用'
                }
                if(val=='1'){
                    result='启用'
                }

                return result
            },
             typeChange (val) {
                let results;

                if(val=='p'){
                    results='客户端'
                }
                if(val=='m'){
                    results='后台管理'
                }
                if(val=='a'){
                    results='全部'
                }

                return results
            },
        	//渲染列表
            changePage (num,list) {
                this.loading = true;

                let msg = {
                    data: {
                        "pageName": localStorage.getItem("pages"),
                        "paginator": {"limit": 10, "page": num},
                         "params": {}
                    }
                };
                if(num=='1'){
                    this.pageIf=false;
                }
                var that = this;
                that.axios.post('/page/list',JSON.stringify(msg))
                    .then(res => {
                        if (res.data.resCode === '000000') {
                            //渲染处理函数
                            this.loading = false;
                            let warningItem = res.data.repBody.list.map((value, index) => {
                                return {
                                    //字段
                                    companyId:value.companyId, //公司id
                                    types:value.type, //账号类别
                                    account: value.userAccount,//账号 
                                    status: this.transition(value.status),//状态
                                    createTime: (new Date(value.createTime)).toLocaleString(),//创建时间
                                    userId: value.userId,//账户id
                                    roleName:value.roleName,//角色名称
                                    typeName:this.typeChange(value.type) //帐号类型
                                }
                            });
                            this.tableData3 = warningItem;
                            if(num=='1'){
                                this.pageIf=true;
                            }
                            this.pageMsg.totalCount = res.data.repBody.paginator.totalCount;
                            this.pageMsg.pageSum = res.data.repBody.paginator.totalPages;
                            for (let i = 1; i <= this.pageMsg.pageSum; i++) {
                                this.pageMsg.pageList.push(i);
                            }
                            if((num - 1) % 5 === 0){
                                this.pageMsg.list = this.pageMsg.pageList.slice(num - 1, num + 4);
                            }else if(num==1){
                                this.pageMsg.list = this.pageMsg.pageList.slice(0, 5);
                            }else if(num==this.pageMsg.pageSum&&(num % 5) === 0){
                                this.pageMsg.list = this.pageMsg.pageList.slice(num - 5, num);
                            }else if(num==this.pageMsg.pageSum&&(num % 5) !== 0){
                                let nn=num%5;
                                this.pageMsg.list = this.pageMsg.pageList.slice(num - nn, num);
                            }else if((num) % 5 === 0){
                                this.pageMsg.list = this.pageMsg.pageList.slice(num - 5, num);
                            }else{
                                this.pageMsg.list = list
                            }
                        }else {
                            this.loading = false;
                            let message = res.data.resMsg
                            MessageBox.alert(message).then(action => {
                                delCookie('JSESSIONID');
                            localStorage.clear();
                            sessionStorage.clear();
                            that.$router.push('/login')
                        });
                        }
                    })
                    .catch(error => {
                    this.loading = false;
                        this.$message({
                            type: 'info',
                            message: '网络错误'
                        });
                    })
            },
        	 handleSelectionChange(val) {
                this.multipleSelection = val;
            },
             dels (index, row) {
                this.$confirm('此操作将永久删除该管理员, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.batchRemove();
                }).catch((e) => {
                  console.log(e);
                    this.$message({
                        type: 'info',
                        message: '已取消'
                    });
                })
            },
        	getListData(){ 
             let msg = {
                 data: {
                     "pageName": localStorage.getItem("pages"),
                     "paginator": {"limit": 10, "page": 1},
                      // 不能只查启用的
                      "params": {}
                 }
             }
             var that = this;
             that.axios.post('/page/list',JSON.stringify(msg))
                 .then(res => {
                     if (res.data.resCode === '000000') {
                         this.loading = false;
                         this.listData = res.data.repBody.list;
                         //查询字段处理函数
                         let warningItem = res.data.repBody.list.map((value, index) => {
                             return {
                                 account: value.userAccount,//账号
                                 role: value.roleName,//角色
                                 status: this.transition(value.status),//状态
                                 createTime: (new Date(value.createTime)).toLocaleString(),//创建时间
                                 userId: value.userId,
                                 roleName:value.roleName,//角色名称
                                 typeName:this.typeChange(value.type) //帐号类型
                             }
                         });
                         // mdefaultRegname
                         this.tableData3 = warningItem;
                         //传给分页组件
                         this.pageMsg.totalCount = res.data.repBody.paginator.totalCount;
                         this.pageMsg.pageSum = res.data.repBody.paginator.totalPages;
                         for (let i = 1; i <= this.pageMsg.pageSum; i++) {
                             this.pageMsg.pageList.push(i);
                         }
                         this.pageMsg.list = this.pageMsg.pageList.slice(0, 5);
                     }
                     else {
                         this.loading = false;
                         let message = res.data.resMsg
                         MessageBox.alert(message).then(action => {
                             delCookie('JSESSIONID');
                             localStorage.clear();
                             sessionStorage.clear();
                             that.$router.push('/login')
                         });
                     }})
                 .catch(error => {
                   console.log(error);
                 this.loading = false;
                   this.$message({
                       type: 'info',
                       message: '网络错误'
                   });
                 })
           },
           getRegion(){

           },
           resetPassword(index,row){
            this.$confirm('此操作将重置该管理员密码, 是否继续?', '提示', {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning'
            }).then(() => {
              let text = {"id": row.userId,"time": new Date().getTime()};
              var key = CryptoJS.enc.Utf8.parse("13223wrwe4345678");
              var encryptedData = CryptoJS.AES.encrypt(JSON.stringify(text), key, {
                mode: CryptoJS.mode.ECB,
                padding: CryptoJS.pad.Pkcs7
              });
              let msg = {data:{"text":encryptedData.toString()}};
                this.axios.post('/user/reset', JSON.stringify(msg))
                  .then(res => {
                    console.log('res:'+JSON.stringify(res));
                    if (res.data.resCode === '000000') {
                      this.loading = false;
                      this.$message({
                        type: 'success',
                        message: '重置成功'
                      });
                    }else{
                      this.loading = false;
                      this.$message({
                        type: 'info',
                        message: '重置失败'
                      });
                    }
                  })
                  .catch(error => {
                    console.log(error);
                    this.loading = false;
                    let message = "请求异常"
                    this.$message({
                      type: 'info',
                      message: message
                    });
                  });
            }).catch((error) => {
              console.log('error:'+error);
              this.$message({
                type: 'info',
                message: '已取消'
              });
            });
           },
          handleEdit(index, row) { 
          		this.check = row; 
          		console.log(this.check)  
             this.isEdit = true;
            },

        }
	  }
 </script>
<style lang="less" rel="stylesheet/less" scoped>
    @import '../../../assets/css/property.less';
    .detlist{width: 100%;}
    </style>
