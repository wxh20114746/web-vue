<template>
    <div class="password">
        <div class="pass">
            <el-form :model="ruleForm2" :rules="rules2" ref="ruleForm2" label-width="100px" class="demo-ruleForm">
                <el-form-item label="旧密码" prop="oldPwd">
                    <el-input v-model="ruleForm2.oldPwd" type="password"></el-input>
                </el-form-item>
                <el-form-item label="新密码" prop="pass">
                    <el-input type="password" v-model="ruleForm2.pass" auto-complete="off"></el-input>
                </el-form-item>
                <el-form-item label="确认密码" prop="checkPass">
                    <el-input type="password" v-model="ruleForm2.checkPass" auto-complete="off"></el-input>
                </el-form-item>
                <el-form-item label-width="100px">
                    <el-button type="primary" @click="vali('ruleForm2')">提交</el-button>
                    <el-button @click="resetForm('ruleForm2')">重置</el-button>
                </el-form-item>
            </el-form>
        </div>
</div>
</template>
<script type="text/ecmascript-6">
    import session from '../../../utils/session'
    import md5 from 'js-md5';

    export default {
        data() {
            var checkAge = (rule, value, callback) => {
                if (value === '') {
                    return callback(new Error('旧密码不能为空'));
                }else if (!/^(\w){6,20}$/.test(this.ruleForm2.oldPwd)) {
                    return callback(new Error('请输入6-20个字母、数字或者下划线组成的旧密码'));
                }else{
                    callback();

                }
            };
            var validatePass = (rule, value, callback) => {
                if (value === '') {
                    callback(new Error('新密码不能为空'));
                }else if (!/^(\w){6,20}$/.test(this.ruleForm2.pass)) {
                    return callback(new Error('请输入6-20个字母、数字或者下划线组成的新密码'));
                }
                else {
                    callback();
                }
            };
            var validatePass2 = (rule, value, callback) => {
                if (value === '') {
                    callback(new Error('请再次输入密码'));
                } else if (value !== this.ruleForm2.pass) {
                    callback(new Error('两次输入密码不一致!'));
                } else {
                    callback();
                }
            };
            return {
                ruleForm2: {
                    pass: '',
                    checkPass: '',
                    oldPwd: ''
                },
                rules2: {
                    pass: [
                        { validator: validatePass, trigger: 'blur' }
                    ],
                    checkPass: [
                        { validator: validatePass2, trigger: 'blur' }
                    ],
                    oldPwd: [
                        { validator: checkAge, trigger: 'blur' }
                    ]
                },
                userName:''
            };
        },
        methods: {
            vali (formName) {
                var that=this;
                that.$refs[formName].validate((valid) => {
                    if (valid) {
                        that.submitForm()
                    } else {
                        return false;
                    }
                });
            },
            //确认提交
            submitForm() {
                var that=this;
                this.$confirm('此操作将修改密码, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    that.revise();
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '取消修改'
                    });
                });
            },
            resetForm(formName) {
                this.$refs[formName].resetFields();
            },
            //发送请求
            revise () {

                this.userName = localStorage.getItem('userLogin');
                let msg = {
                    data:{
                        "oldPwd":(md5(this.ruleForm2.oldPwd)).toUpperCase(),
                        "user":{"pwd":(md5(this.ruleForm2.pass)).toUpperCase(),"userAccount":this.userName}}
                };
                var that = this;
                that.axios.post('/user/modifyPwd',JSON.stringify(msg))
                    .then(res => {
                        if (res.data.resCode === '000000') {
                            this.$message({
                                type: 'info',
                                message: '修改成功'
                            });
                            for (var key in this.ruleForm2) {
                    this.ruleForm2[key] = '';
                }
                            //查询字段处理函数
                        }
                    })
                    .catch(error => {
                    });
                //修改密码
            },
        }
    }
</script>
<style lang="less" rel="stylesheet/less" scoped>
    @import '../../../assets/css/property.less';

    .password {
        padding: 20px 0 0 20px;
        width: 100%;
        margin-left:230px;
        min-width:1008px;
        /*flex: 1;*/
        /*!*overflow-y: scroll;*!*/
        /*padding: 20px;*/
        /*min-width: 1008px;*/
        .pass{
            box-shadow:0px 0px 8px #ccc;
            position: fixed;
            transition:opacity 2s;
            opacity:1;
            left:35%;
            top: 15%;
            width: 410px;
            height: 260px;
            border: 1px solid #ccc;
            padding:30px;
            border-radius: 5px;
            border-image: initial;
            transition: 0.2s;
            .button{
                margin-top:50px;
                button{
                    width: 140px;
                }
            }
        }
        .pass:hover{
            opacity:1;
            transition-duration:0s;
        }
    }
</style>
