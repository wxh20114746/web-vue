<template>
    <div class="edit-role">
        <div class="headerEE"><span>编辑角色</span><i class="el-icon-circle-close f-r" @click="resetForm('editMsg')"></i></div>
        <div class="content">
            <el-form ref="form" :model="editMsg" label-width="80px">
                <el-form-item label="角色名称" :required="true">
                    <el-input v-model="editMsg.role.roleName" class="add-input"></el-input>
                </el-form-item>
                <el-form-item label="角色描述">
                    <el-input type="textarea" v-model="editMsg.role.roleDesc" class="add-input"></el-input>
                </el-form-item>
                <el-form-item label="权限设置" :required="true">
                    <!--//权限选择-->
                    <div class="sheet">
                        <template>
                            <el-checkbox  v-model="checkAll" @change="handleCheckAllChange" class="checkAll">全选</el-checkbox>
                            <div style="margin: 15px 0"></div>
                            <el-checkbox-group v-model="checkedCities" @change="handleCheckedCitiesChange">
                                <el-checkbox v-for="city in cities" :label="city" :key="city" class="check">{{city}}</el-checkbox>
                            </el-checkbox-group>
                        </template>
                    </div>
                </el-form-item>
            </el-form>
        </div>
        <div class="footer">
            <div class="sub f-r">
                <el-button type="primary" @click="open2" class="but">提交</el-button>
                <el-button @click="resetForm('editMsg')" class="but">关闭</el-button>
            </div>
        </div>
    </div>
</template>
<script type="text/ecmascript-6">
    import { Message } from 'element-ui';
    const cityOptions = JSON.parse(localStorage.getItem("userInfo")).totalModule;
    const te=[]
    for(var key in cityOptions){
        te.push(cityOptions[key].moduleName)
    }
    export default {
        data() {
            return {
                checkAll: false,
                isIndeterminate: true,
                cities: te
            }
        },
        props: {
            editMsg: {
                type: Object,
                default: null
            },
            isedit:{
                type: Function,
                default: null
            },
            onEdit:{
                type: Function,
                default: null
            },
            checkedCities :{
                type:Array,
                    default:null
    }
        },
        created () {
        },
        methods: {
            handleCheckAllChange(event) {
                this.checkedCities = event.target.checked ? te : [];
                this.isIndeterminate = false;
            },
            handleCheckedCitiesChange(value) {
                let checkedCount = value.length;
                this.checkAll = checkedCount === this.cities.length;
                this.isIndeterminate = checkedCount > 0 && checkedCount < this.cities.length;
            },
            //提交编辑角色
            submitForm(formName) {
                let arr=[]
                for (var k in cityOptions) {
                    for(var i=0;i<this.checkedCities.length;i++){
                        if(cityOptions[k].moduleName==this.checkedCities[i]){
                            arr.push(cityOptions[k].moduleId)
                        }
                    }
                }

                let moduleId = arr.join(',');
                let msg = {
                    data: {
                        "moduleIds": moduleId,
                        "role": {
                            "roleDesc": this.editMsg.role.roleDesc,
                            "roleId":JSON.stringify(this.editMsg.role.roleId),
                            "roleName": this.editMsg.role.roleName}
                    }
                };
                var that = this;
                that.axios.post('/role/update',JSON.stringify(msg))
                    .then(res => {
                        if (res.data.resCode === '000000') {
                            Message.success({
                                message: '编辑成功'
                            })
                            //查询字段处理函数
                        }
                        else{
                            Message.error({
                                message: '编辑失败'
                            })
                        }
                    })
                    .catch(error => {
                        Message.error({
                            message: '编辑失败'
                        })
                    });
                this.onEdit();
                this.checkedCities=[]
                this.checkAll=false;
                this.isedit();
            },
            resetForm(formName) {
                this.checkedCities=[]
                this.checkAll=false;
                this.isedit();
            },
            open2() {
                //提交创建
                var that =this;
                if (that.editMsg.role.roleName ==='') {
                    that.$message({
                        type: 'info',
                        message: '请填写角色名称'
                    });
                    return false;
                }
                if (that.checkedCities.length===0) {
                    that.$message({
                        type: 'info',
                        message: '请选择角色权限'
                    });
                    return false;
                }
                this.$confirm('此操作将修改角色, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.submitForm(this.ruleForm2);
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消修改'
                    });
                });
            },
        }
    }
</script>
<style lang="less" rel="stylesheet/less" scoped>
    @import '../../../assets/css/property.less';

    .edit-role {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        /*left:0;*/
        /*right:0;*/
        /*margin:0 auto;*/
        background-color: #fff;
        z-index: 99;
        width: 750px;
        height: 510px;
        border: 1px solid #ccc;
        border-radius: 4px;
        .headerEE {
            background-color: #fff;
            width: 100%;
            height: 40px;
            line-height: 40px;
            text-indent: 10px;
            font-size: 14px;
            border-bottom: 1px solid #ccc;
            .el-icon-circle-close {
                font-size: 18px;
                cursor: pointer;
                margin-top: 10px;
                margin-right: 10px;
            }
        }
        .content {
            padding-top: 20px;
            height: 400px;
            border-bottom: 1px solid #ccc;
            .add-input {
                width: 260px;
            }
            .input {
                width: 320px;
                height: 35px;
            }
            .select {
                width: 222px;
            }

            .el-form-item{
                margin-left:20px;
            }
        }
        .footer {
            .sub {
                margin-top: 6px;
                margin-right: 12px;
                .but {
                    width: 70px;
                }
            }
        }
    }

    .te {
        display: inline-block;
        width: 80px;
        height: 40px;
        border: 1px solid #cccccc;
    }

    .active {
        background-color: #ccc;
    }
    .sheet{
        width: 600px;
        .checkAll{
            margin-left:5px;
        }
        .check{
            width: 100px;
            margin-left:5px;
            margin-right:20px;
        }
    }
</style>
