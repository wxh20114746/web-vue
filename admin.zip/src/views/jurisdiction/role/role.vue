<template>
    <div class="admin">
      
        <el-row class="tool">
            <el-col :span="24">
                <div class="grid-content bg-purple toolbar">
                    <el-button type="primary" class="add" size="small" @click="addAdmin">添加角色</el-button>
                </div>
            </el-col>
        </el-row>
        <div class="detlist" v-loading="loading">
            <el-table
                    ref="multipleTable"
                    :data="tableData3"
                    border
                    tooltip-effect="dark"
                    style="width: 100%"
                    @selection-change="handleSelectionChange">
                <el-table-column
                        type="selection"
                        width="55">
                </el-table-column>
                <el-table-column
                        label="角色名称"
                        width="150"
                        align="center"
                        prop="roleName">
                </el-table-column>
                <el-table-column
                        prop="roleDesc"
                        label="角色描述"
                        width="620"
                        align="center">
                </el-table-column>
                <el-table-column label="操作" align="center">
                    <template scope="scope">
                        <el-button
                                size="small"
                                type="danger"
                                @click="del(scope.$index, scope.row)">删除</el-button>
                          <el-button
                                size="small"
                                @click="handleEdit(scope.$index, scope.row)">编辑
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
            <div style="margin-top: 20px">
            <el-button type="danger" @click="dels" :disabled="this.multipleSelection.length===0">批量删除</el-button>
                <el-button @click="toggleSelection()">取消选择</el-button>
            </div>
            <page-bar :changePage="changePage"  class="f-r" :pageMsg="pageMsg" v-if="pageIf"></page-bar>
        </div>
        <transition name='fade' mode='out-in'>
            <add-role v-show="isShow" :issel="issel" :onTex="onTex" :changePage="changePage"></add-role>
        </transition>
        <transition name='fade' mode='out-in'>
        <edit-role v-if="isEdit" :editMsg="editMsg" :isedit="isedit" :onEdit="onEdit" :checkedCities="checkedCities"></edit-role>
        </transition>
    </div>
</template>
<script type="text/ecmascript-6">
    import session from '../../../utils/session'
    import addRole from './addRule.vue'
    import editRole from './editRole.vue'
    import pageBar from '../../../components/pageBar.vue'
    import {Message} from 'element-ui';
    export default {
        data() {
            return {
                multipleSelection:[],
                tableData3: [],
                isShow: false,
                loading:false,
                pageIf:true,
                title:'角色管理',
                pageMsg: {
                    pageSum: '',
                    //总页码
                    pageList: [],
                    //单页数量
                    pageSize: 10,
                    //商品总数
                    totalCount: '',
                    list: []
                },
                isEdit:false,
                editMsg:{},
                idx:'',
                checkedCities:[]
            }
        },
        components: {
            addRole,
            pageBar,
            editRole
        },
        created () {
            document.title='管理员角色';
            function getCookie(name) {
                var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");

                if (arr = document.cookie.match(reg))

                    return (arr[2]);
                else
                    return null;
            }

            function delCookie(name) {
                var exp = new Date();
                exp.setTime(exp.getTime() - 1);
                var cval = getCookie(name);
                if (cval != null)
                    document.cookie = name + "=" + cval + ";expires=" + exp.toGMTString();
            }
            this.loading = true;

            //初始化列表,查询角色分页第一页
            let msg={data:
                {"pageName":localStorage.getItem("pages"),
                    "paginator":{"limit":10,"page":1},"params":{"status":"1"}}}
            var that = this;
            that.axios.post('/page/list',JSON.stringify(msg))
                .then(res => {
            if (res.data.resCode === '000000') {
                this.loading = false;

                //查询字段处理函数
                let warningItem = res.data.repBody.list.map((value, index) => {
                        return {
                            createTime: (new Date(value.createTime)),//创建时间
                            roleCode: value.roleCode,//角色编码
                            roleDesc: value.roleDesc,//角色描述
                            roleId: value.roleId,//角色id
                            roleName: value. roleName,//角色名称
                            roleType: value.roleType,//角色类型
                            status: value.status,//状态
                            updateTime: (new Date(value.updateTime))//更新时间
                        }
                    });
                this.tableData3 = warningItem;
                //传给分页组件
                this.pageMsg.totalCount = res.data.repBody.paginator.totalCount;
                this.pageMsg.pageSum = res.data.repBody.paginator.totalPages;
                for (let i = 1; i <= this.pageMsg.pageSum; i++) {
                    this.pageMsg.pageList.push(i);
                }
                this.pageMsg.list = this.pageMsg.pageList.slice(0, 5);
            }else {
                this.loading = false;
                let message = res.data.resMsg
                this.$message({
                    type: 'info',
                    message: message
                });
            }
        })
        .catch(error => {
            this.loading = false;
            this.$message({
                type: 'info',
                message: '网络错误'
            });
        });

        },
        methods: {
            del (index,row) {
                this.$confirm('此操作将永久删除该项, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.handleDelete(index,row);
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消'
                    });
                });
            },
            dels (index,row) {
                this.$confirm('此操作将永久删除该项, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.batchRemove(index,row);
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消'
                    });
                });
            },
            onTex (val) {
                var newV={roleName:val.roleName,
                    roleDesc:val.roleDesc}
                this.tableData3.push(newV);
            },
            //编辑后的修改
            onEdit () {
                this.tableData3[this.idx].roleDesc = this.editMsg.role.roleDesc;
                this.tableData3[this.idx].roleId = this.editMsg.role.roleId;
                this.tableData3[this.idx].roleName =this.editMsg.role.roleName;
                this.tableData3[this.idx].status = this.editMsg.role.status;
            },
            nowTime (ns) {
                return new Date(parseInt(ns) * 1000).toLocaleString().replace(/:\d{1,2}$/,' ');
            },
            toggleSelection(rows) {
                if (rows) {
                    rows.forEach(row => {
                        this.$refs.multipleTable.toggleRowSelection(row);
                    });
                } else {
                    this.$refs.multipleTable.clearSelection();
                }
            },
            handleSelectionChange(val) {
                this.multipleSelection = val;
            },
            addAdmin () {
                this.isShow = true;
            },
            issel () {
                this.isShow = false;
            },
            isedit () {
                this.isEdit = false;
            },
            //删除
            handleDelete(index, row) {
                this.loading = true;
                let ss = String(row.roleId);
                let msg = {data: {"roleIds": (ss)}};
                var that = this;
                that.axios.post('/role/delete',JSON.stringify(msg))
                    .then(res => {
                        if (res.data.resCode === '000000') {
                            this.changePage(1);
                            this.loading = false;
                            this.$message({
                                type: 'info',
                                message: '删除成功'
                            });
                        }else{
                            this.loading = false;
                            let message = res.data.resMsg
                            this.$message({
                                type: 'info',
                                message: message
                            });
                        }
                    })
                    .catch(error => {
                    let message = res.data.resMsg
                    this.loading = false;
                this.$message({
                    type: 'info',
                    message: message
                });
              })
            },
            batchRemove () {
                //批量删除
                this.loading = true;
                var ids = this.multipleSelection.map(item => item.roleId)//获取所有选中行的id组成的字符串，以逗号分隔
                var arr = [];
                let table = this.tableData3;
                //逗号连接
                let idd = ids.join(',');
                let msg = {data: {"roleIds": (idd)}};
                var that = this;
                that.axios.post('/role/delete',JSON.stringify(msg))
                    .then(res => {
                        if (res.data.resCode === '000000') {
                            this.loading = false;
                    this.$message({
                        type: 'info',
                        message: '删除成功'
                    });
                    this.changePage(1);
                        }else{
                    this.loading = false;
                    let message = res.data.resMsg
                    this.$message({
                        type: 'info',
                        message: message
                    });
                }
                    })
                    .catch(error => {
                    this.loading = false;
                let message = res.data.resMsg
                this.$message({
                    type: 'info',
                    message: message
                });
                    })
            },
            submitForm(formName) {
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        alert('submit!');
                    } else {
                        return false;
                    }
                });
            },
            resetForm(formName) {
                this.$refs[formName].resetFields();
                this.issel()
            },
            //渲染列表
            changePage (num,list) {
                this.loading = true;
                let msg={data:
                    {"pageName":localStorage.getItem("pages"),
                        "paginator":{"limit":10,"page":num},"params":{"status":"1"}}}
                if(num=='1'){
                    this.pageIf=false;
                }
                var that = this;
                that.axios.post('/page/list',JSON.stringify(msg))
                    .then(res => {
                        if (res.data.resCode === '000000') {
                            this.loading = false;
                            //查询字段处理函数
                            let warningItem = res.data.repBody.list.map((value, index) => {
                                return {
                                    createTime: (new Date(value.createTime)),//创建时间
                                    roleCode: value.roleCode,//角色编码
                                    roleDesc: value.roleDesc,//角色描述
                                    roleId: value.roleId,//角色id
                                    roleName: value. roleName,//角色名称
                                    roleType: value.roleType,//角色类型
                                    status: value.status,//状态
                                    updateTime: (new Date(value.updateTime))//更新时间
                                }
                            });
                            this.tableData3 = warningItem;
                            if(num=='1'){
                                this.pageIf=true;
                            }
                            this.pageMsg.totalCount = res.data.repBody.paginator.totalCount;
                            this.pageMsg.pageSum = res.data.repBody.paginator.totalPages;
                            for (let i = 1; i <= this.pageMsg.pageSum; i++) {
                                this.pageMsg.pageList.push(i);
                            }
                            if((num - 1) % 5 === 0){
                                this.pageMsg.list = this.pageMsg.pageList.slice(num - 1, num + 4);
                            }else if(num==1){
                                this.pageMsg.list = this.pageMsg.pageList.slice(0, 5);
                            }else if(num==this.pageMsg.pageSum&&(num % 5) === 0){
                                this.pageMsg.list = this.pageMsg.pageList.slice(num - 5, num);
                            }else if(num==this.pageMsg.pageSum&&(num % 5) !== 0){
                                let nn=num%5;
                                this.pageMsg.list = this.pageMsg.pageList.slice(num - nn, num);
                            }else if((num) % 5 === 0){
                                this.pageMsg.list = this.pageMsg.pageList.slice(num - 5, num);
                            }else{
                                this.pageMsg.list = list
                            }
                        }else{
                            this.loading = false;
                            this.$message({
                                type: 'info',
                                message: '网络错误'
                            });
                        }
                    })
                    .catch(error => {
                        this.loading = false;
                        this.$message({
                            type: 'info',
                            message: '网络错误'
                        });
                    })

            },
            reload () {
                this.$router.push({
                    path: '/empty'
                })
            },
            handleEdit(index, row) {
                console.log(index,row)
                //编辑
                this.checkedCities=[];
                this.idx=index;
                let msg = {data: {"roleId": JSON.stringify(row.roleId)}};
                //删除的字符串,发送符合格式的id
                var that = this;
                that.axios.post('/role/detail',JSON.stringify(msg))
                    .then(res => {
                        if (res.data.resCode === '000000') {
                            that.editMsg=res.data.repBody;
                            for(var key in res.data.repBody.modules){
                                that.checkedCities.push((res.data.repBody.modules)[key].moduleId)
                            }
                            var cityOptions=JSON.parse(localStorage.getItem("userInfo")).totalModule;
                            for (var k in cityOptions) {
                                for(var i=0;i<that.checkedCities.length;i++){
                                    if(cityOptions[k].moduleId==that.checkedCities[i]){
                                        that.checkedCities[i]=cityOptions[k].moduleName
                                    }
                                }
                            }
                        }
                    })
                    .catch(error => {
                    })

                this.isEdit = true;
            },
            reloadReal () {

            }
        }
    }
</script>
<style lang="less" rel="stylesheet/less" scoped>
    @import '../../../assets/css/property.less';

    .admin {
        padding: 20px 20px 0 20px;
        width: 100%;
        min-width:1008px;
        margin-left:230px;
        margin-top:60px;
        .admin-content {
            padding: 10px 10px;
            width: 100%;
            height: 50px;
            border: 1px solid #ccc;
            .add {
                margin-top: 15px;
                font-size: 14px;
            }
        }
        .detlist {
            width: 100%;
        }
        .el-row {
            margin-bottom: 20px;
            &:last-child {
                margin-bottom: 0;
            }
        }
        .tool{
            background-color: #f2f2f2;
            padding:10px;
            border-radius: 4px;
            margin: 10px 0px;

        }
        .el-col {
            border-radius: 4px;
            /*padding:10px;*/
        }
        .bg-purple-dark {
            background: #99a9bf;
        }
        .bg-purple {
            background: #f2f2f2;
        }
        .bread {
            padding-top: 2px;
            height: 24px;
            /*line-height: 50px;*/
            font-size: 14px;
        }
        .toolbar {
            /*background-color: #f2f2f2;*/
            /*padding: 10px;*/
            /*margin: 10px 0px;*/
            .add{
                font-size:14px;
            }
            .el-form-item {
                margin-bottom: 10px;
            }
        }
    }
</style>
