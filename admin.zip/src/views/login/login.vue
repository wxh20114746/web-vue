<template>
  <div class="m-login"> 
    <div class="login-m">  
      <el-form :model="ruleForm2" :rules="rules2" ref="ruleForm2" label-position="left" label-width="0px"
             class="demo-ruleForm login-container">
        <h3 class="title">车管所系统登录</h3>
        <el-form-item prop="account">
            <el-input type="text" v-model="ruleForm2.account" auto-complete="off" placeholder="账号"></el-input>
        </el-form-item>
        <el-form-item prop="checkPass">
            <el-input type="password" v-model="ruleForm2.checkPass" auto-complete="off" placeholder="密码" @keydown.enter.native.prevent="handleSubmit2"></el-input>
        </el-form-item>
        <el-form-item v-show="isYcode" prop="auth" style="width:100%;">
            <el-input type="text" v-model="ruleForm2.auth" auto-complete="off" placeholder="验证码" style="width:55%;vertical-align: middle" @keydown.enter.native.prevent="handleSubmit2" :maxlength="4"></el-input>
            <div class="f-r">
            <canvas id="canvas" width="120" height="36" style="vertical-align: middle"></canvas>
            <img src="../../assets/img/icon/refresh.svg" style="display: inline-block;vertical-align: middle;cursor:pointer" width="20" @click="changeImg">
            </div>
        </el-form-item> 
        <el-form-item  style="width:100%;margin-bottom: 0px">
            <el-checkbox v-model="check" style="color:#a0a0a0;font-weight: 200">记住登录信息</el-checkbox>
            <el-button
                    plain
                    @click="open5" style="float: right;text-decoration: none;color: #f19149;border: 0;padding-right: 0">
                忘记密码?
            </el-button>
        </el-form-item>
        <el-form-item style="width:100%;">
            <el-button type="primary" style="width:100%;" @click.native.prevent="handleSubmit2" :loading="logining">登录
            </el-button>
        </el-form-item>
    </el-form>
  </div>
</div>
</template>
<script>
    import session from '../../utils/session'
    import {Message} from 'element-ui';
    import { MessageBox } from 'element-ui';
    import md5 from 'js-md5';
    export default {
        data() {
            return {
                isYcode:false,
                isIndex:0,
                check:false,
                logining: false,
                ruleForm2: {
                    account: '',
                    checkPass: '',
                    auth:''
                },
                text:"",
                rules2: {
                    account: [
                        {required: true, message: '请输入账号', trigger: 'blur'},
                        {min: 3, max: 20, message: '长度在 3 到 20 个字符', trigger: 'blur'}
                    ],
                    checkPass: [
                        {required: true, message: '请输入密码', trigger: 'blur'},
                        {min: 3, max: 20, message: '长度在 3 到 20 个字符', trigger: 'blur'}
                    ],
                    auth:[
                        {required: true, message: '请输入验证码', trigger: 'blur'},
                        {min: 4, max: 4, message: '请输入4位数验证码', trigger: 'blur'}
                    ]
                },
                sidebarList:[],  //侧边栏菜单
                checked: true,
                userIn: {},
                isImg:false,
                code:''
            };
        },
        created () {
            // document.title='登录';
            localStorage.clear();
            function getCookie(name)
            {
                var arr,reg=new RegExp("(^| )"+name+"=([^;]*)(;|$)");

                if(arr=document.cookie.match(reg))

                    return (arr[2]);
                else
                    return null;
            }
            function delCookie(name)
            {
                var exp = new Date();
                exp.setTime(exp.getTime() - 1);
                var cval=getCookie(name);
                if(cval!=null)
                    document.cookie= name + "="+cval+";expires="+exp.toGMTString();
            }
            delCookie('JSESSIONID');
            var that=this;
//            13223wrwe4345678
            //解密
            function Decrypt(word){ 
                var key = CryptoJS.enc.Utf8.parse("13223wrwe4345678"); 
                var decrypt = CryptoJS.AES.decrypt(word, key, {mode:CryptoJS.mode.ECB,padding: CryptoJS.pad.Pkcs7}); 
                return CryptoJS.enc.Utf8.stringify(decrypt).toString();
            }  
            
            let msg={data:""}; 
            that.axios.post('/user/imageCode',JSON.stringify(msg))
                .then(res => {
                    console.log(res)
                    that.code=Decrypt(res.data.repBody); 
                    if (res.data.resCode === '000000') {
                        //渲染处理函数
                    }else {
                        let message = res.data.resMsg
                        MessageBox.alert(message).then(action => {
                            delCookie('JSESSIONID');
                            localStorage.clear();
                            sessionStorage.clear();
                            that.$router.push('/login')
                        });
                    }
                })
                .catch(error => {
                })
        },
        mounted () {
            var that = this;
            this.$nextTick(function () {
                that.drawPic();
            });
            this.getCookie();
        },
        watch : {
            'code' :function(){
                this.drawPic()
            }
        },
        methods: {
            verifyName () {
                if (!/^[\u4E00-\u9FA5A-Za-z0-9]{2,20}$/.test(this.ruleForm2.account)) {
                    this.isShowN = true
                } else {
                    this.isShowN = false
                }
            },
            handleReset2() {
            },
            handleSubmit2(ev) {
             var that=this;
                if (this.ruleForm2.account==='') {
                    that.$message({
                        type: 'info',
                        message: '账号不能为空'
                    });
                    return false;
                }
                if (this.ruleForm2.checkPass==='') {
                    that.$message({
                        type: 'info',
                        message: '密码不能为空'
                    });
                    return false;
                }
                if(this.isYcode){
                  if (this.ruleForm2.auth==="") {
                      that.$message({
                          type: 'info',
                          message: '验证码不能为空'
                      });
                      return false;
                  }
                }
                // if (this.ruleForm2.auth==="") {
                //     that.$message({
                //         type: 'info',
                //         message: '验证码不能为空'
                //     });
                //     return false;
                // }

                //保存的账号
                var name=this.ruleForm2.account;
                //保存的密码
                var pass=this.ruleForm2.checkPass;

                let msg = {
                    data: {
                        "userAccount": this.ruleForm2.account, "pwd": (md5(this.ruleForm2.checkPass)).toUpperCase(),
                        imageCode:this.ruleForm2.auth
                    }
                };
                var that = this;
                var limit={business:[],code:[],authority:[]}

                that.axios.post('/user/login', JSON.stringify(msg))
                    .then(res => {
                        if (res.data.resCode === '000000') {

                            //渲染处理函数
                            if (res.data.repBody.login === 'success') {
                                 
                                let userInfo = JSON.stringify(res.data.repBody);
                                localStorage.setItem('userInfo', userInfo);
                                localStorage.setItem('userID', res.data.repBody.userInfo.userId);
                                that.sidebarList = res.data.repBody.menu.menus;
                                // console.log(that.sidebarList)
                                // if(res.data.repBody.menu.business){
                                //     limit.business=res.data.repBody.menu.business.menus;
                                // }
                                // if(res.data.repBody.menu.code){
                                //     limit.code=res.data.repBody.menu.code.menus;
                                // }
                                // if(res.data.repBody.menu.authority){
                                //     limit.authority=res.data.repBody.menu.authority.menus;
                                // }
                                localStorage.setItem('newNavList',JSON.stringify(that.sidebarList));
                                localStorage.setItem('jurisdiction',JSON.stringify(limit));
                                localStorage.setItem('userNames', this.ruleForm2.account);
                                window.document.cookie='JSESSIONID'+'='+res.data.repBody.JSESSIONID;
                                localStorage.setItem('loginTime', new Date().getTime());
                                //缓存是否分公司
                                // localStorage.setItem('areaCodeNum', res.data.repBody.userInfo.areaCode.split(',').length);

                                //缓存当前用户的地区代码到cookie中
                                // window.document.cookie = 'meto'+'='+res.data.repBody.userInfo.areaCode;
// 

                                this.$message({
                                    type: 'success',
                                    message: '登录成功'
                                });
 

                                //判断复选框是否被勾选 勾选则调用配置cookie方法
                                if(that.check==true){
                                    //传入账号名，密码，和保存天数3个参数
                                    that.setCookie(name,pass,7);
                                }else{
                                    that.clearCookie();
                                }
                                let firRouter = res.data.repBody.menu.menus[0].menus[0].url;
                                 this.$router.push(firRouter);
                            } else {
                                that.changeImg();
                                this.$message({
                                    type: 'info',
                                    message: '登录失败'
                                });
                            }

                        }else if(res.data.resCode === '100001'){

                            if(this.isIndex < 2){
                                this.isIndex++;
                            }else{
                                this.isYcode = true;
                            }
                          // if(res.data.repBody.loginNum != null){
                               // this.isYcode = true
                            // }
                            that.changeImg();
                            let msg=res.data.resMsg;
                            this.$message({
                                type: 'info',
                                message: msg
                            });
                        }else{
                            that.changeImg();
                            let msg=res.data.resMsg;
                            this.$message({
                                type: 'info',
                                message: msg
                            });
                        }
                    })
                    .catch(error => {
                        that.changeImg();

                    });
                session.setLoginUser({
                    "userAccount": this.ruleForm2.account
                });
            },
            drawPic () {
                /**绘制验证码图片**/
                var that=this;
                    var canvas=document.getElementById("canvas");
                    var width=canvas.width;
                    var height=canvas.height;
                    var ctx = canvas.getContext('2d');
                    ctx.textBaseline = 'middle';

                    /**绘制背景色**/
                    ctx.fillStyle = that.randomColor(180,240); //颜色若太深可能导致看不清
                    ctx.fillRect(0,0,width,height);
                    /**绘制文字**/
                var str=that.code;
                console.log(str)
                    for(var i=0; i<4; i++){
                        var txt = str[i];
                        that.text=that.text+txt;
                        ctx.fillStyle = that.randomColor(50,160);  //随机生成字体颜色
                        ctx.font = that.randomNum(20,40)+'px SimHei'; //随机生成字体大小
                        ctx.shadowOffsetX=that.randomNum(-3,3);
                        ctx.shadowOffsetY=that.randomNum(-3,3);
                        ctx.shadowBlur=that.randomNum(-3,3);
                        var x = 15+width/5*i;
                        var y = height/2;
                        var deg = that.randomNum(-30, 30);
                        //修改坐标原点和旋转角度
                        ctx.translate(x,y);
                        ctx.rotate(deg*Math.PI/180);
                        ctx.fillText(txt, 0,0);
                        //恢复坐标原点和旋转角度
                        ctx.rotate(-deg*Math.PI/180);
                        ctx.translate(-x,-y);
                    }
                    /**绘制干扰线**/
                    for(var i=0; i<6; i++){
                        ctx.strokeStyle = that.randomColor(40,180);
                        ctx.beginPath();
                        ctx.moveTo( that.randomNum(0,width), that.randomNum(0,height) );
                        ctx.lineTo( that.randomNum(0,width), that.randomNum(0,height) );
                        ctx.stroke();
                    }
                    /**绘制干扰点**/
                    for(var i=0; i<50; i++){
                        ctx.fillStyle = that.randomColor(0,255);
                        ctx.beginPath();
                        ctx.arc(that.randomNum(0,width),that.randomNum(0,height), 1, 0, 2*Math.PI);
                        ctx.fill();
                    }
            },
            draw () {
                /**生成一个随机数**/
                function randomNum(min,max){
                    return Math.floor( Math.random()*(max-min)+min);
                }
                /**生成一个随机色**/
                function randomColor(min,max){
                    var r = randomNum(min,max);
                    var g = randomNum(min,max);
                    var b = randomNum(min,max);
                    return "rgb("+r+","+g+","+b+")";
                }
                this.drawPic();
                document.getElementById("changeImg").onclick = function(e){
                    e.preventDefault();
                    drawPic();
                }
            },
            changeImg (e) {  
                this.text='';
                var that=this;
                function Decrypt(word){
                    var key = CryptoJS.enc.Utf8.parse("13223wrwe4345678");
                    var decrypt = CryptoJS.AES.decrypt(word, key, {mode:CryptoJS.mode.ECB,padding: CryptoJS.pad.Pkcs7});
                    return CryptoJS.enc.Utf8.stringify(decrypt).toString();
                }
            let msg={data:""};
            that.axios.post('/user/imageCode')
                .then(res => {
                    if (res.data.resCode === '000000') {
                        //渲染处理函数
                        that.code=Decrypt(res.data.repBody); 
                        that.drawPic();
                    }else {
                        let message = res.data.resMsg
                        MessageBox.alert(message).then(action => {
                            delCookie('JSESSIONID');
                            localStorage.clear();
                            sessionStorage.clear();
                            that.$router.push('/login')
                        });
                    }
                })
                .catch(error => {
                })
            },
            /**生成一个随机数**/
            randomNum (min,max) {
                return  Math.floor( Math.random()*(max-min)+min);
            },
            /**生成一个随机色**/
            randomColor (min,max) {
                var r = this.randomNum(min,max);
                var g = this.randomNum(min,max);
                var b = this.randomNum(min,max);
                return "rgb("+r+","+g+","+b+")";
            },
            encryption () {
                var key = CryptoJS.enc.Utf8.parse("13223wrwe4345678");
//                加解密密钥：13223wrwe4345678
                var plaintText = this.ruleForm2.auth; // 明文
                var encryptedData = CryptoJS.AES.encrypt(plaintText, key, {
                    mode: CryptoJS.mode.ECB,
                    padding: CryptoJS.pad.Pkcs7
                });
//                console.log("加密前："+plaintText);
//                console.log("加密后："+encryptedData);
                encryptedData = encryptedData.ciphertext.toString();
                var encryptedHexStr = CryptoJS.enc.Hex.parse(encryptedData);
                var encryptedBase64Str = CryptoJS.enc.Base64.stringify(encryptedHexStr);
                var decryptedData = CryptoJS.AES.decrypt(encryptedBase64Str, key, {
                    mode: CryptoJS.mode.ECB,
                    padding: CryptoJS.pad.Pkcs7
                });
                var decryptedStr = decryptedData.toString(CryptoJS.enc.Utf8);
//                console.log("解密后:"+decryptedStr);
                var pwd = encryptedData;
                //加密服务端返回的数据
                var decryptedData = CryptoJS.AES.decrypt(pwd, key, {
                    mode: CryptoJS.mode.ECB,
                    padding: CryptoJS.pad.Pkcs7
                });
//                console.log("解密服务端返回的数据:"+decryptedStr);
                return encryptedData.toString();
            },
            //设置cookie
            setCookie(c_name,c_pwd,exdays) {
                var exdate=new Date();//获取时间
                exdate.setTime(exdate.getTime() + 24*60*60*1000*exdays);//保存的天数
                //字符串拼接cookie
                window.document.cookie="userName"+ "=" +c_name+";path=/;expires="+exdate.toGMTString();
                window.document.cookie="userPwd"+"="+c_pwd+";path=/;expires="+exdate.toGMTString();
            },
            //读取cookie
            getCookie:function () {
                if (document.cookie.length>0) {
                    var arr=document.cookie.split('; ');//这里显示的格式需要切割一下自己可输出看下
                    for(var i=0;i<arr.length;i++){
                        var arr2=arr[i].split('=');//再次切割
                        //判断查找相对应的值
                        if(arr2[0]=='userName'){
                            this.ruleForm2.account=arr2[1];//保存到保存数据的地方
                            if(this.ruleForm2.account != null && this.ruleForm2.account != ""){
                                 this.check = true
                            }else{
                                 this.check = false
                            }
                        }else if(arr2[0]=='userPwd'){
                            this.ruleForm2.checkPass=arr2[1];
                        }
                    }
                }
            },
            //清除cookie
            clearCookie:function () {
                this.setCookie("","",-1);//修改2值都为空，天数为负1天就好了
            },
            open5() {
              this.$message({
                        showClose: true,
                        message: '忘记密码，请联系管理员',
                        type: 'error'
                      });
            },
        }
    }
</script>
<style lang="less" rel="stylesheet/less">
    @import '../../assets/css/property.less';
    @import '../../assets/less/login-new';
    // .login-container {
    //     /*box-shadow: 0 0px 8px 0 rgba(0, 0, 0, 0.06), 0 1px 0px 0 rgba(0, 0, 0, 0.02);*/
    //     -webkit-border-radius: 5px;
    //     border-radius: 5px;
    //     -moz-border-radius: 5px;
    //     background-clip: padding-box;
    //     margin: 180px auto;
    //     width: 350px;
    //     padding: 35px 35px 15px 35px;
    //     background: #fff;
    //     border: 1px solid #eaeaea;
    //     box-shadow: 0 0 25px #cac6c6;
    //     .title {
    //         margin: 0px auto 40px auto;
    //         text-align: center;
    //         color: #505458;
    //     }
    //     .remember {
    //         margin: 0px 0px 35px 0px;
    //     }
    //     .image{
    //         /*height: 30px;*/
    //         /*vertical-align: middle;*/
    //     }
    // }
</style>
