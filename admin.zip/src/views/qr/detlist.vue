<template>
    <!--码任务-->
    <div class="detlist" v-loading="loading">
        <el-table
                :data="tableData"
                border
                style="width: 100%">
            <el-table-column
                    prop="oddnum"
                    label="任务号"
                    width="120"
                    align="center">
            </el-table-column>
            <el-table-column
                    prop="oddname"
                    label="任务名称"
                    width="120"
                    align="center">
            </el-table-column>
            <el-table-column
                    prop="ordernum"
                    label="批次号"
                    width="120"
                    align="center">
            </el-table-column>
            <el-table-column
                    prop="date"
                    label="申请时间"
                    width="250"
                    align="center">
            </el-table-column>
            <el-table-column
                    prop="count"
                    label="制码量"
                    width="120"
                    align="center">
            </el-table-column>
            <el-table-column
                    prop="stage"
                    label="制码阶段"
                    width="130"
                    align="center">
            </el-table-column>
            <el-table-column
                    prop="status"
                    label="状态"
                    width="120"
                    align="center">
            </el-table-column>
            <el-table-column  label="操作" :formatter="formatter" prop="ordernum" align="center">
                <template scope="scope">
                    <el-button
                            size="small"
                            type="success"
                            v-if="scope.row.stage=='完成'&&scope.row.status=='正常结束'"
                    ><a :href="baseUrl+'makeTask/download_code_zip?taskId='+scope.row.oddnum" download="二维码" class="download"></a>下载待印文件</el-button>
                    <el-button
                            size="small"
                            type="success"
                            @click="compress(scope.$index, scope.row)"
                            v-else-if="scope.row.stage=='上传'&&scope.row.status=='正常结束'"
                    >压缩待印文件
                    </el-button>
                    <el-button
                            size="small"
                            type="warning"
                            @click="abnormal(scope.$index, scope.row)"
                            v-else-if="scope.row.stage=='上传'&&scope.row.status=='异常结束'"
                    >处理完成异常
                    </el-button>
                    <el-button
                            size="small"
                            type="warning"
                            @click="abnormal(scope.$index, scope.row)"
                            v-else-if="scope.row.stage=='完成'&&scope.row.status=='异常结束'"
                    >处理完成异常
                    </el-button>
                    <el-button
                            size="small"
                            type="warning"
                            @click="abnormal(scope.$index, scope.row)"
                            v-else-if="scope.row.stage=='开始'&&scope.row.status=='异常结束'"
                    >处理开始异常
                    </el-button>
                    <el-button
                            size="small"
                            type="warning"
                            @click="abnormal(scope.$index, scope.row)"
                            v-else-if="scope.row.stage=='生成待印文件'&&scope.row.status=='异常结束'"
                    >处理待印异常
                    </el-button>
                    <el-button
                            size="small"
                            type="warning"
                            @click="abnormal(scope.$index, scope.row)"
                            v-else-if="scope.row.stage=='制码'&&scope.row.status=='异常结束'"
                    >处理生成码异常
                    </el-button>
                    <el-button
                            size="small"
                            type="warning"
                            @click="abnormal(scope.$index, scope.row)"
                            v-else-if="scope.row.stage=='入库'&&scope.row.status=='异常结束'"
                    >处理入库异常
                    </el-button>
                    <el-button
                            size="small"
                            type="primary"
                            v-else
                            @click="check(scope.$index, scope.row)"
                    >查看
                    </el-button>
                </template>
            </el-table-column>
        </el-table>
        <page-bar :changePage="changePage"  class="f-r" :pageMsg="pageMsg" v-if="pageIf"></page-bar>
        <exdetail ref="exdetail" :msg="msg"></exdetail>
    </div>
</template>
<script type="text/ecmascript-6">
    import exdetail from './exdetail.vue'
    import pageBar from '../../components/pageBar.vue'
    import {MessageBox} from 'element-ui';
    import {Message} from 'element-ui';
    import axios from 'axios'
    export default {
        data() {
            return {
                loading: false,
                tableData: [],
                pageIf:true,
                pageMsg: {
                    pageSum: '',
                    //总页码
                    pageList: [],
                    //单页数量
                    pageSize: 10,
                    //商品总数
                    totalCount: '',
                    list: []
                },
                msg:{},
                baseUrl:''
            }
        },
        components: {
            pageBar,
            exdetail
        },
        props:{
            changeData:{
                type:Function,
                default:null
            } ,
            search:{
                type:Object,
                default:null
            }
        },
        watch :{
            'search' :{
                handler:function(val,oldval){
                    this.changePage(1);
                }
            }
        },
        created () {
            this.baseUrl=axios.defaults.baseURL;
            function getCookie(name) {
                var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");

                if (arr = document.cookie.match(reg))

                    return (arr[2]);
                else
                    return null;
            }

            function delCookie(name) {
                var exp = new Date();
                exp.setTime(exp.getTime() - 1);
                var cval = getCookie(name);
                if (cval != null)
                    document.cookie = name + "=" + cval + ";expires=" + exp.toGMTString();
            }
            //初始化列表
            this.loading = true;
            let msg={data:
                {"pageName":localStorage.getItem("pages"),
                    "paginator":{"limit":10,"page":1},
                    "params":{"businessId":"","phase":""}}};
            var that = this;
            that.axios.post('/page/list',JSON.stringify(msg))
                .then(res => {
                    if (res.data.resCode === '000000') {
                        this.loading = false;
                        //查询字段处理函数
                        let warningItem = res.data.repBody.list.map((value, index) => {
                            return {
                                oddnum: value.taskId||'',//批次id
                                oddname: value.taskName||'',//制码任务
                                ordernum: value.businessId||'',
                                date: (new Date(value.createTime)).toLocaleString()||'',//完成时间
                                count: value.codeNum||'',//制码数量
                                stage:  this.transition2(value.phase)||'',//制码阶段
                                status: this.transition(value.status)||''//状态
                            }
                        });
                        this.tableData = warningItem;
                        //传给分页组件
                        this.pageMsg.totalCount = res.data.repBody.paginator.totalCount;
                        this.pageMsg.pageSum = res.data.repBody.paginator.totalPages;
                        for (let i = 1; i <= this.pageMsg.pageSum; i++) {
                            this.pageMsg.pageList.push(i);
                        }
                        this.pageMsg.list = this.pageMsg.pageList.slice(0, 5);
                    }else {
                        this.loading = false;
                        let message = res.data.resMsg
                        MessageBox.alert(message).then(action => {
                            delCookie('JSESSIONID');
                            localStorage.clear();
                            sessionStorage.clear();
                            that.$router.push('/login')
                        });
                    }
                })
                .catch(error => {
                    this.loading = false;
                    let message = res.data.resMsg
                    MessageBox.alert(message).then(action => {
                        delCookie('JSESSIONID');
                        localStorage.clear();
                        sessionStorage.clear();
                        that.$router.push('/login')
                    });
                });
        },
        methods: {
            //渲染列表
            changePage (num,list) {
                function getCookie(name) {
                    var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");

                    if (arr = document.cookie.match(reg))

                        return (arr[2]);
                    else
                        return null;
                }
                function delCookie(name) {
                    var exp = new Date();
                    exp.setTime(exp.getTime() - 1);
                    var cval = getCookie(name);
                    if (cval != null)
                        document.cookie = name + "=" + cval + ";expires=" + exp.toGMTString();
                }
                this.pageMsg={
                    pageSum: '',
                    //总页码
                    pageList: [],
                    //单页数量
                    pageSize: 10,
                    //商品总数
                    totalCount: '',
                    list: []
                };
                this.loading = true;
                let msg={data:
                    {"pageName":localStorage.getItem("pages"),
                        "paginator":{"limit":10,"page":num},
                        "params":this.search}};
                if(num=='1'){
                    this.pageIf=false;
                }
                var that = this;
                that.axios.post('/page/list',JSON.stringify(msg))
                    .then(res => {
//总页数=商品总数/单页数
                        if (res.data.resCode === '000000') {
                            //渲染处理函数
                            this.loading = false;
                            //一个人写的接口,格式不一致,同样是数组,有的是erpBody.list,有的是repBody
                            let warningItem = res.data.repBody.list.map((value, index) => {
                                return {
                                    //字段
                                    oddnum: value.taskId||'',//批次id
                                    oddname: value.taskName||'',//制码任务
                                    ordernum: value.businessId||'',
                                    date: (new Date(value.createTime)).toLocaleString()||'',//完成时间
                                    count: value.codeNum||'',//制码数量
                                    stage:  this.transition2(value.phase)||'',//制码阶段
                                    status: this.transition(value.status)||''//状态
                                }
                            });
                            this.tableData = warningItem;
                            if(num=='1'){
                    this.pageIf=true;
                }
                            this.pageMsg.totalCount = res.data.repBody.paginator.totalCount;
                            this.pageMsg.pageSum = res.data.repBody.paginator.totalPages;
                            for (let i = 1; i <= this.pageMsg.pageSum; i++) {
                                this.pageMsg.pageList.push(i);
                            }
                    if((num - 1) % 5 === 0){
                        this.pageMsg.list = this.pageMsg.pageList.slice(num - 1, num + 4);
                    }else if(num==1){
                        this.pageMsg.list = this.pageMsg.pageList.slice(0, 5);
                    }else if(num==this.pageMsg.pageSum&&(num % 5) === 0){
                        this.pageMsg.list = this.pageMsg.pageList.slice(num - 5, num);
                    }else if(num==this.pageMsg.pageSum&&(num % 5) !== 0){
                        let nn=num%5;
                        this.pageMsg.list = this.pageMsg.pageList.slice(num - nn, num);
                    }else if((num) % 5 === 0){
                        this.pageMsg.list = this.pageMsg.pageList.slice(num - 5, num);
                    }else{
                        this.pageMsg.list = list
                    }
                        }else{
                            this.loading = false;
                            let message = res.data.resMsg
                            MessageBox.alert(message).then(action => {
                                delCookie('JSESSIONID');
                                localStorage.clear();
                                sessionStorage.clear();
                                that.$router.push('/login')
                            });
                        }
                    })
                    .catch(error => {
                        this.loading = false;
                        let message = res.data.resMsg
                        MessageBox.alert(message).then(action => {
                            delCookie('JSESSIONID');
                            localStorage.clear();
                            sessionStorage.clear();
                            that.$router.push('/login')
                        });
                    })
            },
            formatter(row, column) {
                return row.address;
            },
            //下载
            download(index, row) {
                let msg={data:
                    {"taskId":row.oddnum}};
                var that = this;
                that.axios.post('/makeTask/download_code_zip',JSON.stringify(msg))
                    .then(res => {
                        if (res.data.resCode === '000000') {
                            //渲染处理函数''


                        }else if(res.data.resCode === '100200'){
                            this.$message({
                                type: 'info',
                                message: res.data.resMsg
                            });
                        }else{
                            this.$message({
                                type: 'info',
                                message: res.data.resMsg
                            });
                        }
                    })
                    .catch(error => {
                        this.$message({
                            type: 'info',
                            message: res.data.resMsg
                        });
                    });

            },
            //下载
            submit(index,row) {
                this.$confirm('此操作将下载待印文件, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.download(index, row);
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消'
                    });
                });
            },
            //压缩
            compress (index,row) {
                if(row.stage=='完成'&& row.status=='正常结束'){
                    return false
                }
                let msg={data:
                    {"taskId":row.oddnum}};

                var that = this;
                that.axios.post('/makeTask/download_code',JSON.stringify(msg))
                    .then(res => {
                        if (res.data.resCode === '000000') {
                            //渲染处理函数''
                            row.stage='完成'
                            row.status='正常结束'
                            that.$message({
                                type: 'info',
                                message: '压缩成功'
                            });
                        }else if(res.data.resCode === '100200'){
                            this.$message({
                                type: 'info',
                                message: '压缩失败'
                            });
                        }else{
                            this.$message({
                                type: 'info',
                                message: '压缩失败'
                            });
                        }
                    })
                    .catch(error => {
                        this.$message({
                            type: 'info',
                            message: res.data.resMsg
                        });
                    });
            },
            //处理异常
            abnormal (index,row) {
                let msg={data:
                    {"taskId":row.oddnum}};
                var that = this;
                that.axios.post('/makeTask/code',JSON.stringify(msg))
                    .then(res => {
                        if (res.data.resCode === '000000') {
                            //渲染处理函数''
                            that.$message({
                                type: 'info',
                                message: '已处理'
                            });
                        }else if(res.data.resCode === '100200'){
                            this.$message({
                                type: 'info',
                                message: res.data.resMsg
                            });
                        }else{
                            this.$message({
                                type: 'info',
                                message: res.data.resMsg
                            });
                        }
                    })
                    .catch(error => {
                        this.$message({
                            type: 'info',
                            message: res.data.resMsg
                        });
                    });
            },
            //查看
            check (index,row) {
                let msg={data:
                    {"taskId":row.oddnum}};
                var that = this;
                that.axios.post('/makeTask/queryMakeTaskLog',JSON.stringify(msg))
                    .then(res => {
                if (res.data.resCode === '000000') {
                    //渲染处理函数''
                    that.msg=res.data.repBody;
                    that.msg.makeTask.phase=that.transition2(that.msg.makeTask.phase);
                    that.msg.makeTask.createTime=(new Date(that.msg.makeTask.createTime)).toLocaleString()
                    if(that.msg.makeTask.completeTime){
                        that.msg.makeTask.completeTime=(new Date(that.msg.makeTask.completeTime)).toLocaleString()
                    }
                    function result(x) {
                        let re;
                        if(x==1){
                            re='正常'
                        }else{
                            re='异常'
                        }
                        return re
                    }
                    that.msg.taskLoglist = res.data.repBody.taskLoglist.map((value, index) => {
                            return {
                                "description":value.description||'',//制码阶段描述
                            "logId":value.logId||'',//日志id
                            "operName":value.operName||'', //操作名称
                            "operTime":(new Date(value.operTime)).toLocaleString()||'',//操作时间
                            "result":result(value.result)||'', //操作结果（结果，1：正常，2：异常）
                            "taskID":value.taskID||'' //对应的任务id
                            }
                        });
                }else if(res.data.resCode === '100200'){
                    this.$message({
                        type: 'info',
                        message: res.data.resMsg
                    });
                }else{
                    this.$message({
                        type: 'info',
                        message: res.data.resMsg
                    });
                }
            })
            .catch(error => {
                    this.$message({
                    type: 'info',
                    message: res.data.resMsg
                });
            });


                this.$refs.exdetail.isShow=true;
            },
            transition (val) {
                let result;
                if(val=='-1'){
                    result='待处理'
                }
                if(val=='1'){
                    result='处理中'
                }
                if(val=='2'){
                    result='正常结束'
                }
                if(val=='3'){
                    result='异常结束'
                }
                return result
            },
            transition2 (val) {
                let result2;
                if(val=='START'){
                    result2='开始'
                }
                if(val=='GENERATE_CODE'){
                    result2='制码'
                }
                if(val=='INPUT_DB'){
                    result2='入库'
                }
                if(val=='PRINT_FILE'){
                    result2='生成待印文件'
                }
                if(val=='UPLOAD_FTP'){
                    result2='上传'
                }
                if(val=='FINISH'){
                    result2='完成'
                }
                return result2
            }
        }
    }
</script>
<style lang="less" rel="stylesheet/less" scoped>
    @import '../../assets/css/property.less';
    .detlist{
        width: 100%;
        .cell{
            .el-button{
                position: relative;
                /*margin:0 auto;*/
                text-align: center;
                width: 100px!important;
                .download{
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100px;
                    height: 28px;
                    z-index: 99;
                    /*display: inline-block;*/
                    color: #fff;
                }
            }
        }
    }
</style>
