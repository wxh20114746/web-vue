<template>
    <!--码任务详情-->
    <div class="exaqr" v-show="isShow">
        <div class="detail">
            <div class="headerEx"><span>查看制码任务</span><i class="el-icon-circle-close f-r" @click="close"></i>
            </div>
            <h3>1.制码任务信息</h3>
            <ul>
                <li class="list">
                    <div class="left dediv">任务编号:</div>
                    <div class="center dediv"><span class="f-l">{{msg.makeTask.taskId}}</span><span class="f-r name">批次号:</span></div>
                    <div class="right dediv">{{msg.makeTask.businessId}}</div>
                </li>
                <li class="list">
                    <div class="left dediv">任务名称:</div>
                    <div class="center dediv"><span class="f-l">{{msg.makeTask.taskName}}</span><span class="f-r name">制码量:</span></div>
                    <div class="right dediv">{{msg.makeTask.codeNum}}</div>
                </li>
                <li class="list">
                    <div class="left dediv">制码类型:</div>
                    <div class="center dediv"><span class="f-l" v-if="msg.makeTask.codeType==2">普通二维码</span><span class="f-r name">状态:</span></div>
                    <div class="right dediv" v-if="msg.makeTask.status==1">处理中</div><div class="right dediv" v-if="msg.makeTask.status==2">正常结束</div><div class="right dediv" v-if="msg.makeTask.status==3">异常结束</div>
                </li>
                <li class="list">
                    <div class="left dediv">申请日期:</div>
                    <div class="center dediv"><span class="f-l">{{msg.makeTask.createTime}}</span><span class="f-r name">完成日期:</span></div>
                    <div class="right dediv">{{msg.makeTask.completeTime}}</div>
                </li>
                <li class="list">
                    <div class="left dediv">阶段:</div>
                    <div class="center dediv"><span class="f-l">{{msg.makeTask.phase}}</span><span class="f-r name">进度:</span></div>
                    <div class="right dediv">{{msg.makeTask.progress}}</div>
                </li>
            </ul>
            <h3>2.日志列表</h3>
            <el-table
                    :formatter="formatter"
                    :data="msg.taskLoglist"
                    style="width: 100%"
                    max-height="170"
                    border
                    :row-class-name="tableRowClassName">
                <el-table-column
                        prop="operTime"
                        label="时间"
                        width="200"
                        align="center">
                </el-table-column>
                <el-table-column
                        prop="operName"
                        label="事件"
                        width="120"
                        align="center">
                </el-table-column>
                <el-table-column
                        prop="description"
                        label="阶段"
                        width="120"
                        align="center">
                </el-table-column>
                <el-table-column
                        prop="result"
                        label="结果"
                        width="120"
                        align="center">
                </el-table-column>
                <el-table-column
                        label="操作"
                        align="center"
                       >
                </el-table-column>
            </el-table>
            <div class="button2">
                <el-button type="primary" class="close" @click="close">返回</el-button>
            </div>
        </div>
    </div>
</template>
<script type="text/ecmascript-6">
    export default {
        data () {
            return {
                isShow: false
            }
        },
        props: {
            msg: {
                type: Object,
                default: null
            }
        },
        methods: {
            close () {
                this.isShow = false;
            },
            tableRowClassName(row, index) {
                if (index === 1) {
                    return 'info-row';
                } else if (index === 3) {
                    return 'positive-row';
                }
                return '';
            },
            handleClick() {
            }
        }
    }
</script>
<style lang="less" rel="stylesheet/less" scoped>
    @import '../../assets/css/property.less';

    .exaqr {
        box-shadow: 0px 0px 8px #ccc;
        position: fixed;
        margin: auto;
        /* 将上下左右边距（相对于浏览器窗口边缘）全设为0，使浏览器推算出的外边距上下、左右对应相等
           可以设置任何其他相等的值，但如果窗口小到不能容下任意一个方向的两侧边距，元素也将不居中，所以推荐设为0 */
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
        transition: opacity 2s;
        opacity: 1;
        border-radius: 3px;
        width: 700px;
        height: 650px;
        /*max-height: 700px;*/
        padding: 10px 10px;
        padding-top:5px;
        padding-bottom: 5px;
        border: 1px solid #ccc;
        background-color: #fff;
        z-index: 99;
        .headerEx {
            background-color: #fff;
            width: 100%;
            height: 40px;
            line-height: 40px;
            text-indent: 10px;
            font-size: 14px;
            border-bottom: 1px solid #ccc;
            span{
                font-size: 18px;
            }
            .el-icon-circle-close {
                font-size: 18px;
                cursor: pointer;
                margin-top: 10px;
                margin-right: 10px;
            }
        }

        .h3 {
            text-align: center;
            margin-top: 20px;
        }
        .button2 {
            position: absolute;
            bottom: 25px;
            width: 100%;
            padding-top: 30px;
            .el-button {
                display: block;
                width: 150px;
                margin:0 auto;
            }

        }
        .detail {
            height: 100%;
            h3{
                height: 60px;
                line-height: 60px;
                font-size:18px;
            }
            ul {
                border: 1px solid #ccc;
                border-bottom: 0;

                .list {
                    height: 50px;
                    box-sizing: border-box;
                    .left {
                        width: 15%;
                        text-align: right;
                        border-right:1px solid #ccc;
                        border-bottom:1px solid #ccc;
                        font-weight: 700;
                        font-size: 13px;
                    }
                    .center {
                        width: 60%;
                        border-right:1px solid #ccc;
                        border-bottom:1px solid #ccc;
                        .name{
                            font-weight: 700;
                            font-size: 13px;
                        }
                    }
                    .right {
                        width: 25%;
                        border-bottom:1px solid #ccc;
                        /*border-right:0px solid #ccc;*/
                    }
                    .dediv {
                        padding: 0 10px;
                        box-sizing: border-box;
                        float: left;
                        display: inline-block;
                        height: 50px;
                        line-height: 50px;
                        font-size: 13px;
                    }
                }
            }

            /*.el-table{*/
                /*overflow-x: hidden;*/
                /*.el-table__body{*/
                    /*overflow-x: hidden;*/
                    /*tbody{*/
                        /*overflow-x: hidden;*/
                    /*}*/
            /*}*/
            /*}*/
            .el-table .info-row {
                background: #c9e5f5;
            }

            .el-table .positive-row {
                background: #e2f0e4;
            }




            /*table.gridtable {*/
                /*font-family: verdana,arial,sans-serif;*/
                /*font-size:11px;*/
                /*color:#333333;*/
                /*border-width: 1px;*/
                /*border-color: #666666;*/
                /*border-collapse: collapse;*/
            /*}*/
            /*table.gridtable th {*/
                /*border-width: 1px;*/
                /*padding: 8px;*/
                /*border-style: solid;*/
                /*border-color: #666666;*/
                /*background-color: #dedede;*/
            /*}*/
            /*table.gridtable td {*/
                /*border-width: 1px;*/
                /*padding: 8px;*/
                /*border-style: solid;*/
                /*border-color: #666666;*/
                /*background-color: #ffffff;*/
            /*}*/




            p {
                height: 20px;
                line-height: 20px;
                margin: 20px;
                .sp {
                    display: inline-block;
                    width: 150px;
                    margin-left: 70px;
                }

            }
        }
    }

    .el-icon-circle-close {
        font-size: 18px;
        cursor: pointer;
        margin-top: 10px;
        margin-right: 10px;
    }
</style>
