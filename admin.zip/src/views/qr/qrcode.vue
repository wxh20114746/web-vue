<template>
    <!--码任务-->
    <div class="work-order"> 
        <el-row class="tool">
            <el-col :span="24">
                <div class="grid-content bg-purple toolbar">
                    <el-form :inline="true" :model="formInline" class="demo-form-inline">
                        <el-form-item label="" >
                            <el-input  v-model="formInline.oddnum" placeholder="请输入批次号" ></el-input>
                        </el-form-item>
                        <el-form-item label="">
                            <el-select  v-model="formInline.region" placeholder="请选择制码阶段" clearable>
                                <!--<el-option label="全部" value="全部"></el-option>-->
                                <el-option label="全部阶段" value="All"></el-option>
                                <el-option label="开始" value="START"></el-option>
                                <el-option label="制码" value="GENERATE_CODE"></el-option>
                                <el-option label="入库" value="INPUT_DB"></el-option>
                                <el-option label="生成待印文件" value="PRINT_FILE"></el-option>
                                <el-option label="上传" value="UPLOAD_FTP"></el-option>
                                <el-option label="完成" value="FTPFINISH"></el-option>
                            </el-select>
                        </el-form-item>
                        <el-form-item>
                            <el-button  type="primary" @click="onSubmit" class="serSub">查询</el-button>
                        </el-form-item>
                        <br>
                    </el-form>                </div>
            </el-col>
        </el-row>
        <!--码任务列表-->
        <detlist :tableData="tableData" :changeData="changeData" v-loading="loading" :search="search"></detlist>
    </div>
</template>
<script type="text/ecmascript-6">
    import detlist from './detlist.vue';
    export default {
        components: {
            detlist
        },
        data() {
            return {
                //查询条件
                formInline: {
                    oddnum: '',
                    region: 'All'
                },
                //列表渲染
                tableData: [],
                loading:false,
                title:'码任务',
                search:{
                    businessId:'',
                    phase:''
                }
            }
        },
        created () {
            document.title='码任务';
        },
        methods: {
            //查询
            onSubmit() {
                var that=this;
                if (this.formInline.oddnum ===''&&this.formInline.region ==='') {
                    that.$message({
                        type: 'info',
                        message: '查询条件不能为空'
                    });
                    return false;
                }
                if(this.formInline.region === 'All'){
                  this.formInline.region = ''
                }
                this.search={
                    businessId: this.formInline.oddnum,
                    phase: this.formInline.region
                }
            },
            changeData (newV) {
                this.tableData=newV;
            },
            transition (val) {
                let result;

                if(val=='1'){
                    result='处理中'
                }
                if(val=='2'){
                    result='正常结束'
                }
                if(val=='3'){
                    result='异常结束'
                }
                return result
            },
            reload () {
                this.$router.push({
                    path: '/empty'
                })
            }
        }
    }
</script>
<style lang="less" rel="stylesheet/less" scoped>
    @import '../../assets/css/property.less';

    .work-order {
        padding: 20px 20px 0 20px;
        width: 100%;
        margin-left:230px;
        min-width:1008px;
        margin-top:60px;
        /*flex: 1;*/
        /*border: 1px solid #ccc;*/
        /*.search {*/
            /*padding: 10px 10px;*/
            /*width: 100%;*/
            /*height: 100px;*/
            /*!*line-height: 100px;*!*/
            /*border: 1px solid #ccc;*/
            /*.demo-form-inline{*/
                /*margin-top:30px;*/
            /*}*/
            /*.oinput {*/
                /*width: 193px;*/
            /*}*/
            /*.serSub {*/
                /*width: 150px;*/
            /*}*/
        /*}*/
        .el-row {
            margin-bottom: 20px;
            &:last-child {
                margin-bottom: 0;
            }
        }
        .tool{
            background-color: #f2f2f2;
            padding:10px;
            border-radius: 2px;
            margin: 10px 0px;

        }
        .el-col {
            border-radius: 4px;
            /*padding:10px;*/
        }
        .bg-purple-dark {
            background: #99a9bf;
        }
        .bg-purple {
            background: #f2f2f2;
        }
        .bread {
            padding-top: 2px;
            height: 24px;
            /*line-height: 50px;*/
            font-size: 14px;
        }
        .toolbar {
            /*background-color: #f2f2f2;*/
            /*padding: 10px;*/
            /*margin: 10px 0px;*/

            .add{
                font-size:14px;
            }
            .el-form-item {
                margin-bottom: 0px;
                .serSub{
                    span{
                        -webkit-font-smoothing: antialiased;

                    }
                }
            }
        }
    }
</style>
