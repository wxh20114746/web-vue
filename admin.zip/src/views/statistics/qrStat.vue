<template>
    <!--码管理-->
    <div class="work-order">
         
        <el-row class="tool">
            <el-col :span="6">
              <div class="grid-content bg-purple" style="margin-bottom:20px; margin-right:20px;">
                <el-card class="box-card">
                  <div class="text item codeNums">
                        <img src="../../assets/img/codenum.png">
                        <div class="l_cont">
                            <p class="b_n">打码总数</p>
                            <P class="b_c">{{bindCodeNum}}</P>
                        </div> 
                  </div> 
                </el-card>
              </div>
            </el-col>

               <el-col :span="6">
              <div class="grid-content bg-purple" style="margin-bottom:20px;margin-right:20px;">
                <el-card class="box-card">
                  <div class="text item codeNums">
                        <img src="../../assets/img/bindcar.png">
                        <div class="l_cont">
                            <p class="b_n">绑定车辆总数</p>
                            <P class="b_c">{{bindCarNum}}</P>
                        </div> 
                  </div> 
                </el-card>
              </div>
            </el-col>

               <el-col :span="6">
              <div class="grid-content bg-purple" style="margin-bottom:20px;margin-right:20px;">
                <el-card class="box-card">
                  <div class="text item codeNums">
                        <img src="../../assets/img/buda.png">
                        <div class="l_cont">
                            <p class="b_n">补打总数</p>
                            <P class="b_c">{{supplementNum}}</P>
                        </div> 
                  </div> 
                </el-card>
              </div>
            </el-col>

            <el-col :span="24">
                <div class="grid-content bg-purple toolbar">
                    <el-form :inline="true" :model="formInline" class="demo-form-inline creatqr">
                    
                        <el-form-item label="">
                               <el-select  v-model="formInline.qrid" placeholder="全部车检站" clearable>  
                                <el-option :label="item.aileas" :value="item.id" v-for="item in stationList"></el-option> 
                            </el-select>
                        </el-form-item>
                    <el-form-item>
                            <div class="block">
                              <el-date-picker
                                v-model="value1"
                                type="date"
                                placeholder="选择开始日期"
                                @change="getStartDate"
                                :picker-options="pickerOptions0"
                              >
                              </el-date-picker>
                            </div>
                    </el-form-item>
                    <el-form-item>
                        <div class="block">
                          <el-date-picker
                            v-model="value2"
                            type="date"
                            placeholder="选择结束日期"
                            @change="getEndDate"
                            :picker-options="pickerOptions1"
                          >
                          </el-date-picker>
                        </div>
              </el-form-item>
                        <el-form-item>
                            <el-button  type="primary" @click="getList" class="serSub" icon="search">查询</el-button>
                        </el-form-item>
                        <el-form-item> 
                            <a :href="baseUrl+'/qrcode/export?startDate='+formInline.startTime+'&endDate='+formInline.endTime+'&cisId='+formInline.qrid" download="码统计" class="download-cust"><el-button type="primary" class="serSub" icon="upload2">导出</el-button></a>
                        </el-form-item>
                    </el-form>
                </div>
            </el-col>
        </el-row>
         <!-- 列表 -->
             <div class="detlist" v-loading="loading" ref="detQr">
        <el-table
                :data="tableData"
                border
                >
            <el-table-column
                    prop="companyName"
                    label="车检站" 
                    align="center">
            </el-table-column>
            <el-table-column
                    prop="sprayNum"
                    label="绑码数量" 
                    align="center">
            </el-table-column>
            <el-table-column
                    prop="bindCarNum"
                    label="绑码车辆" 
                    align="center">
            </el-table-column>
            <el-table-column
                    prop="reprintNum"
                    label="补打次数" 
                    align="center">
            </el-table-column> 
        </el-table>
        <!--分页-->
        <page-bar :changePage="changePage"  class="f-r" :pageMsg="pageMsg" v-if="pageIf"></page-bar>
    </div> 
    </div>
</template>
<script type="text/ecmascript-6">
    import axios from 'axios'
    import tastlist from './tastlist.vue'; 
    import pageBar from '../../components/pageBar.vue'
    export default {
        components: {
            tastlist ,
            pageBar
        },
        data() {
            return {
                baseUrl:'',
                isShow: false,
                pageIf:true,
                  pageMsg: {
                    pageSum: '',
                    //总页码
                    pageList: [],
                    //单页数量
                    pageSize: 10,
                    //商品总数
                    totalCount: '',
                    list: []
                },
                //查询条件
                formInline: { 
                    qrid: '',
                    startTime:'',
                    endTime:''

                },
                value1:'',
                value2:'',
                //列表数据
                tableData: [],
                loading:false,
                title:'批次管理',
                search:{
                    batchName: '',
                    batchId: ''
                },
                stationList:[], //所有车检站
                bindCarNum:'0', //绑定车辆总数
                bindCodeNum:'0',//绑码总数
                supplementNum:'0',//补打总数
                pickerOptions0: {
                  disabledDate: (time) => {
                    if (this.value2 != "") {
                      return time.getTime() > Date.now() || time.getTime() > this.value2;
                    } else {
                      return time.getTime() > Date.now();
                    }
                  }
                },
                pickerOptions1: {
                  disabledDate: (time) => {
                    return time.getTime() < this.value1 || time.getTime() > Date.now();
                  } 
            }
        }
        },
        created () {
            document.title='批次管理';
            this.baseUrl = axios.defaults.baseURL;
            this.checkcodeNum();  //查询绑码数量
            this.getallstation();
            this.loading = true;
            this.getList();//初始化列表
        },
        methods: {
                //渲染列表
            changePage (num,list) {
                this.loading = true;

                let msg = {
                    data:{
                        pageName:"pqQrcodeService",
                        paginator:{
                            limit:10,
                            page:num
                        },
                        params:{
                            startDate:this.formInline.startTime,
                            endDate:this.formInline.endTime,
                            cisId:this.formInline.qrid
                        }
                    }
                };
                if(num=='1'){
                    this.pageIf=false;
                }
                var that = this;
                that.axios.post('/page/list',JSON.stringify(msg))
                    .then(res => {
                        if (res.data.resCode === '000000') {
                            //渲染处理函数
                            this.loading = false;
                          that.tableData = res.data.repBody.list; 
                            if(num=='1'){
                                this.pageIf=true;
                            }
                            this.pageMsg.totalCount = res.data.repBody.paginator.totalCount;
                            this.pageMsg.pageSum = res.data.repBody.paginator.totalPages;
                            for (let i = 1; i <= this.pageMsg.pageSum; i++) {
                                this.pageMsg.pageList.push(i);
                            }
                            if((num - 1) % 5 === 0){
                                this.pageMsg.list = this.pageMsg.pageList.slice(num - 1, num + 4);
                            }else if(num==1){
                                this.pageMsg.list = this.pageMsg.pageList.slice(0, 5);
                            }else if(num==this.pageMsg.pageSum&&(num % 5) === 0){
                                this.pageMsg.list = this.pageMsg.pageList.slice(num - 5, num);
                            }else if(num==this.pageMsg.pageSum&&(num % 5) !== 0){
                                let nn=num%5;
                                this.pageMsg.list = this.pageMsg.pageList.slice(num - nn, num);
                            }else if((num) % 5 === 0){
                                this.pageMsg.list = this.pageMsg.pageList.slice(num - 5, num);
                            }else{
                                this.pageMsg.list = list
                            }
                        }else {
                            this.loading = false;
                            let message = res.data.resMsg
                            MessageBox.alert(message).then(action => {
                                delCookie('JSESSIONID');
                            localStorage.clear();
                            sessionStorage.clear();
                            that.$router.push('/login')
                        });
                        }
                    })
                    .catch(error => {
                    this.loading = false;
                        this.$message({
                            type: 'info',
                            message: '网络错误'
                        });
                    })
            },
            //码统计导出
            qrcodereport(){
                let that = this;
                let msg = {
                    data:{
                        startDate:that.formInline.startTime,
                        endDate:that.formInline.endTime,
                        cisId:that.formInline.qrid
                    }
                };
                that.axios.post('/qrcode/export',JSON.stringify(msg))
                .then(res => {

                })
                .catch(error => {

                })
            },
            //列表
            getList(){
                let msg = {
                    data:{
                        pageName:"pqQrcodeService",
                        paginator:{
                            limit:10,
                            page:1
                        },
                        params:{
                            startDate:this.formInline.startTime,
                            endDate:this.formInline.endTime,
                            cisId:this.formInline.qrid
                        }
                    }
                }
                let that = this;
                    that.axios.post('/page/list', JSON.stringify(msg))
                    .then(res => { 
                        if (res.data.resCode === '000000') { 
                            that.loading = false;
                            that.tableData = res.data.repBody.list;

                            //传给分页组件
                        this.pageMsg.totalCount = res.data.repBody.paginator.totalCount;
                        this.pageMsg.pageSum = res.data.repBody.paginator.totalPages;
                        for (let i = 1; i <= this.pageMsg.pageSum; i++) {
                            this.pageMsg.pageList.push(i);
                        }
                        this.pageMsg.list = this.pageMsg.pageList.slice(0, 5);
                        }
                    })
                    .catch(error => { 

                    })
            },
            //获取所有车检站
            getallstation(){
             let msg = {}
                let that = this;
                that.axios.post('/cisCompany/queryAll', JSON.stringify(msg))
                .then(res => { 
                    if (res.data.resCode === '000000') { 
                        that.stationList = res.data.repBody;
                    }
                })
                .catch(error => { 

                })
            },
            //查询绑码总数
            checkcodeNum(){
                let msg = {};
                let that = this;
                that.axios.post('/qrcode/sum', JSON.stringify(msg))
                .then(res => { 
                    if (res.data.resCode === '000000') {
                        if(res.data.repBody.bindCarNum){that.bindCarNum = res.data.repBody.bindCarNum;}
                        if(res.data.repBody.bindCodeNum){that.bindCodeNum = res.data.repBody.bindCodeNum;}
                        if(res.data.repBody.supplementNum){that.supplementNum = res.data.repBody.supplementNum;}
                        
                        // that.bindCodeNum = res.data.repBody.bindCodeNum;
                        // that.supplementNum = res.data.repBody.supplementNum;
                    }
                })
                .catch(error => { 

                })
            },
            creatqr(){

            },
            getStartDate (value) {
                this.formInline.startTime = value;
              },
            getEndDate(value){
                this.formInline.endTime = value;
              },
            //查询
            onSubmit() {
                console.log(this.value1,this.value2);
                var that=this;
                if (this.formInline.qrname ===''&&this.formInline.qrid ==='') {
                    that.$message({
                        type: 'info',
                        message: '查询条件不能为空'
                    });
                    return false;
                }
                this.search={
                    batchName: this.formInline.qrname,
                    batchId: this.formInline.qrid
                }
            },
            changeData (val) {
                console.log(val)
                this.tableData=val;
            },
            reload () {
                this.$router.push({
                    path: '/empty'
                })
            }
        }
    }
</script>
<style lang="less" rel="stylesheet/less">
    @import '../../assets/css/property.less';
    .work-order {
        padding: 20px 20px 0 20px;
        width: 100%;
        min-width:1008px;
        margin-left:230px;
        margin-top:60px;
        .search {
            padding: 10px 10px;
            width: 100%;
            height: 100px;
            border: 1px solid #ccc;
            /*.creatqr {*/
                /*margin: 30px 5px;*/
            /*}*/
            .oinput {
                width: 193px;
            }
        }
        .el-col-6{
        width:26%;
        }
        .el-row {
            margin-bottom: 20px;
            &:last-child {
                margin-bottom: 0;
            }
        }
        .el-card__body{
            padding:0 !important;
        }
        .codeNums{ 

            img{
                display: inline-block;
                float: left;
                width: 64px;
                height: 64px;
                margin:10px;
            }
            .l_cont{
                float: left;  
                text-align: center;
                .b_n{
                    margin-top: 15px;
                    font-size: 24px;
                    color: #666666;
                    font-weight: 400;
                }
                .b_c{
                    margin-top: 10px;
                    font-weight: bold;
                    font-size: 30px;
                }
            }
        }
        .tool{
            background-color: #f2f2f2;
            padding:10px;
            border-radius: 2px;
            margin: 10px 0px;

        }
        .el-col {
            border-radius: 4px;
            /*padding:10px;*/
        }
        .bg-purple-dark {
            background: #99a9bf;
        }
        .bg-purple {
            background: #f2f2f2;
        }
        .bread {
            padding-top: 2px;
            height: 24px;
            /*line-height: 50px;*/
            font-size: 14px;
        }
        .toolbar {
            /*background-color: #f2f2f2;*/
            /*padding: 10px;*/
            /*margin: 10px 0px;*/

            .add{
                font-size:14px;
            }
            .el-form-item {
                margin-bottom: 0px;
                /*.serSub{*/
                /*span{*/
                /*font-weight:200;*/
                /*font-size: 22px;*/
                /*color: #000;*/
                /*}*/
                /*}*/
            }
        }
        .serSub{
            white-space: nowrap;
            cursor: pointer;
            font-size: 14px;
            text-rendering: auto;
            letter-spacing: normal;
            word-spacing: normal;
            text-transform: none;
            text-indent: 0px;
            text-shadow: none;
            /*字体变细的原因*/
            -webkit-font-smoothing: antialiased;
        }
    }
</style>
