<template>
    <!--批次管理列表-->
    <div class="detlist" v-loading="loading" ref="detQr">
        <el-table
                :data="tableData"
                border
                >
            <el-table-column
                    prop="cisName"
                    label="车检站" 
                    align="center">
            </el-table-column>
            <el-table-column
                    prop="bindCodeNum"
                    label="绑码数量" 
                    align="center">
            </el-table-column>
            <el-table-column
                    prop="bindCarNum"
                    label="绑码车辆" 
                    align="center">
            </el-table-column>
            <el-table-column
                    prop="supplementNum"
                    label="补打次数" 
                    align="center">
            </el-table-column> 
        </el-table>
        <!--分页-->
        <page-bar :changePage="changePage"  class="f-r" :pageMsg="pageMsg" v-if="pageIf"></page-bar>
    </div>
</template>
<script type="text/ecmascript-6">
    import pageBar from '../../components/pageBar.vue'
    import {Message} from 'element-ui';

    export default {
        data() {
            return {
                loading:false,
                pageIf:true,
                pageMsg: {
                    pageSum: '',
                    //总页码
                    pageList: [],
                    //单页数量
                    pageSize: 10,
                    //商品总数
                    totalCount: '',
                    list: []
                },
                tableData:[],

            }
        },
        //分页
        components: {
            pageBar
        },
        props: {
            tableData:{
                type:Array,
                default:[]
            },
            changeData:{
                type:Function,
                default:null
            },
            search:{
                type:Object,
                default:null
            }
        },
        watch :{
            'search' :{
                handler:function(val,oldval){
                    this.changePage(1);
                }
            }
        },
        created () {
            function getCookie(name) {
                var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");

                if (arr = document.cookie.match(reg))

                    return (arr[2]);
                else
                    return null;
            }

            function delCookie(name) {
                var exp = new Date();
                exp.setTime(exp.getTime() - 1);
                var cval = getCookie(name);
                if (cval != null)
                    document.cookie = name + "=" + cval + ";expires=" + exp.toGMTString();
            }
            // this.loading = true;

            let msg={data:
                {"pageName":localStorage.getItem("pages"),
                    "paginator":{"limit":10,"page":1},
                    "params":{"batchId:":"","batchName":""}
                }
            };

            var that = this;
            return
            that.axios.post('/page/list',JSON.stringify(msg))
                .then(res => {
            if (res.data.resCode === '000000') {
                this.loading = false;

                //查询字段处理函数
                let warningItem = res.data.repBody.list.map((value, index) => {
                        return {
                            qrnum: value.batchId,//批次号
                            qrname: value.batchName,//批次名称
                            qrtype: this.transition(value.codeType),//制码类型
                            createTime: (new Date(value.createTime)).toLocaleString(),//创建时间
                            count: value.qrcodeNum//码总量
                        }
                    });
                //this.tableData = warningItem;
                //传给分页组件
                this.pageMsg.totalCount = res.data.repBody.paginator.totalCount;
                this.pageMsg.pageSum = res.data.repBody.paginator.totalPages;
                for (let i = 1; i <= this.pageMsg.pageSum; i++) {
                    this.pageMsg.pageList.push(i);
                }
                this.pageMsg.list = this.pageMsg.pageList.slice(0, 5);
            }else {
                this.loading = false;

                let message = res.data.resMsg
                MessageBox.alert(message).then(action => {
                    delCookie('JSESSIONID');
                localStorage.clear();
                sessionStorage.clear();
                that.$router.push('/login')
            });
            }
        })
        .catch(error => {
                this.loading = false;
            this.$message({
                type: 'info',
                message: '网络错误'
            });
        })
        },
        methods: {
            formatter(row, column) {
                return row.createTime;
            },
            //渲染列表
            changePage (num,list) {
                this.pageMsg={
                    pageSum: '',
                    //总页码
                    pageList: [],
                    //单页数量
                    pageSize: 10,
                    //商品总数
                    totalCount: '',
                    list: []
                };
                this.loading = true;

                //查询条件,放入对象,转为字符串符合后台传入的参数
                let msg={data:
                    {"pageName":localStorage.getItem("pages"),
                        "paginator":{"limit":10,"page":num},
                    "params":this.search
                    }
                };

                if(num=='1'){
                    this.pageIf=false;
                }
                var that = this;
                that.axios.post('/page/list',JSON.stringify(msg))
                    .then(res => {
                if (res.data.resCode === '000000') {
                    this.loading = false;
                    let warningItem = res.data.repBody.list.map((value, index) => {
                            return {
                                qrnum: value.batchId,//批次号
                                qrname: value.batchName,//批次名称
                                qrtype: this.transition(value.codeType),//制码类型
                                createTime: (new Date(value.createTime)).toLocaleString(),//创建时间
                                count: value.qrcodeNum//码总量
                                //让tableData的num接收它的id
                            }
                        });
                    this.tableData = warningItem;
                    if(num=='1'){
                        this.pageIf=true;
                    }
                    this.pageMsg.totalCount = res.data.repBody.paginator.totalCount;
                    this.pageMsg.pageSum = res.data.repBody.paginator.totalPages;
                    for (let i = 1; i <= this.pageMsg.pageSum; i++) {
                        this.pageMsg.pageList.push(i);
                    }
                    if((num - 1) % 5 === 0){
                        this.pageMsg.list = this.pageMsg.pageList.slice(num - 1, num + 4);
                    }else if(num==1){
                        this.pageMsg.list = this.pageMsg.pageList.slice(0, 5);
                    }else if(num==this.pageMsg.pageSum&&(num % 5) === 0){
                        this.pageMsg.list = this.pageMsg.pageList.slice(num - 5, num);
                    }else if(num==this.pageMsg.pageSum&&(num % 5) !== 0){
                        let nn=num%5;
                        this.pageMsg.list = this.pageMsg.pageList.slice(num - nn, num);
                    }else if((num) % 5 === 0){
                        this.pageMsg.list = this.pageMsg.pageList.slice(num - 5, num);
                    }else{
                        this.pageMsg.list = list
                    }
                }else{
                    this.loading = false;
                    this.$message({
                        type: 'info',
                        message: '网络错误'
                    });
                }
                })
            .catch(error => {
                    this.loading = false;
                this.$message({
                    type: 'info',
                    message: '网络错误'
                });

            })
                //发送查询请求,返回数组对象.


            },
            onTex (val) {
                var newV = {
                    qrnum: value.qrnum,//批次号
                    qrname: value.qrname,//批次名称
                    qrtype: value.qrtype,//制码类型
                    count: value.count//码总量
                };

                this.tableData.push(newV);
            },
            transition (val) {
                let result;
                if(val=='1'){
                    result='字符码'
                }
                if(val=='2'){
                    result='普通二维码'
                }
                if(val=='3'){
                    result='条形码'
                }
//                if(val=='8'){
//                    result='微型二维码'
//                }
                return result
            }
        }
    }
</script>
<style lang="less" rel="stylesheet/less" scoped>
    @import '../../assets/css/property.less';
    .detlist {
        width: 100%;
    }
</style>
