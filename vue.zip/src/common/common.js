import Vue from 'vue'

// 公共Vue对象
const bus = new Vue()

export {bus}