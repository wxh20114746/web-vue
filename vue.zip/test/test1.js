// 基础用法
/**
const promise = new Promise((resolve,reject)=>{
    // 做一些耗时间的操作
    setTimeout(() => {
        const random = Math.random()
        console.log(random)

        if(random > 0.5){
            resolve({status:0,message:'success'})
        }else{
            reject(new Error('执行异步操作失败'))
        }
    }, 2000);
})


promise.then(result=>{
    console.log(result)
},err=>{
    console.log(err)
})

promise.then(result=>{
    console.log(result)
}).catch(err=>{
    console.log(err)
})

 */

 /** 
setTimeout(() => {
    console.log("---第一层----")
    setTimeout(() => {
        console.log("---第二层----")
        setTimeout(() => {
            console.log("---第三层----")
            setTimeout(() => {
                console.log("---第四层----")
            }, 2000);
        }, 1000);
    }, 3000);
}, 2000);
*/

// 封装一个函数，每个函数中，返回一个新的promise对象
function delay(timeout,str){
    const promise = new Promise((resolve,reject)=>{
        // 耗时间操作
        setTimeout(() => {
            resolve(str)
        }, timeout);
    })

    return promise
}

delay(2000,"---第一层----").then(result1=>{
    console.log(result1)
    return delay(3000,'---第二层----')
}).then(result2=>{
    console.log(result2)
    return delay(1000,'---第三层----')
}).then(result3=>{
    console.log(result3)
    return delay(2000,'---第四层----')
}).then(result4=>{
    console.log(result4)
})