/**
const promise1 = new Promise((resolve,reject)=>{
    setTimeout(() => {
        resolve("---网络请求之后，获取到的数据111----")
    }, 3000);
})

const promise2 = new Promise((resolve,reject)=>{
    setTimeout(() => {
        resolve("---网络请求之后，获取到的数据222----")
    }, 1000);
})


async function delay(){
    const result1 = await promise1
    
    console.log(result1)

    
    const result2 = await promise2

    console.log(result2)
}

delay()
 */

 // 封装一个函数，每个函数中，返回一个新的promise对象
function delay(timeout,str){
    const promise = new Promise((resolve,reject)=>{
        // 耗时间操作
        setTimeout(() => {
            resolve(str)
        }, timeout);
    })

    return promise
}

async function execDelay(){
    const result1 = await delay(2000,'---第一层----')
    console.log(result1)

    const result2 = await delay(3000,'---第二层----')
    console.log(result2)

    const result3 = await delay(1000,'---第三层----')
    console.log(result3)

    const result4 = await delay(2000,'---第四层----')
    console.log(result4)
}

execDelay()